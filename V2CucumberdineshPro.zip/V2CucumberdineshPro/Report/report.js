$(document).ready(function() {var formatter = new CucumberHTML.DOMFormatter($('.cucumber-report'));formatter.uri("1LoginV2SocialSurvey.feature");
formatter.feature({
  "line": 1,
  "name": "Login functionality for v2socialsurevey Website",
  "description": "",
  "id": "login-functionality-for-v2socialsurevey-website",
  "keyword": "Feature"
});
formatter.scenarioOutline({
  "line": 3,
  "name": "",
  "description": "Sucessful login into the v2socialsurvey website with valid credentials",
  "id": "login-functionality-for-v2socialsurevey-website;",
  "type": "scenario_outline",
  "keyword": "Scenario Outline",
  "tags": [
    {
      "line": 2,
      "name": "@login"
    }
  ]
});
formatter.uri("2AdminV2SocialSurvey.feature");
formatter.feature({
  "line": 2,
  "name": "Admin Management functionality for v2socialsurevey Website",
  "description": "",
  "id": "admin-management-functionality-for-v2socialsurevey-website",
  "keyword": "Feature",
  "tags": [
    {
      "line": 1,
      "name": "@Admin"
    }
  ]
});
formatter.scenario({
  "line": 5,
  "name": "Sucessfull verify pagination of all admin list with suitable login user",
  "description": "",
  "id": "admin-management-functionality-for-v2socialsurevey-website;sucessfull-verify-pagination-of-all-admin-list-with-suitable-login-user",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 4,
      "name": "@AdminPagination"
    }
  ]
});
formatter.step({
  "line": 6,
  "name": "user clicks the admin icon",
  "keyword": "When "
});
formatter.step({
  "line": 7,
  "name": "user scrolling down to the page",
  "keyword": "When "
});
formatter.step({
  "line": 8,
  "name": "user naviagates to next page",
  "keyword": "And "
});
formatter.step({
  "line": 9,
  "name": "user navigates to the last page",
  "keyword": "And "
});
formatter.step({
  "line": 10,
  "name": "user navigates to the previous page",
  "keyword": "And "
});
formatter.step({
  "line": 11,
  "name": "user naviagtes to the admin list first page",
  "keyword": "Then "
});
formatter.match({
  "location": "BBStepdefenitionAdmin.user_clicks_the_admin_icon()"
});
formatter.result({
  "duration": 62112584232,
  "status": "passed"
});
formatter.match({
  "location": "BBStepdefenitionAdmin.user_scrolling_down_to_the_page()"
});
formatter.result({
  "duration": 31370508200,
  "error_message": "org.openqa.selenium.NoSuchElementException: no such element: Unable to locate element: {\"method\":\"xpath\",\"selector\":\"(//a[@class\u003d\u0027ant-pagination-item-link\u0027])[2]\"}\n  (Session info: chrome\u003d84.0.4147.105)\nFor documentation on this error, please visit: https://www.seleniumhq.org/exceptions/no_such_element.html\nBuild info: version: \u00273.141.59\u0027, revision: \u0027e82be7d358\u0027, time: \u00272018-11-14T08:17:03\u0027\nSystem info: host: \u0027Dineshs-MBP\u0027, ip: \u0027fe80:0:0:0:c34:547b:ffcb:450a%en0\u0027, os.name: \u0027Mac OS X\u0027, os.arch: \u0027x86_64\u0027, os.version: \u002710.15.2\u0027, java.version: \u00271.8.0_251\u0027\nDriver info: org.openqa.selenium.chrome.ChromeDriver\nCapabilities {acceptInsecureCerts: false, browserName: chrome, browserVersion: 84.0.4147.105, chrome: {chromedriverVersion: 84.0.4147.30 (48b3e868b4cc0..., userDataDir: /var/folders/7b/3897g_kx40z...}, goog:chromeOptions: {debuggerAddress: localhost:57699}, javascriptEnabled: true, networkConnectionEnabled: false, pageLoadStrategy: normal, platform: MAC, platformName: MAC, proxy: Proxy(), setWindowRect: true, strictFileInteractability: false, timeouts: {implicit: 0, pageLoad: 300000, script: 30000}, unhandledPromptBehavior: dismiss and notify, webauthn:virtualAuthenticators: true}\nSession ID: 0cfc972b41afd8ee2d4e1d67d5f2ea1d\n*** Element info: {Using\u003dxpath, value\u003d(//a[@class\u003d\u0027ant-pagination-item-link\u0027])[2]}\n\tat sun.reflect.GeneratedConstructorAccessor16.newInstance(Unknown Source)\n\tat sun.reflect.DelegatingConstructorAccessorImpl.newInstance(DelegatingConstructorAccessorImpl.java:45)\n\tat java.lang.reflect.Constructor.newInstance(Constructor.java:423)\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.createException(W3CHttpResponseCodec.java:187)\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:122)\n\tat org.openqa.selenium.remote.http.W3CHttpResponseCodec.decode(W3CHttpResponseCodec.java:49)\n\tat org.openqa.selenium.remote.HttpCommandExecutor.execute(HttpCommandExecutor.java:158)\n\tat org.openqa.selenium.remote.service.DriverCommandExecutor.execute(DriverCommandExecutor.java:83)\n\tat org.openqa.selenium.remote.RemoteWebDriver.execute(RemoteWebDriver.java:552)\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:323)\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElementByXPath(RemoteWebDriver.java:428)\n\tat org.openqa.selenium.By$ByXPath.findElement(By.java:353)\n\tat org.openqa.selenium.remote.RemoteWebDriver.findElement(RemoteWebDriver.java:315)\n\tat org.openqa.selenium.support.pagefactory.DefaultElementLocator.findElement(DefaultElementLocator.java:69)\n\tat org.openqa.selenium.support.pagefactory.internal.LocatingElementHandler.invoke(LocatingElementHandler.java:38)\n\tat com.sun.proxy.$Proxy14.getWrappedElement(Unknown Source)\n\tat org.openqa.selenium.remote.internal.WebElementToJsonConverter.apply(WebElementToJsonConverter.java:50)\n\tat java.util.stream.ReferencePipeline$3$1.accept(ReferencePipeline.java:193)\n\tat java.util.Spliterators$ArraySpliterator.forEachRemaining(Spliterators.java:948)\n\tat java.util.stream.AbstractPipeline.copyInto(AbstractPipeline.java:482)\n\tat java.util.stream.AbstractPipeline.wrapAndCopyInto(AbstractPipeline.java:472)\n\tat java.util.stream.ReduceOps$ReduceOp.evaluateSequential(ReduceOps.java:708)\n\tat java.util.stream.AbstractPipeline.evaluate(AbstractPipeline.java:234)\n\tat java.util.stream.ReferencePipeline.collect(ReferencePipeline.java:499)\n\tat org.openqa.selenium.remote.RemoteWebDriver.executeScript(RemoteWebDriver.java:484)\n\tat com.baseclass.org.BaseClass.scrollingup(BaseClass.java:97)\n\tat com.V2SS.Stepdefenition.BBStepdefenitionAdmin.user_scrolling_down_to_the_page(BBStepdefenitionAdmin.java:48)\n\tat ✽.When user scrolling down to the page(2AdminV2SocialSurvey.feature:7)\n",
  "status": "failed"
});
formatter.match({
  "location": "BBStepdefenitionAdmin.user_naviagates_to_next_page()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "BBStepdefenitionAdmin.user_navigates_to_the_last_page()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "BBStepdefenitionAdmin.user_navigates_to_the_previous_page()"
});
formatter.result({
  "status": "skipped"
});
formatter.match({
  "location": "BBStepdefenitionAdmin.user_naviagtes_to_the_admin_list_first_page()"
});
formatter.result({
  "status": "skipped"
});
formatter.scenario({
  "line": 15,
  "name": "Sucessfull edit of all admin fields with suitable login user",
  "description": "",
  "id": "admin-management-functionality-for-v2socialsurevey-website;sucessfull-edit-of-all-admin-fields-with-suitable-login-user",
  "type": "scenario",
  "keyword": "Scenario",
  "tags": [
    {
      "line": 14,
      "name": "@Editadmin"
    }
  ]
});
formatter.step({
  "line": 16,
  "name": "user click the search button1",
  "keyword": "When "
});
formatter.step({
  "line": 17,
  "name": "user enter the admin1",
  "keyword": "And "
});
formatter.step({
  "line": 18,
  "name": "user click the pencil icon1",
  "keyword": "And "
});
formatter.step({
  "line": 19,
  "name": "user click the submit button1",
  "keyword": "And "
});
formatter.step({
  "line": 20,
  "name": "user clear the admin",
  "keyword": "And "
});
formatter.step({
  "line": 21,
  "name": "user enter the admin",
  "keyword": "And "
});
formatter.step({
  "line": 22,
  "name": "user click the pencil icon",
  "keyword": "And "
});
formatter.step({
  "line": 23,
  "name": "user edit the first name",
  "keyword": "And "
});
formatter.step({
  "line": 24,
  "name": "user add the first name",
  "keyword": "And "
});
formatter.step({
  "line": 25,
  "name": "user edit the last name",
  "keyword": "And "
});
formatter.step({
  "line": 26,
  "name": "user add the last name",
  "keyword": "And "
});
formatter.step({
  "line": 27,
  "name": "user inactive the admin toggle",
  "keyword": "And "
});
formatter.step({
  "line": 28,
  "name": "user active the admin toggle",
  "keyword": "And "
});
formatter.step({
  "line": 29,
  "name": "user click the group",
  "keyword": "And "
});
formatter.step({
  "line": 30,
  "name": "user add the group",
  "keyword": "And "
});
formatter.step({
  "line": 31,
  "name": "user delete the group",
  "keyword": "And "
});
formatter.step({
  "line": 32,
  "name": "user click the organization",
  "keyword": "And "
});
formatter.step({
  "line": 33,
  "name": "user add the organization",
  "keyword": "And "
});
formatter.step({
  "line": 34,
  "name": "user delete the existing organization",
  "keyword": "And "
});
formatter.step({
  "line": 35,
  "name": "user click the submit btn org",
  "keyword": "And "
});
formatter.step({
  "line": 36,
  "name": "user click the allaccounts icon",
  "keyword": "And "
});
formatter.step({
  "line": 37,
  "name": "user click the myaccounts icon",
  "keyword": "And "
});
formatter.step({
  "line": 38,
  "name": "user click the admin page icon",
  "keyword": "Then "
});
formatter.match({
  "arguments": [
    {
      "val": "1",
      "offset": 28
    }
  ],
  "location": "BBStepdefenitionAdmin.user_click_the_search_button(int)"
});
formatter.result({
  "duration": 60814402548,
  "status": "passed"
});
formatter.match({
  "arguments": [
    {
      "val": "1",
      "offset": 20
    }
  ],
  "location": "BBStepdefenitionAdmin.user_enter_the_admin(int)"
});
