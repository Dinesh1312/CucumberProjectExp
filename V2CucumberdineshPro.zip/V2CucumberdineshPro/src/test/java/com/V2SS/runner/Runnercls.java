package com.V2SS.runner;

import org.junit.BeforeClass;
import org.junit.runner.RunWith;
import org.openqa.selenium.WebDriver;

import com.V2SS.helpers.FileReaderManager;
import com.baseclass.org.BaseClass;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(features = "src/test/java/com/V2SS/feature", glue = "com/V2SS/Stepdefinition", plugin = {
		"com.cucumber.listener.ExtentCucumberFormatter:Report/extentReport.html", "rerun: ReRun//failedtestcase.txt",
		"json:target//cucumber-reports//CucumberTestReport.json" },

		monochrome = true, dryRun = false, tags = { "@login" })

public class Runnercls extends BaseClass {
	public static WebDriver driver;

	@BeforeClass
	public static void setUp() {

		try {
			String browsername = FileReaderManager.getInstance().getcrinstance().browsername();
			driver = BaseClass.browseropen(browsername);

			Thread.sleep(3000);
			String geturl = FileReaderManager.getInstance().getcrinstance().geturl();
			applaunch(geturl);
			Thread.sleep(4000);

		} catch (Throwable e) {

			e.printStackTrace();
		}

		System.out.println("Browser Launch");

	}
}