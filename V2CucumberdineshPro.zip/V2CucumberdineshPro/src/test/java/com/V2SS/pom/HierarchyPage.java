package com.V2SS.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HierarchyPage {
	
	public static WebDriver driver;

	@FindBy(xpath = "//a[@href='/admin/hierarchy']")
	private WebElement Hierarchy_icon;
	

	@FindBy(xpath = "(//button[@class='ant-btn sc-fzqBZW eNQuho sc-pIUfD qlYhQ ant-btn-circle'])[2]")
	private WebElement CreateTier;
	
	
	@FindBy(xpath = "//input[@id='createTier_tierName']")
	private WebElement TierName;
	
	
	@FindBy(xpath = "//div[@class='ant-select-selection__placeholder']")
	private WebElement Parenttier_Name;
	
	
	@FindBy(xpath = "//button[@class='ant-btn ant-btn-primary']")
	private WebElement CreateTier_Submit;
	
	
	@FindBy(xpath = "//li[text()='account check6']")
	private WebElement Account_check6_dropdown;
	
	@FindBy(xpath = "//input[@id='editTierSettings_newTierName']")
	private WebElement Edit_tiername;
	
	
	@FindBy(xpath = "(//button[@class='ant-btn ant-btn-primary'])[2]")
	private WebElement Edit_Submit;
	

	
	@FindBy(xpath = "//button[@class='ant-btn sc-fzokOt hLgJkJ sc-oUDcU cnVYtu ant-btn-danger ant-btn-background-ghost']")
	private WebElement DeletethisTier_button;
	
	
	@FindBy(xpath = "//button[@class='ant-btn']")
	private WebElement BacktoEDit;
	
	
	@FindBy(xpath = "//button[@class='ant-btn ant-btn-danger']")
	private WebElement DeleteTier;
	
	
	
	@FindBy(xpath = "//div[@class='ant-table-row-expand-icon ant-table-row-collapsed']")
	private WebElement First_Expand;
	
	@FindBy(xpath = "(//div[@class='ant-table-row-expand-icon ant-table-row-collapsed'])[1]")
	private WebElement Second_Expand;
	
	@FindBy(xpath = "//div[@class='ant-table-row-expand-icon ant-table-row-collapsed']")
	private WebElement Third_Expand;
	
	
	@FindBy(xpath = "//li[text()='New York']")
	private WebElement Newyork_tier;
	
	@FindBy(xpath = "//button[@class='ant-btn']")
	private WebElement Maybe_later;
	
	
   @FindBy(xpath = "(//div[@class='ant-select-selection__rendered'])[4]")
   private WebElement EditParent_move;
					

   @FindBy(xpath = "//li[text()='California']")
   private WebElement California_tier;
					
      @FindBy(xpath = "(//button[@class='ant-btn sc-pkHUE fIcDpF ant-btn-link'])[8]")
   private WebElement Tier_Hierarchy8;	
      
     
      @FindBy(xpath = "(//button[@class='ant-btn sc-pkHUE fIcDpF ant-btn-link'])[5]")
     private WebElement Tier_Hierarchy5;			  
	
      
    
      
     @FindBy(xpath = "//button[@id='editTierSettings_enablePublicProfile']")
     private WebElement Enable_publicpages;	
     
     @FindBy(xpath = "//button[@id='editTierSettings_enableAgentProfile']")
     private WebElement Enable_agent_publicprofiles;	
     
     @FindBy(xpath = "//button[@id='editTierSettings_enableHierarchyDisplay']")
     private WebElement Display_hierarchy_publicpages;	
      
  
     @FindBy(xpath = "//button[@id='editTierSettings_enableContactForm']")
     private WebElement Showcontactform_publicpages_true;	
     
   //i[@class='anticon anticon-close ant-select-remove-icon']
     @FindBy(xpath = "(//i[@class='anticon anticon-close ant-select-remove-icon'])[1]")
     private WebElement Agent_close;	
     
     @FindBy(xpath = "//i[@class='anticon anticon-close ant-select-remove-icon']")
     private WebElement Manager_close;	
      
  
      @FindBy(xpath = "(//div[@class='ant-select-selection__rendered'])[5]")
      private WebElement Send_contact_formto_field ;	
      
     
     @FindBy(xpath = "(//li[@class='ant-select-dropdown-menu-item'])[1]")
     private WebElement Add_Manager;	
     
     @FindBy(xpath = "(//li[@class='ant-select-dropdown-menu-item'])[2]")
     private WebElement Add_Agent;
      
      @FindBy(xpath = "//input[@id='editTierSettings_maxDailyPosts']")
      private WebElement Maximum_number_ofpostsper_day_field; 
      
   

      @FindBy(xpath = "//i[@class='anticon anticon-clock-circle ant-time-picker-clock-icon']")
      private WebElement Minimum_gap_between_posts_Close;
      
   
      @FindBy(xpath = "//input[@class='ant-time-picker-input']")
      private WebElement SelectTime_filed;	
    
      @FindBy(xpath = "//li[text()='17']")
      private WebElement SelectTime_Hour_17;	
      
      
     @FindBy(xpath = "(//li[text()='10'])[2]")
      private WebElement SelectTime_Min_10;	
      
    
    		 
     @FindBy(xpath = "(//div[@class='ant-slider-handle'])[1]")
     private WebElement Slide_auto_post_on_social_media;
     
     @FindBy(xpath = "(//div[@class='ant-slider-handle'])[2]")
     private WebElement Slide_survey_completion_emailto_agents;
   
     @FindBy(xpath = "(//div[@role='slider'])[3]")
     private WebElement Slide_survey_completionSMS_agents;
     
     
  

     @FindBy(xpath = "//button[@class='ant-btn sc-fzqBZW eNQuho ant-btn-circle']")
     private WebElement Hierarchy_Filter;
     
   
     @FindBy(xpath = "//input[@placeholder='Search']")
     private WebElement Hierarchy_Search_field;
     
     
     @FindBy(xpath = "(//i[@class='anticon anticon-close'])[2]")
     private WebElement Hierarchy_Search_field_close;
     
   
     @FindBy(xpath = "//div[@class='ant-select-selection__rendered']")
     private WebElement Hierarchy_catagory_field;	
     
   
     @FindBy(xpath = "//li[text()='HQ']")
     private WebElement Catagory_HQ;
     
   
     @FindBy(xpath = "//li[text()='REGION']")
     private WebElement Catagory_REGION;
     
   
     @FindBy(xpath = "//li[text()='BRANCH']")
     private WebElement Catagory_BRANCH;
     
   
     @FindBy(xpath = "//button[@class='ant-btn sc-fzqBZW eNQuho ant-btn-circle']")
     private WebElement Hierarchy_filter_close;
   
   
     @FindBy(xpath = "//li[text()='Show all']")
     private WebElement Catagory_showall;
     
     	
    		 
     @FindBy(xpath = "(//input[@class='ant-checkbox-input'])[1]")
     private WebElement Catagory_column;
     
     
     @FindBy(xpath = "(//input[@class='ant-checkbox-input'])[2]")
     private WebElement Users_column;
     
     @FindBy(xpath = "(//input[@class='ant-checkbox-input'])[3]")
     private WebElement CreatedDate_column;  
     
    		 
	public HierarchyPage (WebDriver hie_driver) {
		this.driver = hie_driver;
		PageFactory.initElements(driver, this);
	}
	
	
	public WebElement getHierarchy_icon() {
		return Hierarchy_icon;

	}
	
	public WebElement getCreateTier() {
		return CreateTier;

	}
	
	public WebElement getTierName() {
		return TierName;

	}
	public WebElement getParenttier_Name() {
		return Parenttier_Name;

	}
	public WebElement getCreateTier_Submit() {
		return CreateTier_Submit;

	}
	public WebElement getEdit_tiername() {
		return Edit_tiername;

	}
	
	public WebElement getEdit_Submit() {
		return Edit_Submit;

	}
	public WebElement getDeletethisTier_button() {
		return DeletethisTier_button;

	}
	
	public WebElement getBacktoEDit() {
		return BacktoEDit;

	}
	
	public WebElement getDeleteTier() {
		return DeleteTier;

	}
	
	public WebElement getFirst_Expand() {
		return First_Expand;

	}
	public WebElement getSecond_Expand() {
		return Second_Expand;

	}
	public WebElement getThird_Expand() {
		return Third_Expand;

	}
	
	public WebElement getNewyork_tier() {
		return Newyork_tier;

	}
	
	public WebElement getMaybe_later() {
		return Maybe_later;

	}
	public WebElement getEditParent_move() {
		return EditParent_move;

	}
	public WebElement getCalifornia_tier() {
		return California_tier;

	}
	
	
	public WebElement getTier_Hierarchy8() {
		return Tier_Hierarchy8;

	}
	
			
	public WebElement getTier_Hierarchy5() {
	return Tier_Hierarchy5;

	}	
	
	public WebElement getEnable_publicpages() {
		return Enable_publicpages;

	}
	
	public WebElement getEnable_agent_publicprofiles() {
		return Enable_agent_publicprofiles;

	}
	
	public WebElement getDisplay_hierarchy_publicpages() {
		return Display_hierarchy_publicpages;

	}
	
	public WebElement getShowcontactform_publicpages_true() {
		return Showcontactform_publicpages_true;

	}
	
	public WebElement getAgent_close() {
		return Agent_close;

	}
	
	public WebElement getManager_close() {
		return  Manager_close;

	}
	
	public WebElement getSend_contact_formto_field () {
		return Send_contact_formto_field ;

	}
	
	public WebElement getAdd_Manager() {
		return Add_Manager;

	}
	
	
	public WebElement getAdd_Agent() {
		return Add_Agent;

	}
	public WebElement getMaximum_number_ofpostsper_day_field() {
		return Maximum_number_ofpostsper_day_field;

	}
	
	public WebElement getMinimum_gap_between_posts_Close() {
		return Minimum_gap_between_posts_Close;

	}
	
	
	public WebElement getSelectTime_filed() {
		return SelectTime_filed;

	}
	
	
	public WebElement getSelectTime_Hour_17() {
		return SelectTime_Hour_17;

	}
	
	public WebElement getSelectTime_Min_10() {
		return SelectTime_Min_10;

	}
	
	
	public WebElement getSlide_auto_post_on_social_media() {
		return Slide_auto_post_on_social_media;

	}
	
	public WebElement getSlide_survey_completion_emailto_agents() {
		return Slide_survey_completion_emailto_agents;

	}
	
	
	public WebElement getSlide_survey_completionSMS_agents() {
		return Slide_survey_completionSMS_agents;

	}
	
	public WebElement getHierarchy_Filter() {
		return Hierarchy_Filter;

	}
	
	public WebElement getHierarchy_Search_field() {
		return Hierarchy_Search_field;

	}
	
	public WebElement getHierarchy_Search_field_close() {
		return Hierarchy_Search_field_close;

	}
	
	public WebElement getHierarchy_catagory_field() {
		return Hierarchy_catagory_field;

	}
	
	public WebElement getCatagory_HQ() {
		return Catagory_HQ;

	}
	
	
	public WebElement getCatagory_REGION() {
		return Catagory_REGION;

	}
	
	
	public WebElement getCatagory_BRANCH() {
		return Catagory_BRANCH;

	}
	
	public WebElement getHierarchy_filter_close() {
		return Hierarchy_filter_close;

	}
	
	
	public WebElement getCatagory_showall() {
		return Catagory_showall;

	}
	
	
	public WebElement getCatagory_column() {
		return Catagory_column;

	}
	
	public WebElement getUsers_column() {
		return Users_column;

	}
	
	public WebElement getCreatedDate_column() {
		return CreatedDate_column;

	}
	
	
	
	
	
	
}
