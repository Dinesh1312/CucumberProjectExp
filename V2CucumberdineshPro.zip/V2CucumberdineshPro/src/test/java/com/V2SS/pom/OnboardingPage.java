package com.V2SS.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class OnboardingPage {

	public static WebDriver driver;
	
	
	
	
	@FindBy(xpath = "//button[@class='ant-btn sc-fzokOt hLgJkJ sc-prPLn bvTLbK']")
	private WebElement Upload_Button;
	

	@FindBy(xpath = "//input[@id='data-test-upload-file']")
	private WebElement Bulk_upload_click;
	
	
	
	@FindBy(xpath = "//button[@class='ant-drawer-close']")
	private WebElement Upload_drawerClose;
	
	@FindBy(xpath = "//button[@class='ant-btn ant-dropdown-trigger ant-btn-icon-only']")
	private WebElement viewdropdown;
	
	
	@FindBy(xpath = "//li[text()='Activate']")
	private WebElement Activated_dropdown;
	
	@FindBy(xpath = "//li[text()='Deactivate']")
	private WebElement Deactivated_dropdown;
	
	
	@FindBy(xpath = "//button[@class='ant-btn ant-btn-primary']")
	private WebElement Sync_to_V1Btn_submit;
	
	
	
	@FindBy(xpath = "//span[text()='Active']")
	private WebElement Active;
	
	
	
			
	@FindBy(xpath = "(//button[@class='ant-btn'])[4]")
	private WebElement Active_confirmation;	
	
	@FindBy(xpath = "//span[text()='Inactive']")
	private WebElement InActive;
	
	

	@FindBy(xpath = "//button[@class='ant-btn sc-qPXtF hdrNyJ']")
	private WebElement Not_sync;
	
	
	
	
	@FindBy(xpath = "(//span[@class='sc-pRsKx jgBPUY'])[1]")
	private WebElement First_Expand;
	
	@FindBy(xpath = "(//span[@class='sc-pRsKx jgBPUY'])[1]")
	private WebElement Second_Expand;
	
	
	@FindBy(xpath = "//span[@class='sc-pRsKx jgBPUY']")
	private WebElement Third_Expand;
	
	
	@FindBy(xpath = "//span[@class='sc-pRsKx jgBPUY']")
	private WebElement Forth_Expand;
	
	
	@FindBy(xpath = "//button[@class='ant-btn sc-paWCZ fYWNyo']")
	private WebElement Users_tab;
	
	
	
	@FindBy(xpath = "//div[text()='Upload Successful! ']")
	private WebElement Upload_successful;
	
	
	@FindBy(xpath = "//li[@class='ant-pagination-item ant-pagination-item-1 ant-pagination-item-active']")
	private WebElement Users_firstPage;
	
	
	
	@FindBy(xpath = "//span[text()='Account created Successfully.']")
	private WebElement Acc_createSucessPopup;
	
	@FindBy(xpath = "//span[@class='sc-pReKu sc-ptdsS jENrvK']")
	private WebElement Synctov1btn;
	
	
	@FindBy(xpath = "//button[@class='ant-btn sc-qPXtF hdrNyJ']")
	private WebElement before_Synctov1btn;
	
	
	@FindBy(xpath = "//button[@class='ant-drawer-close']")
	private WebElement upload_drawerClose;
	
	
	@FindBy(xpath = "//span[@class='ant-typography sc-pAMyN sc-kJoyaE fumNUy']")
	private WebElement Hq_Text;
	
	
	@FindBy(xpath = "//span[@class='ant-typography sc-pAMyN sc-kJoyaE fumNUy']")
	private WebElement Hierarchy_PgTitle;
	
	
	@FindBy(xpath = "//table/tbody/tr[1]/td[2]/span[2]")
	private WebElement Hq_element;
	
	
	@FindBy(xpath = "//table/tbody/tr[2]/td[2]/span[2]")
	private WebElement Region1_element;
	
	
	@FindBy(xpath = "//table/tbody/tr[6]/td[2]/span[2]")
	private WebElement Region2_element;
	
	
	@FindBy(xpath = "//table/tbody/tr[3]/td[2]/span[2]")
	private WebElement Branch1_element;
	
	@FindBy(xpath = "//table/tbody/tr[7]/td[2]/span[2]")
	private WebElement Branch2_element;
	
	
	@FindBy(xpath = "//table/tbody/tr[5]/td/div/div/div/div/div/div[1]/table/tbody/tr[1]/td[1]/span")
	private WebElement User1_element;
	
	

	@FindBy(xpath = "//table/tbody/tr[9]/td/div/div/div/div/div/div[1]/table/tbody/tr/td[1]/span")
	private WebElement User2_element;
	
	
	
	
	@FindBy(xpath = "//table/tbody/tr[4]/td/div/div/div/div/div/div[1]/table/tbody/tr/td[1]/span")
	private WebElement User3_element;
	
	
	
	@FindBy(xpath = "//table/tbody/tr[10]/td/div/div/div/div/div/div[1]/table/tbody/tr/td[1]/span")
	private WebElement User4_element;
	
	
	@FindBy(xpath = "(//button[@class='ant-drawer-close'])[3]")
   private WebElement SyncToV1_drawerclose;
			
	
	
	@FindBy(xpath = "(//i[@class='anticon anticon-close'])[4]")
     private WebElement search_close_Onb;
	
	
	@FindBy(xpath = "(//i[@class='anticon anticon-close'])[6]")
  private WebElement search_close_sup;
	
	public OnboardingPage(WebDriver onb_driver) {
		this.driver = onb_driver;
		PageFactory.initElements(driver, this);
	}
	
	public WebElement getUpload_Button() {
		return Upload_Button;

	}
	
	public WebElement getBulk_upload_click() {
		return Bulk_upload_click;

	}
	
	public WebElement getUpload_drawerClose() {
		return Upload_drawerClose;
	}
		
   public WebElement getviewdropdown() {
	return viewdropdown;

	}
   
   public WebElement getDeactivated_dropdown() {
		return Deactivated_dropdown;

		}
   public WebElement getSync_to_V1Btn_submit() {
		return Sync_to_V1Btn_submit;

		}
   
   public WebElement getActive() {
 		return Active;

 		}
   
   public WebElement getInActive() {
		return InActive;

		}
   
  
   public WebElement getNot_sync() {
		return  Not_sync;

		}
   
   public WebElement getActive_confirmation() {
		return  Active_confirmation;

		}
   
    public WebElement getActivated_dropdown() {
		return  Activated_dropdown;

		}
   public WebElement getFirst_Expand() {
		return  First_Expand;

		}
   
   public WebElement getSecond_Expand() {
		return  Second_Expand;

		}
   
   public WebElement getThird_Expand() {
		return  Third_Expand;

		}
   
   public WebElement getForth_Expand() {
 		return  Forth_Expand;

 		}
   
   
   public WebElement getUsers_tab() {
		return  Users_tab;

		}
   
   
   public WebElement getUsers_firstPage() {
		return  Users_firstPage;

		}
   
   
   public WebElement getUpload_successful() {
		return  Upload_successful;

		}
   
   
   public WebElement getAcc_createSucessPopup() {
		return  Acc_createSucessPopup;

		}
   
   public WebElement getSynctov1btn() {
		return  Synctov1btn;

		}
   
   public WebElement getBefore_Synctov1btn() {
		return  before_Synctov1btn;

		}
   
   public WebElement getupload_drawerClose() {
		return  upload_drawerClose;

		}
 
   public WebElement getHq_Text() {
		return  Hq_Text;

		}
   
   public WebElement getHierarchy_PgTitle() {
		return  Hierarchy_PgTitle;

		}
   
   public WebElement getHq_element() {
 		return  Hq_element;

 		}
   
   public WebElement getRegion1_element() {
		return  Region1_element;

		}
   public WebElement getRegion2_element() {
		return  Region2_element;

		}
  
   public WebElement getBranch1_element() {
		return   Branch1_element;

		}
   public WebElement getBranch2_element() {
		return   Branch2_element;

		}
   
   
   public WebElement getUser1_element() {
		return   User1_element;

		}
   public WebElement getUser2_element() {
		return   User2_element;

		}
   
   public WebElement getUser3_element() {
		return   User3_element;

		}
   
   public WebElement getUser4_element() {
		return   User4_element;

		}
   
   public WebElement getSyncToV1_drawerclose() {
		return  SyncToV1_drawerclose;

		}
   
   public WebElement getsearch_close_Onb() {
		return  search_close_Onb;

		}
   
   public WebElement getsearch_close_sup() {
		return  search_close_sup;

		}
   
}
