package com.V2SS.pom;

import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/*
 * -----------locators for Accounts page--------------- 
 * created on: 05-05-2020
 * created by: Dineshkumar 
 * last modification:10-6-2020 by Dinesh kumar
 * 
 */

public class AccountPage {

	public static WebDriver driver;

	@FindBy(xpath = "//li[@path='/admin/accounts']")
	private WebElement accounts_icon;

	@FindBy(xpath = "//span[@data-test-nav-logo='true']")
	private WebElement ssicon;
	
	
	@FindBy(xpath = "//div[@class='sc-kcAMUC BviJU']")
	private WebElement Expanded_ssicon;
	
	@FindBy(xpath = "//a[text()='All Organizations']")
	private WebElement ssicon_allorganization;

	@FindBy(xpath = "//a[contains(text(),'Logout')]")
	private WebElement ssicon_logout;

	@FindBy(xpath = "//li[@path='/admin/accounts']")
	private WebElement accounts_tab;

	@FindBy(xpath = "//button[@class='ant-btn sc-fzpdyU dfmoXX ant-btn-round']")
	private WebElement all_accounts;

	@FindBy(xpath = "/html/body/div[1]/div[2]/div[2]/div[2]/div[1]/div[2]/div/button[1]")
	private WebElement my_accounts;

	@FindBy(xpath = "//button[@class='ant-btn sc-fzqBZW eNQuho ant-btn-circle']")
	private WebElement search_icon;
	
	@FindBy(xpath = "//input[@class='ant-input sc-fznNTe jQCbOp']")
	private WebElement searchaccount;

	@FindBy(xpath = "//div[text()='New Account']")
	private WebElement new_account;

	@FindBy(xpath = "(//button[@class='ant-btn'])[2]")
	private WebElement view1;

	@FindBy(xpath = "//button[@class='ant-btn ant-dropdown-trigger ant-btn-icon-only']")
	private WebElement viewdropdown;

	@FindBy(xpath = "//li[text()='Assign Admin']")
	private WebElement Assignadmin;

	@FindBy(xpath = "//div[text()='Please select admins']")
	private WebElement Selectadmin;

	@FindBy(xpath = "//li[text()='Dinesh Kumar']")
	private WebElement dinesh_dropdown_admin;

	@FindBy(xpath = "//button[@class='ant-btn ant-btn-primary']")
	private WebElement Assignbtn;
	
	@FindBy(xpath = "(//i[@class='anticon anticon-close'])[5]")
	private WebElement searchclose;

	@FindBy(xpath = "//input[@id='NewAccount_name']")
	private WebElement PrimaryAccount;

	@FindBy(xpath = "//div[text()='Submit']")
	private WebElement submit_newacc;

	@FindBy(xpath = "(//div[@class='ant-select-selection__rendered'])[4]")
	private WebElement OnboardingOwners;

	@FindBy(xpath = "(//button[@class='ant-drawer-close'])[1]")
	private WebElement newaccPage_close;

	@FindBy(xpath = "/html/body/div[1]/div[2]/div[2]/div[2]/div[2]/div/div/div[2]/div/div/div[2]/div/form/div[2]/div[2]/div/span/div/div/div")
	private WebElement selectbusinesscategory;

	@FindBy(xpath = "(//div[@class='ant-select-selection__rendered'])[3]")
	private WebElement selectOrganization;

	
	@FindBy(xpath = "(//div[@class='ant-select-selection__rendered'])[2]")
	private WebElement selectblueprint;
	
	@FindBy(xpath = "//li[text()='Default Blueprint']")
	private WebElement add_defaultBluePrint;

	@FindBy(xpath = "//li[@data-test-new-account-create-new-organization-button='true']")
	private WebElement createNewOrg;

	@FindBy(xpath = "//input[@id='NewAccount_org_name']")
	private WebElement EnternewOrg;
	
	@FindBy(xpath = "//input[@id='NewAccount_contact_name']")
	private WebElement EnternewOrg_ContactName;
	
	
	@FindBy(xpath = "//input[@id='NewAccount_contact_email']")
	private WebElement EnternewOrg_ContactEmail;
	
	
	@FindBy(xpath = "//input[@id='NewAccount_contact_number']")
	private WebElement EnternewOrg_ContactNumber;
	
	
	@FindBy(xpath = "(//div[@class='ant-select-selection__rendered'])[3]")
	private WebElement EnternewOrg_OnboardingOwner;		
	
	//div[7]/div/div/div/ul/li[4]
	@FindBy(xpath = "//li[@data-test-new-account-onboarding-owner='21']")
	private WebElement OnboardingOwner_onboardingadmin;

	@FindBy(xpath = "//li[@data-test-new-account-onboarding-owner='15']")
	private WebElement OnboardingOwner_dinesh;

	@FindBy(xpath = "//li[text()='Mortgage']")
	private WebElement Business_catagory_mortgage;

	@FindBy(xpath = "//li[text()='Real Estate']")
	private WebElement Business_catagory_RealEstate;

	@FindBy(xpath = "//li[text()='Automation Qa Team']")
	private WebElement add_Org_QAteamOrganization;
	
	
	@FindBy(xpath = "//li[text()='Admin Organization']")
	private WebElement add_Org_AutomationQaTeam;
	
	@FindBy(xpath = "(//button[@class='ant-btn'])[1]")
	private WebElement Add_New_Manager;
	
	
	@FindBy(xpath = "//input[@id='NewAccount_organization_first_name']")
	private WebElement Manager_firstname;
	
	@FindBy(xpath = "//input[@id='NewAccount_organization_last_name']")
	private WebElement Manager_lastname;
	
	@FindBy(xpath = "//input[@id='NewAccount_organization_email']")
	private WebElement Manager_email;
	
	@FindBy(xpath = "//li[text()='Assign Manager']")
	private WebElement Assign_Manager_DropDown;
	
	
	
	@FindBy(xpath = "//div[text()='Please select user']")
	private WebElement AssignManagerDD_field;
	
	
	@FindBy(xpath = "//li[text()='nithin kumar']")
	private WebElement Nithin_Manager;
	
	
	@FindBy(xpath = "//li[text()='Edit Account']")
	private WebElement Edit_Account_Dropdown;
	
	
	
	@FindBy(xpath = "//input[@id='EditAccount_name']")
	private WebElement EditAccount_Name;
	
	
	
	@FindBy(xpath = "(//div[@class='ant-select-selection__rendered'])[4]")
     private WebElement Edit_BusinessCatagory ;
			
	
	@FindBy(xpath = "(//li[text()='Accounting'])[2]")
	private WebElement EditBusiness_catagory_accounting;		
			
	
	
	@FindBy(xpath = "(//div[text()='Submit'])[2]")
	private WebElement  Edit_submit;
	
	
	
	
	public AccountPage(WebDriver accdriver) {
		this.driver = accdriver;
		PageFactory.initElements(driver, this);
	}

	public WebElement getaccounts_icon() {
		return accounts_icon;

	}

	public WebElement getssicon() {
		return ssicon;

	}

	
	public WebElement getExpanded_ssicon() {
		return Expanded_ssicon;

	}
	public WebElement getSsicon_allorganization() {
		return ssicon_allorganization;

	}

	public WebElement getSsicon_Logout() {
		return ssicon_logout;

	}

	public WebElement getAll_Accounts() {
		return all_accounts;

	}

	public WebElement getMy_Accounts() {
		return my_accounts;

	}

	public WebElement getSearch_Icon() {
		return search_icon;

	}

	public WebElement getAccounts_Tab() {
		return accounts_tab;

	}

	public WebElement getSearch_Account() {
		return searchaccount;

	}

	public WebElement getNew_Account() {
		return new_account;

	}

	public WebElement getView() {
		return view1;

	}

	public WebElement getViewdropdown() {
		return viewdropdown;

	}

	public WebElement getAssignadmin() {
		return Assignadmin;

	}

	public WebElement getSelectadmin() {
		return Selectadmin;

	}

	public WebElement getAssignbtn() {
		return Assignbtn;

	}

	public WebElement getSearchclose() {
		return searchclose;

	}

	public WebElement getDinesh_dropdown_admin() {
		return dinesh_dropdown_admin;

	}

	public WebElement getPrimaryaccount() {
		return PrimaryAccount;

	}

	public WebElement getSubmit_newacc() {
		return submit_newacc;

	}

	public WebElement getOnboardingOwners() {
		return OnboardingOwners;

	}

	public WebElement getNewaccPage_close() {
		return newaccPage_close;

	}

	public WebElement getSelectBusiness_catogory() {
		return selectbusinesscategory;

	}
	
	public WebElement getselectblueprint() {
		return selectblueprint;

	}
	
	public WebElement getadd_defaultBluePrint() {
		return add_defaultBluePrint;

	}

	public WebElement getSelectOrganization() {
		return selectOrganization;

	}

	public WebElement getCreateNewOrg() {
		return createNewOrg;

	}

	public WebElement getEnternewOrg() {
		return EnternewOrg;

	}
	
	public WebElement getEnternewOrg_ContactName() {
		return EnternewOrg_ContactName;

	}
	
	public WebElement getEnternewOrg_ContactEmail() {
		return EnternewOrg_ContactEmail;

	}
	
	public WebElement getEnternewOrg_ContactNumber() {
		return EnternewOrg_ContactNumber;

	}
	
	public WebElement getEnternewOrg_OnboardingOwner() {
		return EnternewOrg_OnboardingOwner;

	}
	

	public WebElement getOnboardingOwner_onboardingadmin() {
		return OnboardingOwner_onboardingadmin;

	}

	public WebElement getOnboardingOwner_dinesh() {
		return OnboardingOwner_dinesh;

	}

	public WebElement getBusinessCatagory_Mortagage() {
		return Business_catagory_mortgage;

	}

	public WebElement getBusinessCatagory_RealEstate() {
		return Business_catagory_RealEstate;

	}

	public WebElement getAdd_Org_QAteamOrganization() {
		return add_Org_QAteamOrganization;

	}
	
	 

		public WebElement getAdd_New_Manager() {
			return Add_New_Manager;

		}
		
		public WebElement getManager_firstname() {
			return Manager_firstname;

		}
		
		
		public WebElement geManager_lastname() {
			return Manager_lastname;

		}
		
		
		public WebElement getManager_email() {
			return Manager_email;

		}
		
		
		public WebElement getadd_Org_AutomationQaTeam() {
			return add_Org_AutomationQaTeam;

		}
		
		public WebElement getAssign_Manager_DropDown() {
			return Assign_Manager_DropDown;

		}
		
		public WebElement getAssignManagerDD_field() {
			return AssignManagerDD_field;

		}
		
		public WebElement getNithin_Manager() {
			return Nithin_Manager;

		}
		
		public WebElement getEdit_Account_Dropdown() {
			return Edit_Account_Dropdown;

		}
		
		public WebElement getEditAccount_Name() {
			return EditAccount_Name;

		}
		

		public WebElement getEdit_BusinessCatagory() {
			return Edit_BusinessCatagory;

		}
		
		public WebElement getEditBusiness_catagory_accounting() {
			return EditBusiness_catagory_accounting;

		}
		
		public WebElement getEdit_submit() {
			return Edit_submit;

		}
}
