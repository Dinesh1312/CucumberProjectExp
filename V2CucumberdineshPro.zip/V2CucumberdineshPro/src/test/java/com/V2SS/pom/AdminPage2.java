package com.V2SS.pom;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/*
 * -----------locators for Admin page--------------- 
 * created on: 09-05-2020
 * created by: Dineshkumar 
 * last modification:17-6-2020 by Dinesh kumar
 * 
 */
public class AdminPage2 {

	

	public static WebDriver driver;

	@FindBy(xpath = "(//i[@class='anticon anticon-close'])[3]")
	private WebElement adminicon;

	@FindBy(xpath = "(//a[@class='ant-pagination-item-link'])[2]")
	private WebElement arrow;
	
	@FindBy(xpath = "//li[@title='1']")
	private WebElement firstpage;
	
	@FindBy(xpath = "//a[text()='2']")
	private WebElement secondpage;

	@FindBy(xpath = "(//a[@class='ant-pagination-item-link'])[1]")
	private WebElement previouspage;
	
	
	@FindBy(xpath = "(//a[@class='ant-pagination-item-link'])[2]")
	private WebElement LastArrow;	
	
	
	@FindBy(xpath = "//a[text()='34']")
	private WebElement Lastpage;

	@FindBy(xpath = "(//button[@class='ant-btn sc-fzqBZW eNQuho ant-btn-circle'])[1]")
	private WebElement searchbutton1;

	@FindBy(xpath = "(//input[@type='text'])[1]")
	private WebElement enteradmin1;

	@FindBy(xpath = "//body//td[5]//*[local-name()='svg']")
	private WebElement pencilicon1;

	@FindBy(xpath = "//div[contains(text(),'Submit')]")
	private WebElement submitbutton1;

	@FindBy(xpath = "(//input[@type='text'])[1]")
	private WebElement clearadmin;

	@FindBy(xpath = "(//input[@type='text'])[1]")
	private WebElement enter_admin;

	@FindBy(xpath = "//body//td[5]//*[local-name()='svg']")
	private WebElement pencil_icon;
	
	
	@FindBy(xpath = "//input[@name='email']")
	private WebElement email_field;


	@FindBy(xpath = "//input[@name='first_name']")
	private WebElement edit_firstname;

	@FindBy(xpath = "//input[@name='first_name']")
	private WebElement add_firstname;

	@FindBy(xpath = "//input[@name='last_name']")
	private WebElement edit_lastname;

	@FindBy(xpath = "//input[@name='last_name']")
	private WebElement add_lastname;

	@FindBy(xpath = "//span[@class='ant-switch-inner']")
	private WebElement inactive_admintoggle;

	@FindBy(xpath = "//span[@class='ant-switch-inner']")
	private WebElement active_admintoggle;

	@FindBy(xpath = "//div[text()='Please select']")
	private WebElement click_group;

	@FindBy(xpath = "//li[text()='Customer Support']")
	private WebElement add_group_cus_support;

	@FindBy(xpath = "(//li[@class='ant-select-dropdown-menu-item ant-select-dropdown-menu-item-active'])[1]")
	private WebElement add_group_onboarding;

	@FindBy(xpath = "//div[text()='Please select']")
	private WebElement add_group_field;

	@FindBy(xpath = "//i[@class='anticon anticon-close ant-select-remove-icon']")
	private WebElement delete_group;

	@FindBy(xpath = "(//div[@class='ant-select-selection__rendered'])[3]")
	private WebElement click_organization;

	@FindBy(xpath = "//li[text()='Default']")
	private WebElement add_organization;

	@FindBy(xpath = "//li[text()='Social Survey ']")
	private WebElement add_socialsurvey_org;
	
	
	@FindBy(xpath = "//li[text()='new-test-org ']")
	private WebElement add_newtestorg;
	
	@FindBy(xpath = "//i[@class='anticon anticon-close sc-khlcQO jnMmUs']")
	private WebElement delete_organization;

	@FindBy(xpath = "//div[text()='Submit']")
	private WebElement submitbtbn;

	@FindBy(xpath = "//div[text()='Create New Admin']")
	private WebElement createnewadmin_icon;

	@FindBy(xpath = "//input[@id='AdminForm_email']")
	private WebElement create_emailid;

	@FindBy(xpath = "//input[@id='AdminForm_first_name']")
	private WebElement create_firstname;

	@FindBy(xpath = "//input[@id='AdminForm_last_name']")
	private WebElement create_lastname;

	@FindBy(xpath = "//input[@class='ant-select-search__field']")
	private WebElement click_newgroup;

	@FindBy(xpath = "//li[@class='ant-select-dropdown-menu-item ant-select-dropdown-menu-item-active']")
	private WebElement add_newgroup;
	

	@FindBy(xpath = "html/body/div[6]/div/div/div/ul/li[3]")
	private WebElement Add_salesgroup;
	
	@FindBy(xpath = "(//div[@class='ant-select-selection__rendered'])[3]")
	private WebElement click_neworganization;

	@FindBy(xpath = "(//div[@class='ant-select-selection__rendered'])[3]")
	private WebElement sendkey_neworganization;

	@FindBy(xpath = "//li[text()='new org']")
	private WebElement add_neworganization_newOrg;
	//li[text()='Automation Qa Team']
	
	@FindBy(xpath = "//li[@account_name='Admin Organization']")
	private WebElement add_neworganization_automationQA;
	
	

	@FindBy(xpath = "//div[text()='Submit']")
	private WebElement submitbtn_last;

	@FindBy(xpath = "//button[@class='ant-btn sc-fzqBZW eNQuho ant-btn-circle']")
	private WebElement search_iconlast;

	@FindBy(xpath = "//input[@type='text']")
	private WebElement enter_newadmin;

	@FindBy(xpath = "//input[@id='AdminForm_email']")
	private WebElement createexisting_emailid;

	@FindBy(xpath = "//input[@id='AdminForm_first_name']")
	private WebElement create_firstnameexist;

	@FindBy(xpath = "//input[@id='AdminForm_last_name']")
	private WebElement create_lastnameexist;

	@FindBy(xpath = "//div[contains(text(),'Submit')]")
	private WebElement submitbtn_exist;
	
	@FindBy(xpath = "//button[@class='ant-drawer-close']")
	private WebElement closepage_ext_emailid;
	
	@FindBy(xpath = "//button[@class='ant-drawer-close']")
	private WebElement closepage_validate_emailid;
	
	
	@FindBy(xpath = "(//button[@class='ant-btn sc-fzqBZW eNQuho ant-btn-circle'])[2]")
	private WebElement Filter_Organization;
	
	
	@FindBy(xpath = "//div[@class='ant-select-selection__rendered']")
	private WebElement Filter_searchfield;
	
	@FindBy(xpath = "//li[text()='Onboarding Group']")
	private WebElement Filter_OnboardingGroup;
	
	
	@FindBy(xpath = "//li[text()='Customer Support']")
	private WebElement Filter_CustomersupportGroup;
	
	
	@FindBy(xpath = "//li[text()='Sales Group']")
	private WebElement Filter_SalesGroup;
	
	//li[@class='ant-select-dropdown-menu-item'][1]
	
	@FindBy(xpath = "(//i[@class='anticon anticon-down ant-select-arrow-icon'])[1]")
	private WebElement Filter_Org_GroupClose;
	
	
	@FindBy(xpath = "(//span[@class='ant-radio-inner'])[1]")
	private WebElement Radio_AllAdmins;	
	
	@FindBy(xpath = "(//span[@class='ant-radio-inner'])[2]")
	private WebElement Radio_ActiveAdmins;	
	
	@FindBy(xpath = "(//span[@class='ant-radio-inner'])[3]")
	private WebElement Radio_DeactivedAdmins;	
	
	
	@FindBy(xpath = "(//button[@class='ant-btn sc-fzqBZW eNQuho ant-btn-circle'])[2]")
	private WebElement Filter_close;			
	
	@FindBy(xpath = "(//i[@class='anticon anticon-caret-up ant-table-column-sorter-up off'])[1]")
	private WebElement Namesort_Uparrow;
	
	
	@FindBy(xpath = "(//i[@class='anticon anticon-caret-down ant-table-column-sorter-down off'])[1]")
	private WebElement Namesort_Downarrow;		
	
	@FindBy(xpath = "(//i[@class='anticon anticon-caret-up ant-table-column-sorter-up off'])[2]")
	private WebElement Orgsort_Uparrow;
	

	@FindBy(xpath = "(//i[@class='anticon anticon-caret-down ant-table-column-sorter-down off'])[2]")
	private WebElement Orgsort_Downarrow;
	
	
	@FindBy(xpath = "(//i[@class='anticon anticon-caret-up ant-table-column-sorter-up off'])[3]")
	private WebElement Statussort_Uparrow;
	
	@FindBy(xpath = "(//i[@class='anticon anticon-caret-down ant-table-column-sorter-down off'])[3]")
	private WebElement Statussort_Downarrow;
	
	
	@FindBy(xpath = "//button[@class='ant-btn ant-btn-primary ant-btn-sm']")
	private WebElement inactive_OKbtn;			
	
	
	@FindBy(xpath = "//button[@class='ant-btn ant-btn-primary ant-btn-sm']")
	private WebElement active_OKbtn;
	
	
	
	@FindBy(xpath = "(//i[@class='anticon anticon-close'])[6]")
	private WebElement search_fieldClose;
	
	
	@FindBy(xpath = "//span[text()='Active']")
	private WebElement ActiveStatus;

	
	@FindBy(xpath = "//span[text()='Inactive']")
	private WebElement InActiveStatus;
	
	
	@FindBy(xpath = "//span[text()='0']")
	private WebElement OrgCount_0;

	
	@FindBy(xpath = "//span[text()='1']")
	private WebElement OrgCount_1;
	
	
	@FindBy(xpath = "//a[@class='sc-fzoVTD Atfvz']")
	private WebElement Onboarding_Nav;
	
			
	public AdminPage2(WebDriver adriver) {
		this.driver = adriver;
		PageFactory.initElements(driver, this);
	}

	public WebElement getAdminicon() {
		return adminicon;

	}

	public WebElement getArrow() {
		return arrow;

	}

	public WebElement getsecondpage() {
		return secondpage;

	}
	
	
	
	public WebElement getfirstpage() {
		return firstpage;

	}

	public WebElement getPreviouspage() {
		return previouspage;

	}
	
	
	
	public WebElement getLastArrow() {
		return LastArrow;

	}
	
	
	public WebElement getLastpage() {
		return Lastpage;

	}

	public WebElement getSearchbutton1() {
		return searchbutton1;

	}

	public WebElement getEnteradmin1() {
		return enteradmin1;

	}

	public WebElement getPencilicon1() {
		return pencilicon1;

	}

	public WebElement getSubmitbutton1() {
		return submitbutton1;

	}

	public WebElement getClearadmin() {
		return clearadmin;

	}

	public WebElement getEnteradmin() {
		return enter_admin;

	}

	public WebElement getPencilicon() {
		return pencil_icon;

	}

	
	public WebElement getemail_field() {
		return email_field;

	}
	public WebElement getEditfirstname() {
		return edit_firstname;

	}

	public WebElement getAddfirstname() {
		return add_firstname;

	}

	public WebElement getEditlastname() {
		return edit_lastname;

	}

	public WebElement getAddlastname() {
		return add_lastname;

	}

	public WebElement getInactivetoggle() {
		return inactive_admintoggle;

	}

	public WebElement getActivetoggle() {
		return active_admintoggle;

	}

	public WebElement getSubmitbtbn() {
		return submitbtbn;

	}

	public WebElement getClickgroup() {
		return click_group;

	}

	public WebElement getAddgroup_cus_support() {
		return add_group_cus_support;

	}

	public WebElement getAddgroup_onboarding() {
		return add_group_onboarding;

	}
	
	public WebElement getAdd_salesgroup() {
		return Add_salesgroup;

	}

	public WebElement getAddgroup_field() {
		return add_group_field;

	}

	public WebElement getDeletegroup() {
		return delete_group;

	}

	public WebElement getClickorganization() {
		return click_organization;

	}

	public WebElement getAddorganization() {
		return add_organization;

	}

	public WebElement getSocialsurvey_Org() {
		return add_socialsurvey_org;

	}
	
	public WebElement getnewtestorg() {
		return add_newtestorg;

	}

	public WebElement getDeleteorganization() {
		return delete_organization;

	}

	public WebElement getCreatenewadminicon() {
		return createnewadmin_icon;

	}

	public WebElement getCreateemailid() {
		return create_emailid;

	}

	public WebElement getCreatefirstname() {
		return create_firstname;

	}

	public WebElement getCreatelastname() {
		return create_lastname;

	}

	public WebElement getClicknewgroup() {
		return click_newgroup;

	}

	public WebElement getAddnewgroup() {
		return add_newgroup;

	}

	public WebElement getClickneworganization() {
		return click_neworganization;

	}

	public WebElement getSendkeyneworganization() {
		return sendkey_neworganization;

	}

	public WebElement getAddneworganization_newOrg() {
		return add_neworganization_newOrg;

	}
	
	
	public WebElement getAdd_neworganization_automationQA() {
		return add_neworganization_automationQA;

	}

	public WebElement getSubmitbtnlast() {
		return submitbtn_last;

	}

	public WebElement getSearchiconlast() {
		return search_iconlast;

	}

	public WebElement getEnternewadmin() {
		return enter_newadmin;

	}

	public WebElement getCreateexistingemailid() {
		return createexisting_emailid;

	}

	public WebElement getCreatefirstnameexist() {
		return create_firstnameexist;

	}

	public WebElement getCreatelastnameexist() {
		return create_lastnameexist;

	}

	public WebElement getSubmitbuttonexist() {
		return submitbtn_exist;

	}
	public WebElement getClosepage_ext_emailid() {
		return closepage_ext_emailid;

	}
	
	
	public WebElement getclosepage_validate_emailid() {
		return closepage_validate_emailid;

	}
	
	public WebElement getFilter_Organization() {
		return Filter_Organization;

	}
	
	public WebElement getFilter_searchfield() {
		return Filter_searchfield;

	}
	
	public WebElement getFilter_OnboardingGroup() {
		return Filter_OnboardingGroup;

	}
	
	
	
	public WebElement getFilter_CustomersupportGroup() {
		return Filter_CustomersupportGroup;

	}
	
	public WebElement getFilter_SalesGroup() {
		return Filter_SalesGroup;

	}
	
	
	
	public WebElement getFilter_Org_GroupClose() {
		return Filter_Org_GroupClose;

	}
	public WebElement getRadio_AllAdmins() {
		return Radio_AllAdmins;

	}
	public WebElement getRadio_ActiveAdmins() {
		return Radio_ActiveAdmins;

	}
	
	public WebElement getRadio_DeactivedAdmins() {
		return Radio_DeactivedAdmins;

	}
	
	public WebElement getFilter_close() {
		return Filter_close;

	}
	
	
	public WebElement getNamesort_Uparrow() {
		return Namesort_Uparrow;

	}
	
	public WebElement getNamesort_Downarrow() {
		return Namesort_Downarrow;

	}
	
	public WebElement getOrgsort_Uparrow() {
		return Orgsort_Uparrow;

	}
	public WebElement getOrgsort_Downarrow() {
		return Orgsort_Downarrow;

	}
	
	public WebElement getStatussort_Uparrow() {
		return Statussort_Uparrow;

	}
	public WebElement getStatussort_Downarrow() {
		return Statussort_Downarrow;

	}
	
	public WebElement getinactive_OKbtn() {
		return inactive_OKbtn;

	}
	
	public WebElement getactive_OKbtn() {
		return active_OKbtn;

	}
	
	 
	 
	 public WebElement getsearch_fieldClose() {
			return search_fieldClose;

		}
	 
	 
	 
	 public WebElement getActiveStatus() {
			List<WebElement> Activestatus = driver.findElements(By.xpath("//span[text()='Active']"));
			return ActiveStatus;
 
 
 
		}
	 
	 public WebElement getInActiveStatus() {
			return InActiveStatus;

		}
	 
	 
	 public WebElement getOrgCount_0() {
			return OrgCount_0;

		}
	 
	 
	 public WebElement getOrgCount_1() {
			return OrgCount_1;

		}
	
	 
	 public WebElement getOnboarding_Nav() {
			return  Onboarding_Nav;

		}
	 
	
	
	
	
	
	

}