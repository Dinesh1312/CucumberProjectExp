package com.V2SS.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class OnboardingAdminLogin {

	
	public static WebDriver driver;
	
	
	@FindBy(xpath = "/html/body/div/div[2]/div/div[2]/a/button")
	private WebElement icon2;
	
	
	@FindBy(xpath = "(//i[@class='anticon anticon-close'])[4]")
		private WebElement Onb_SearchClose;
	
	@FindBy(xpath = "//input[@id='identifierId']")
	private WebElement mail;

	@FindBy(xpath = "(//div[@class='VfPpkd-RLmnJb'])[1]")
	private WebElement nxtbtn;

	@FindBy(xpath = "//input[@name='password']")
	private WebElement password;

	@FindBy(xpath = "(//div[@class='VfPpkd-RLmnJb'])[1]")
	private WebElement passbtn;


	public OnboardingAdminLogin(WebDriver OnbAd_ldriver) {
		this.driver = OnbAd_ldriver;
		PageFactory.initElements(driver, this);
	}

	public WebElement getIcon2() {
		return icon2;

	}

	public WebElement getMail() {
		return mail;

	}

	public WebElement getNxtbtn() {
		return nxtbtn;

	}

	public WebElement getPassword() {
		return password;

	}

	public WebElement getPassbtn() {
		return passbtn;

	}
	
	public WebElement getOnb_SearchClose() {
		return Onb_SearchClose;

	}

}

	
	

