package com.V2SS.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AdmingroupPage {

	public static WebDriver driver;
	
	
	@FindBy(xpath = "(//a)[1]")
	private WebElement Tab_EnlargeIcon;
	
	@FindBy(xpath = "(//i[@class='anticon anticon-close'])[4]")
	private WebElement AdminGroupIcon;
	
	@FindBy(xpath = "//span[text()='Admin Groups']")
	private WebElement AdminGroup_Page;
	
	
	@FindBy(xpath = "(//span[text()='Members'])[1]")
	private WebElement Members_List;
	
	
	@FindBy(xpath = "(//a[@class='ant-pagination-item-link'])[2]")
	private WebElement Pg_NextPg_Arrow;
	
	
	@FindBy(xpath = "(//a[@class='ant-pagination-item-link'])[1]")
	private WebElement Pg_PreviousPg_Arrow;
	
	
	@FindBy(xpath = "//a[text()='9']")
	private WebElement LastPg;
	
	
	@FindBy(xpath = "//a[text()='1']")
	private WebElement FirstPg_Arrow;
	
	
	@FindBy(xpath = "//button[@class='ant-drawer-close']")
	private WebElement AdminList_Close;
	
	
	@FindBy(xpath = "//div[@data-test-admin-group-edit-btn='Onboarding Group']")
	private WebElement Onboarding_EditPencil;
	
	
	@FindBy(xpath = "//input[@id='EditGroup_groupName']")
	private WebElement Onboarding_groupName;
	
	
	@FindBy(xpath = "//textarea[@type='text']")
	private WebElement Text_area;
	
	
	
	@FindBy(xpath = "//div[@role='combobox']")
	private WebElement Admin_comboboxField;
	
	
	
	@FindBy(xpath = "//li[text()='anton waugh']")
	private WebElement AntonWaugh_Admin;
	
	
	
	@FindBy(xpath = "//div[text()='Submit']")
	private WebElement EditOnb_Group_Submit;
	
	

	@FindBy(xpath = "//button[@id='EditGroup_autoColor']")
	private WebElement Colour_toggle;
	
	
	@FindBy(xpath = "//i[@data-test-remove-admin='84']")
	private WebElement Anton_waugh_delete;
	
	
	public AdmingroupPage(WebDriver ad_gdriver) {
		this.driver = ad_gdriver;
		PageFactory.initElements(driver, this);
	}
	
	
	public WebElement getTab_EnlargeIcon() {
		return Tab_EnlargeIcon;

	}
	
	public WebElement getAdminGroupIcon() {
		return AdminGroupIcon;

	}
	
	
	public WebElement getAdminGroup_Page() {
		return AdminGroup_Page;

	}
	
	
	public WebElement getMembers_List() {
		return Members_List;

	}
	
	
	public WebElement getPg_NextPg_Arrow() {
		return Pg_NextPg_Arrow;

	}
	
	
	
	public WebElement getPg_PreviousPg_Arrow() {
		return Pg_PreviousPg_Arrow;

	}
	
	
	public WebElement getLastPg() {
		return LastPg;

	}
	
	
	public WebElement getFirstPg_Arrow() {
		return FirstPg_Arrow;

	}
	
	public WebElement getAdminList_Close() {
		return AdminList_Close;

	}
	
	
	public WebElement getOnboarding_EditPencil() {
		return Onboarding_EditPencil;

	}
	
	
	public WebElement getOnboarding_groupName() {
		return Onboarding_groupName;

	}
	
	
	public WebElement getText_area() {
		return Text_area;

	}
	
	
	public WebElement getAdmin_comboboxField() {
		return Admin_comboboxField;

	}
	
	
	public WebElement getAntonWaugh_Admin() {
		return AntonWaugh_Admin;

	}
	
	public WebElement getEditOnb_Group_Submit() {
		return EditOnb_Group_Submit;

	}
	
	
	public WebElement getAnton_waugh_delete() {
		return Anton_waugh_delete;

	}
	
	
	public WebElement getColour_toggle() {
		return Colour_toggle;

	}
	
}
