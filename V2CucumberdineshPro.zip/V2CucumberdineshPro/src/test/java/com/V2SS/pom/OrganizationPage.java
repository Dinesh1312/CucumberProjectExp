package com.V2SS.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class OrganizationPage {

	
	public static WebDriver driver;

	@FindBy(xpath = "//a[@href='/admin/organizations/list']")
	private WebElement Organization_icon;
	
	@FindBy(xpath = "(//a[@class='ant-pagination-item-link'])[3]")
	private WebElement Nextpage_Arrow;
	
	@FindBy(xpath = "//a[text()='14']")
	private WebElement LastPage;
	
	@FindBy(xpath = "(//a[@class='ant-pagination-item-link'])[1]")
	private WebElement Previouspage;
	
	@FindBy(xpath = "//a[text()='1']")
	private WebElement Firstpage;
	
	@FindBy(xpath = "//button[@class='ant-btn sc-fzqBZW eNQuho ant-btn-circle']")
	private WebElement Organization_searchIcon;
	
	@FindBy(xpath = "//input[@class='ant-input sc-fzoCCn ibPYJZ']")
	private WebElement Org_searchField;
	
	@FindBy(xpath = "(//*[name()='svg'])[20]")
	private WebElement PencilIcon_Org;
	
	@FindBy(xpath = "//input[@name='org_name']")
	private WebElement Organization_Name;
	
	@FindBy(xpath = "//input[@name='contact_name']")
	private WebElement Contact_Name_Org;
	
	@FindBy(xpath = "//input[@name='contact_number']")
	private WebElement Contact_Number_Org;
	
	@FindBy(xpath = "//input[@name='contact_email']")
	private WebElement Contact_Email_Org;
	
	
	@FindBy(xpath = "//div[2]/div[1]/div/button")
	private WebElement Org_deactivation_toggle;
	
	
	@FindBy(xpath = "//div[2]/div[1]/div/button")
	private WebElement Org_activation_toggle;

	@FindBy(xpath = "//button[@class='ant-btn sc-fzokOt hLgJkJ ant-btn-primary']")
	private WebElement Submit_Org;
	
	
	@FindBy(xpath = "(//a[text()='1'])[2]")
	private WebElement Firstpage_inner_orgedit;
	
	

	@FindBy(xpath = "//div[text()='Qa22nddemo']")
	private WebElement Navigating_account;
	
	
	@FindBy(xpath = "//div[text()='New Organization']")
	private WebElement New_Organization;
	
	
	
	@FindBy(xpath = "//i[@class='anticon anticon-close']")
    private WebElement Search_fieldClose;
	

	@FindBy(xpath = "(//i[@class='anticon anticon-caret-up ant-table-column-sorter-up off'])[1]")
	private WebElement OrgNamesort_Uparrow;
	
	@FindBy(xpath = "(//i[@class='anticon anticon-caret-down ant-table-column-sorter-down off'])[1]")
	private WebElement OrgNamesort_Downarrow;	
	
	@FindBy(xpath = "(//i[@class='anticon anticon-caret-up ant-table-column-sorter-up off'])[2]")
	private WebElement OwnerNamesort_Uparrow;
	
	@FindBy(xpath = "(//i[@class='anticon anticon-caret-down ant-table-column-sorter-down off'])[2]")
	private WebElement OwnerNamesort_Downarrow;	
	
	@FindBy(xpath = "(//i[@class='anticon anticon-caret-up ant-table-column-sorter-up off'])[3]")
	private WebElement No_Of_Acc_sort_Uparrow;
	
	@FindBy(xpath = "(//i[@class='anticon anticon-caret-down ant-table-column-sorter-down off'])[3]")
	private WebElement NO_of_Acc_sort_Downarrow;	
	
	@FindBy(xpath = "(//i[@class='anticon anticon-caret-up ant-table-column-sorter-up off'])[4]")
	private WebElement CreatedOn_sort_Uparrow;
	
	@FindBy(xpath = "(//i[@class='anticon anticon-caret-down ant-table-column-sorter-down off'])[4]")
	private WebElement CreatedOn_sort_Downarrow;	
	
	@FindBy(xpath = "(//i[@class='anticon anticon-caret-up ant-table-column-sorter-up off'])[5]")
	private WebElement Status_sort_Uparrow;
	
	@FindBy(xpath = "(//i[@class='anticon anticon-caret-down ant-table-column-sorter-down off'])[5]")
	private WebElement Status_sort_Downarrow;	
	
	public OrganizationPage(WebDriver orgdriver) {
		this.driver = orgdriver;
		PageFactory.initElements(driver, this);
	}
	
	public WebElement getOrganization_icon() {
		return Organization_icon;
		
	}
	public WebElement getNextpage_Arrow() {
		return Nextpage_Arrow;

	}public WebElement getLastPage() {
		return LastPage;

	}
	
	public WebElement getPreviouspage() {
		return Previouspage;

	}
	
	public WebElement getFirstpage() {
		return Firstpage;

	}
	
	public WebElement getOrganization_searchIcon() {
		return Organization_searchIcon;

	}
	
	public WebElement getOrg_searchField() {
		return Org_searchField;

	}
	
	
	public WebElement getPencilIcon_Org() {
		return PencilIcon_Org;

	}
	
	
	public WebElement getOrganization_Name() {
		return Organization_Name;

	}
	
	
	
	public WebElement getContact_Name_Org() {
		return Contact_Name_Org;

	}
	
	
	public WebElement getContact_Number_Org() {
		return Contact_Number_Org;

	}
	
	
	public WebElement getContact_Email_Org() {
		return Contact_Email_Org;

	}
	
	
	public WebElement getOrg_deactivation_toggle() {
		return Org_deactivation_toggle;

	}
	
	public WebElement getOrg_activation_toggle() {
		return Org_activation_toggle;

	}
	
	public WebElement getSubmit_Org() {
		return Submit_Org;

	}
	public WebElement getFirstpage_inner_orgedit() {
		return Firstpage_inner_orgedit;

	}
	
	
	public WebElement getNavigating_account() {
		return Navigating_account;

	}
	
	public WebElement getNew_Organization() {
		return New_Organization;

	}
	public WebElement getSearch_fieldClose() {
		return Search_fieldClose;

	}
	public WebElement getOrgNamesort_Uparrow() {
		return OrgNamesort_Uparrow;
		
	}
	public WebElement getOrgNamesort_Downarrow() {
		return OrgNamesort_Downarrow;
		
	}
	public WebElement getOwnerNamesort_Uparrow() {
		return OwnerNamesort_Uparrow;
		
	}
	public WebElement getOwnerNamesort_Downarrow() {
		return OwnerNamesort_Downarrow;
		
	}
	public WebElement getNo_Of_Acc_sort_Uparrow() {
		return No_Of_Acc_sort_Uparrow;
		
	}
	public WebElement getNO_of_Acc_sort_Downarrow() {
		return NO_of_Acc_sort_Downarrow;
		
	}
	public WebElement getCreatedOn_sort_Uparrow() {
		return CreatedOn_sort_Uparrow;
		
	}
	public WebElement getCreatedOn_sort_Downarrow() {
		return CreatedOn_sort_Downarrow;
		
	}
	public WebElement getStatus_sort_Uparrow() {
		return Status_sort_Uparrow;
		
	}
	public WebElement getStatus_sort_Downarrow() {
		return Status_sort_Downarrow;
		
	}
	
	
}
