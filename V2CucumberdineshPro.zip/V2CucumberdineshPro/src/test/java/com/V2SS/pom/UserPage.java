package com.V2SS.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class UserPage {

	public static WebDriver driver;
	
	@FindBy(xpath = "//button[@class='ant-btn sc-pAwOa dHBtKj']")
	private WebElement user_tab;
	
	@FindBy(xpath = "//button[@class='ant-btn sc-fzqBZW eNQuho sc-pIUfD qlYhQ ant-btn-circle']")
	private WebElement createUser_btn;
	
	
	@FindBy(xpath = "//input[@name='firstname']")
	private WebElement first_name;
	
	@FindBy(xpath = "//input[@name='lastname']")
	private WebElement last_name;
	
	
	@FindBy(xpath = "//input[@name='email']")
	private WebElement email_user;
	
	
	@FindBy(xpath = "//button[@class='ant-switch']")
	private WebElement optIn_SS_loginToggle;
	
	
	@FindBy(xpath = "//div[text()='Select Tier']")
	private WebElement select_tier_field;		
	
	
	@FindBy(xpath = "//li[text()='Chennai']")
	private WebElement chennai_tier;
	
	
	@FindBy(xpath = "//div[text()='Select Tier Roles']")
	private WebElement select_roles_field_create;		
					
	
	@FindBy(xpath = "(//li[text()='Agent'])[2]")
	private WebElement Agent_role;
	
	
	
	@FindBy(xpath = "//button[@class='ant-btn sc-fzqBZW eNQuho sc-qapxP jnVPKq ant-btn-circle']")
	private WebElement Tier_role_Adding;
	
	
	@FindBy(xpath = "(//button[@class='ant-btn ant-btn-primary'])[2]")
	private WebElement Create_user;
	
	
	@FindBy(xpath = "//input[@class='ant-input sc-fzqAbL hCuLgs']")
	private WebElement Search_Name_Field;
	
	//(//div[@class='ant-select-selection__rendered'])[1]
	@FindBy(xpath = "//div[text()='Select Roles']")
	private WebElement searchRole_field;
	
	
	@FindBy(xpath = "//li[text()='Show All']")
	private WebElement Search_ShowAll;
	
	
	@FindBy(xpath = "//li[text()='Agent']")
	private WebElement Search_Agent;		
			
			
      @FindBy(xpath = "//li[text()='Tier Manager']")
	 private WebElement Search_Manager;			   
	 	   
      
    
      @FindBy(xpath = "//button[@class='ant-btn sc-fzqBZW eNQuho ant-btn-circle']")
      private WebElement User_filter;
      
      
  
      @FindBy(xpath = "//div[@class='sc-pJwHY diVRja']")
      private WebElement User_filter_close;
      
     
    		  
     @FindBy(xpath = " (//i[@class='anticon anticon-caret-up ant-table-column-sorter-up off'])[1]")
      private WebElement User_Name_upward;
    					  
     @FindBy(xpath = " (//i[@class='anticon anticon-caret-up ant-table-column-sorter-up off'])[2]")
 	private WebElement  User_Email_upward;
 	
     
     @FindBy(xpath = " (//i[@class='anticon anticon-caret-up ant-table-column-sorter-up off'])[3]")
 	private WebElement  User_Tier_upward;
 	
    		  
    		  
   	
    		
    @FindBy(xpath = " (//i[@class='anticon anticon-caret-down ant-table-column-sorter-down off'])[1]")
     private WebElement User_Name_Downward;
    
    @FindBy(xpath = " (//i[@class='anticon anticon-caret-down ant-table-column-sorter-down off'])[2]")
	private WebElement User_Email_Downward;
	
    
    @FindBy(xpath = " (//i[@class='anticon anticon-caret-down ant-table-column-sorter-down off'])[3]")
	private WebElement User_Tier_Downward;
	
    				
	public UserPage(WebDriver userdriver) {
		this.driver = userdriver;
		PageFactory.initElements(driver, this);
	}
	
	
	public WebElement getuser_tab() {
		return user_tab;

	}
	
	
	public WebElement getcreateUser_btn() {
		return createUser_btn;

	}
	
	public WebElement getfirst_name() {
		return first_name;

	}
	
	public WebElement getlast_name() {
		return last_name;

	}
	
	public WebElement getemail_user() {
		return email_user;

	}
	
	
	public WebElement getoptIn_SS_loginToggle() {
		return optIn_SS_loginToggle;

	}
	
	
	public WebElement getselect_tier_field() {
		return select_tier_field;

	}
	
	
	public WebElement getchennai_tier() {
		return chennai_tier;

	}
	
	
	
	public WebElement getselect_roles_field_create() {
		return select_roles_field_create;

	}
	
	
	
	public WebElement getAgent_role() {
		return Agent_role;

	}
	
	
	
	public WebElement getTier_role_Adding() {
		return Tier_role_Adding;

	}
	
	
	public WebElement getCreate_user() {
		return Create_user;

	}
	
	public WebElement getSearch_Name_Field() {
		return Search_Name_Field;

	}
	

	public WebElement getsearchRole_field() {
		return searchRole_field;

	}
	
	

	public WebElement getSearch_ShowAll() {
		return Search_ShowAll;

	}
	
	
	

	public WebElement getSearch_Agent() {
		return Search_Agent;

	}
	
	

	public WebElement getSearch_Manager() {
		return Search_Manager;

	}
	
	
	public WebElement getUser_filter() {
		return User_filter;

	}
	
	public WebElement getUser_filter_close() {
		return User_filter_close;

	}
	
	public WebElement getUser_Name_upward() {
		return  User_Name_upward;

	}
	
	
	public WebElement getUser_Email_upward() {
		return User_Email_upward;

	}
	
	
	public WebElement getUser_Tier_upward() {
		return User_Tier_upward;

	}
	
	
	public WebElement getUser_Name_Downward() {
		return User_Name_Downward;

	}
	
	public WebElement getUser_Email_Downward() {
		return User_Email_Downward;

	}
	
	public WebElement getUser_Tier_Downward() {
		return User_Tier_Downward;

	}
	
	
	
}
