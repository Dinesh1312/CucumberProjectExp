package com.V2SS.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Verificationpage {

	public static WebDriver driver;
	
	
	@FindBy(xpath = "//div[@class='sc-AxjAm sc-jXPivZ djHTWT']")
	private WebElement  SSiconlogo;
	
	
	@FindBy(xpath = "(//a)[1]")
	private WebElement  Menuexpansion;
	
	
	@FindBy(xpath = "//li[@path='/admin/organizations']")
	private WebElement  Org_tab;
	
	
	
	
	@FindBy(xpath = "(//li[@path='/admin/onboardinggroupdashboard'])[1]")
	private WebElement Onb_grpDashboard ;			
	

	public Verificationpage(WebDriver vpdriver) {
		this.driver = vpdriver;
		PageFactory.initElements(driver, this);
	}
	
	public WebElement getSSiconlogo() {
		return SSiconlogo;
}
	
	public WebElement getMenuexpansion() {
		return Menuexpansion;
}	
	
	public WebElement getOrg_tab() {
		return Org_tab;
}	
	
	public WebElement getOnb_grpDashboard() {
		return Onb_grpDashboard;
}	
	
	
	
	
	
}
