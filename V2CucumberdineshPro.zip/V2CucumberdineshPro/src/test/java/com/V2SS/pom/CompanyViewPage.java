package com.V2SS.pom;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
/*
 * -----------locators for CompanyView page--------------- 
 * created on: 17-05-2020
 * created by: Anupradha CD 
 * last modification:10-6-2020 by  Anupradha CD 
 * 
 */


public class CompanyViewPage {

	public static WebDriver driver;

	@FindBy(xpath = "li[@class='ant-menu-item sc-pIJmg ehCwJf ant-menu-item-selected']//a[@class='sc-pZaHX sc-oTaid fpeoAN']")
	private WebElement mismatch;

	@FindBy(xpath = "//div[contains(text(),'Export')]")
	// div[@class='sc-fzqNJr dDfkcN']
	private WebElement mismatch_export;

	@FindBy(xpath = "//*[name()='circle' and contains(@cx,'11')]")
	private WebElement mismatch_searchicon;

	@FindBy(xpath = "//div[contains(text(),'New')]")
	private WebElement mismatch_new;

	@FindBy(xpath = "//div[contains(text(),'Processed')]")
	// div[@class='ant-tabs-tab-active ant-tabs-tab']
	private WebElement mismatch_processed;

	@FindBy(xpath = "//div[contains(text(),'Mapped')]")
	private WebElement mismatch_mapped;

	@FindBy(xpath = "//div[contains(text(),'Archived')]")
	private WebElement mismatch_archived;

	@FindBy(xpath = "//div[contains(text(),'Corrupt')]")
	private WebElement mismatch_corrupt;

	@FindBy(xpath = "li[@class='ant-menu-item sc-pIJmg ehCwJf ant-menu-item-selected']//a[@class='sc-pZaHX sc-oTaid fpeoAN']")
	private WebElement transactions;

	@FindBy(xpath = "//li[@class='ant-menu-item sc-pIJmg ehCwJf ant-menu-item-selected']//a[@class='sc-pZaHX sc-oTaid fpeoAN']")
	private WebElement testimonial_widget;

	@FindBy(xpath = "//button[@class='ant-btn sc-fzqBZW eNQuho ant-btn-circle']//*[local-name()='svg']")
	private WebElement testimonial_widget_filter;

	@FindBy(xpath = "//div[@class='sc-fzoant hXtGXC']//i[@class='anticon anticon-close']//*[local-name()='svg']")
	private WebElement testimonial_widget_filter_back;

	@FindBy(xpath = "//span[contains(text(),'Get Code')]")
	private WebElement testimonial_widget_getcode;

	@FindBy(xpath = "//li[@class='ant-menu-item sc-pIJmg ehCwJf ant-menu-item-selected']//a[@class='sc-pZaHX sc-oTaid fpeoAN']")
	private WebElement reviews_management;

	@FindBy(xpath = "//button[@class='ant-btn sc-fzqBZW eNQuho ant-btn-circle']//*[local-name()='svg']")
	private WebElement reviews_management_filter;

	@FindBy(xpath = "//div[@class='sc-fzoant hXtGXC']//i[@class='anticon anticon-close']//*[local-name()='svg']")
	private WebElement reviews_management_filter_back;

	@FindBy(xpath = "//li[@class='ant-menu-item sc-pIJmg ehCwJf ant-menu-item-selected']//a[@class='sc-pZaHX sc-oTaid fpeoAN']")
	private WebElement hierarchy;

	@FindBy(xpath = "//tr[@class='ant-table-row ant-table-row-level-0']//button[2]//*[local-name()='svg']")
	private WebElement hierarchy_edit;

	@FindBy(xpath = "//tr[@class='ant-table-row ant-table-row-level-0']//button[1]//*[local-name()='svg']//*[name()='path' and contains(@d,'M16.9453 1')]")
	private WebElement hierarchy_settings;

	@FindBy(xpath = "//div[@class='sc-fzqNJr dDfkcN']")
	private WebElement hierarchy_upload;

	@FindBy(xpath = "//body//button[3]//*[local-name()='svg']")
	private WebElement hierarchy_add;

	public CompanyViewPage(WebDriver cmpdriver) {
		this.driver = cmpdriver;
		PageFactory.initElements(driver, this);
	}

	public WebElement getmismatch() {
		return mismatch;

	}

	public WebElement getmismatch_export() {
		return mismatch_export;

	}

	public WebElement getmismatch_searchicon() {
		return mismatch_searchicon;

	}

	public WebElement getmismatchnew() {
		return mismatch_new;

	}

	public WebElement getmismatch_processed() {
		return mismatch_processed;

	}

	public WebElement getmismatch_mapped() {
		return mismatch_mapped;

	}

	public WebElement getmismatch_archived() {
		return mismatch_archived;

	}

	public WebElement getmismatch_corrupt() {
		return mismatch_corrupt;

	}

	public WebElement gettransactions() {
		return transactions;

	}

	public WebElement gettestimonial_widget() {
		return testimonial_widget;

	}

	public WebElement gettestimonial_widget_filter() {
		return testimonial_widget_filter;

	}

	public WebElement gettestimonial_widget_filter_back() {
		return testimonial_widget_filter_back;

	}

	public WebElement gettestimonial_widget_getcode() {
		return testimonial_widget_getcode;

	}

	public WebElement getreviews_management() {
		return reviews_management;

	}

	public WebElement getreviews_management_filter() {
		return reviews_management_filter;

	}

	public WebElement getreviews_management_filter_back() {
		return reviews_management_filter_back;

	}

	public WebElement gethierarchy() {
		return hierarchy;

	}

	public WebElement gethierarchy_edit() {
		return hierarchy_edit;

	}

	public WebElement gethierarchy_settings() {
		return hierarchy_settings;

	}

	public WebElement gethierarchy_upload() {
		return hierarchy_upload;

	}

	public WebElement gethierarchy_add() {
		return hierarchy_add;

	}

}
