package com.V2SS.helpers;

import org.openqa.selenium.WebDriver;

import com.V2SS.pom.AccountPage;
import com.V2SS.pom.AdminPage2;
import com.V2SS.pom.AdmingroupPage;
import com.V2SS.pom.CustomerSupportLogin;
import com.V2SS.pom.HierarchyPage;
import com.V2SS.pom.LoginPage1;
import com.V2SS.pom.OnboardingAdminLogin;
import com.V2SS.pom.OnboardingPage;
import com.V2SS.pom.OrganizationPage;
import com.V2SS.pom.UserPage;
import com.V2SS.pom.Verificationpage;

//-------------------------instance of all the page object module----------------------------------

public class PageObjectManager {
	public static WebDriver driver;

	private LoginPage1 lp;
	private AdminPage2 ap;
	private AccountPage acc_pg;
    private OrganizationPage org_pg;
    private HierarchyPage hie_pg;
    private UserPage User_pg;
    private OnboardingPage Onb_pg;
    private OnboardingAdminLogin OnbAdmin_pg;
    private CustomerSupportLogin CSAdmin_pg;
    private AdmingroupPage adm_grp;
    private Verificationpage vp;
    
    
	public PageObjectManager(WebDriver driver) {
		this.driver = driver;
	}

	public LoginPage1 getlp() {
		lp = new LoginPage1(driver);
		return lp;
	}

	public AdminPage2 getap() {
		ap = new AdminPage2(driver);
		return ap;

	}

	public AccountPage getacc_pg() {
		acc_pg = new AccountPage(driver);
		return acc_pg;
	}
	
	public OrganizationPage getOrg_pg() {
		org_pg = new OrganizationPage(driver);
		return org_pg;
	}
	
	
	public HierarchyPage getHie_pg() {
		hie_pg = new HierarchyPage(driver);
		return hie_pg;
}
	
	public UserPage getUser_pg() {
		User_pg = new UserPage(driver);
		return User_pg;
}
	public OnboardingPage getOnb_pg() {
		Onb_pg = new OnboardingPage(driver);
		return Onb_pg;
}
	
	public OnboardingAdminLogin getOnbAdmin_pg() {
		OnbAdmin_pg = new OnboardingAdminLogin(driver);
	  return OnbAdmin_pg;
	  
	}
	  public CustomerSupportLogin getCSAdmin_pg() {
			CSAdmin_pg = new CustomerSupportLogin(driver);
		  return CSAdmin_pg;  
}
	  
	  public  AdmingroupPage  getadm_grp() {
		adm_grp = new AdmingroupPage(driver);
		 return adm_grp;
	}
	  
	  public Verificationpage getvp() {
			vp = new Verificationpage(driver);
			return vp;
		}
	
}	
