package com.V2SS.helpers;

import java.util.ArrayList;
import java.util.Random;

import org.apache.commons.lang3.RandomStringUtils;

public class Emailgenerator {
	
static String email1 = null;
	
	
	@SuppressWarnings("unlikely-arg-type")
	public static void main(String[] args) {
		 String newemailgenerated = Emailgenerator.newemail();
		System.out.println(newemailgenerated);
		
		String newFirstname = Emailgenerator.newCode(8);
		String newLastname= Emailgenerator.newCode(4);
		System.out.println(newFirstname);
		System.out.println(newLastname);
		System.out.println(newFirstname+" " +newLastname);

		ArrayList<String> ar1 = new ArrayList<String>();
		ar1.add(0, "dinesh");
	   ar1.add(1,"ganesh");
		ar1.add(2, "suresh");
		for(int i=0; i<ar1.size();i++) {
			if(ar1.get(i).contentEquals("suresh")) {
				System.out.println("superda");
				break;
			}
			else {
				continue;
			}
		}
		
		
		
		
	}
	
	public static String randomNumGenerator() {
		
		Random random = new Random();
		int randomNumber = random.nextInt(9000000);
		String id = Integer.toString(randomNumber);
		return id;
		
		
	}
	
	
	public static String newCode(int count) {
		String randomAlphabetic = RandomStringUtils.randomAlphabetic(count);
		
	String name	=randomAlphabetic;
		return name;
	}
	
	
	public static String newemail() {
		String newemail = "waquaralam987+";
			String email1 = newemail + Emailgenerator.randomNumGenerator() + "@gmail.com";
			return email1;
	
	}
	
	public static String newAccmanageremail() {
		String newemail = "waquaralam987+";
			String email1 = newemail + Emailgenerator.randomNumGenerator() + "@gmail.com";
			return email1;
	
	}
	
	public static String CreatenewAdminemail() {
		String newemail = "waquaralam+";
			String email1 = newemail + Emailgenerator.randomNumGenerator() + "@socialsurvey.com";
			return email1;
	
	}
	
	
	
}
