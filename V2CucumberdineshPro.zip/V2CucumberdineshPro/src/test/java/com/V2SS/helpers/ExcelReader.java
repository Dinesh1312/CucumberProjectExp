package com.V2SS.helpers;


import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
public class ExcelReader {
	public static String readFromExcel(String file,String sheet, int row_num, int col_num) throws IOException {
		
		XSSFWorkbook myExcelBook = new XSSFWorkbook(new FileInputStream(file));
		XSSFSheet myExcelSheet = myExcelBook.getSheet(sheet);
		XSSFRow row = myExcelSheet.getRow(row_num);
		
		String name = row.getCell(col_num).getStringCellValue();
		System.out.println("NAME : " + name);	
		myExcelBook.close();
		return name;
		
	}
	
public static String readFromExcel2(String file,String sheet, int row_num, int col_num) throws IOException {
		
		XSSFWorkbook myExcelBook = new XSSFWorkbook(new FileInputStream(file));
		XSSFSheet myExcelSheet = myExcelBook.getSheet(sheet);
		XSSFRow row = myExcelSheet.getRow(row_num);
		
		String name = row.getCell(col_num).getStringCellValue();
		System.out.println("NAME : " + name);	
		myExcelBook.close();
		return name;
		
	}

public static String camelcasevalue(String username) {
	
	String camelcasevalue=" ";
	
		String[] split = username.toLowerCase().split(" ");
		for(int i=0;i< split.length;i++) {
		
			split[i] = split[i].substring(0,1).toUpperCase()+split[i].substring(1);
			
		}
		
		for(int i=0;i< split.length;i++) {
			camelcasevalue	=camelcasevalue+" "+split[i];
		}
		System.out.println(camelcasevalue);
		return camelcasevalue;
		
	
}
	
	// remove this main method
public static void main(String[] args) throws IOException {
	 
//
/*	ArrayList<String> ar1 = new ArrayList<String>();
	try {
		for (int i = 1 ; i < 5; i++) {	
			ar1.add(ExcelReader.readFromExcel2("/Users/dineshkumar/Downloads/Automation Upload File1.xlsx", "Users", i, 1));
		}
	
		System.out.println("Variables values are " + ar1.get(0));
			String region1 = ar1.get(0);
		
				} catch (IOException e) {	
		}}}			 
			*/	
	ArrayList<String> ar1 = new ArrayList<String>();
	for (int i = 1 ; i < 5; i++) {
		
		for (int j = 1 ; j< 3; j++) {
			System.out.print(ar1 .add(ExcelReader.readFromExcel("/Users/dineshkumar/Downloads/Automation Upload File1.xlsx", "Users", i, j)));
		}
		
		System.out.println();
	}
		System.out.println(ar1);
		String ar=ar1 .get(0)+" "+ar1 .get(1);
		ExcelReader.camelcasevalue(ar);
}


   
		
		
}