package com.V2SS.helpers;






import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.V2SS.runner.Runnercls;
import com.baseclass.org.BaseClass;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;




public class Hooks extends BaseClass {
	
	
	@Before("@login")
	public void beforeScenario(Scenario scenario) {
		
		System.out.println("scenario name:  "+scenario.getName());
		
	}
	@After("@login")
	public void  afterScenario(Scenario scenario)throws Exception {
		
		if(scenario.isFailed()) {
			
			String name = scenario.getName();
			System.out.println("scenario name is: " +name);
			//Screenshot(name);
			
			
			TakesScreenshot ts = (TakesScreenshot) driver;
			File srcfile = ts.getScreenshotAs(OutputType.FILE);
			File destFile = new File("Users/dineshkumar/ssrepo/V2_Uiautomation/V2CucumberPro/Screenshot"+ name +".png");
			FileUtils.copyFile(srcfile, destFile);
			System.out.println("scenario name is: " );
		}}}
