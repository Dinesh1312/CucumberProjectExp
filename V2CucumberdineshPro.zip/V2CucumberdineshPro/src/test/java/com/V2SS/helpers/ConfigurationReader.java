package com.V2SS.helpers;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class ConfigurationReader {
	public static Properties ps;

	public ConfigurationReader() throws IOException {
		File f = new File("/Users/dineshkumar/ssrepo/V2_Uiautomation/V2CucumberdineshPro/src/test/java/com/V2SS/properties/configuration.properties");
		FileInputStream fis = new FileInputStream(f);

		ps = new Properties();
		ps.load(fis);
	}

	public String browsername() {

		String browser = ps.getProperty("Browsername");
		return browser;
	}

	public static String geturl() {
		String url = ps.getProperty("url");
		return url;
	}

	public static String getAdmins_SearchUser1() {

		String Admins_SearchUser1 = ps.getProperty("Admins_SearchUser1");
		return Admins_SearchUser1;
	}

	
	
	
	
	public static String getAdmins_SearchUser2() {

		String Admins_SearchUser2 = ps.getProperty("Admins_SearchUser2");
		return Admins_SearchUser2;
	}
	
	
	public static String Admins_EditFnUser1() {

		String Admins_EditFnUser1 = ps.getProperty("Admins_EditFnUser1");
		return Admins_EditFnUser1;
	}

	public static String Admins_EditLnUser1() {

		String Admins_EditLnUser1 = ps.getProperty("Admins_EditLnUser1");
		return Admins_EditLnUser1;
	}


	public static String Admins_EditFnUser2() {

		String Admins_EditFnUser2 = ps.getProperty("Admins_EditFnUser2");
		return Admins_EditFnUser2;
	}

	public static String Admins_EditLnUser2() {

		String Admins_EditLnUser2 = ps.getProperty("Admins_EditLnUser2");
		return Admins_EditLnUser2;
	}

	public static String Admins_NewUserMail() {

		String Admins_NewUserMail = ps.getProperty("Admins_NewUserMail");
		return Admins_NewUserMail;
	}

	public static String Admins_NewUserFn() {

		String Admins_NewUserFn = ps.getProperty("Admins_NewUserFn");
		return Admins_NewUserFn;
	}

	public static String Admins_NewUserLn() {

		String Admins_NewUserLn = ps.getProperty("Admins_NewUserLn");
		return Admins_NewUserLn;
	}

	public static String Admins_SearchNewUser() {

		String Admins_SearchNewUser = ps.getProperty("Admins_SearchNewUser");
		return Admins_SearchNewUser;
	}

	public static String Admins_ExistingMailId() {

		String Admins_ExistingMailId = ps.getProperty("Admins_ExistingMailId");
		return Admins_ExistingMailId;
	}

	public static String Admins_ExistingMailFn() {

		String Admins_ExistingMailFn = ps.getProperty("Admins_ExistingMailFn");
		return Admins_ExistingMailFn;
	}

	public static String Admins_ExistingMailLn() {

		String Admins_ExistingMailLn = ps.getProperty("Admins_ExistingMailLn");
		return Admins_ExistingMailLn;
	}

	public static String getAcc_E_O_Pri_Acc() {

		String Acc_E_O_Pri_Acc = ps.getProperty("Acc_E_O_Pri_Acc");
		return Acc_E_O_Pri_Acc;
	}

	public static String getAcc_N_O_Pri_Acc() {

		String Acc_N_O_Pri_Acc = ps.getProperty("Acc_N_O_Pri_Acc");
		return Acc_N_O_Pri_Acc;
	}

	public static String getAcc_newOrgName() {

		String Acc_newOrgName = ps.getProperty("Acc_newOrgName");
		return Acc_newOrgName;
	}

	public static String getAdminGroupCatagory() {

		String Admins_group_catagory = ps.getProperty("Admins_group_catagory");
		return Admins_group_catagory;
	}

	public static String getAcc_Searching_acc() {

		String Acc_Searching_acc = ps.getProperty("Acc_Searching_acc");
		return Acc_Searching_acc;
	}
	
	public static String getOrg_Searchby_OrgName() {

		String Org_Searchby_OrgName = ps.getProperty("Org_Searchby_OrgName");
		return Org_Searchby_OrgName;
	}
	
	public static String getOrg_Searchby_Owner() {

		String Org_Searchby_Owner = ps.getProperty("Org_Searchby_Owner");
		return Org_Searchby_Owner;
	}
	
	public static String getOrg_OrgnameTo_update_searchbar() {

		String Org_OrgnameTo_update_searchbar = ps.getProperty("Org_OrgnameTo_update_searchbar");
		return Org_OrgnameTo_update_searchbar;
	}
	
	public static String getOrg_Edited_Orgname_field() {

		String Org_Edited_Orgname_field = ps.getProperty("Org_Edited_Orgname_field");
		return Org_Edited_Orgname_field;
	}
	
	
	public static String getOrg_Edited_Contactname_field() {

		String Org_Edited_Contactname_field = ps.getProperty("Org_Edited_Contactname_field");
		return Org_Edited_Contactname_field;
	}
	
	public static String getOrg_Edited_Contactnum_field() {

		String Org_Edited_Contactnum_field= ps.getProperty("Org_Edited_Contactnum_field");
		return Org_Edited_Contactnum_field;
	}
	
	
	public static String getOrg_Edited_Contactmail_field() {

		String Org_Edited_Contactmail_field = ps.getProperty("Org_Edited_Contactmail_field");
		return Org_Edited_Contactmail_field;
	}
	
	
	public static String getOrg_NewOrgName() {

		String Org_NewOrgName = ps.getProperty("Org_NewOrgName");
		return Org_NewOrgName;
	}
	
	
	public static String getOrg_NewContactName() {

		String Org_NewContactName = ps.getProperty("Org_NewContactName");
		return Org_NewContactName;
	}
	
	
	public static String getOrg_NewContactnum() {

		String Org_NewContactnum = ps.getProperty("Org_NewContactnum");
		return Org_NewContactnum;
	}
	
	
	public static String getOrg_NewContactMail() {

		String Org_NewContactMail = ps.getProperty("Org_NewContactMail");
		return Org_NewContactMail;
	}
	
	public static String getHie_AccountName() {

		String Hie_AccountName = ps.getProperty("Hie_AccountName");
		return Hie_AccountName;
	}
	
	public static String getHie_NewTierName() {

		String Hie_NewTierName= ps.getProperty("Hie_NewTierName");
		return Hie_NewTierName;
	}
	
	public static String getHie_NewEdittierName() {

		String Hie_NewEdittierName = ps.getProperty("Hie_NewEdittierName");
		return Hie_NewEdittierName;
	}


public String getReportConfigPath(){
 String reportConfigPath = ps.getProperty("/V2CucumberPro/src/test/java/com/V2SS/properties/extent-config.xml");
 if(reportConfigPath!= null) return reportConfigPath;
 else throw new RuntimeException("Report Config Path not specified in the Configuration.properties file for the Key:reportConfigPath"); 
}
	
public static String getAdmin_GrpName() {

	String Admin_GrpName = ps.getProperty("Admin_GrpName");
	return Admin_GrpName;
}

public static String getAdmin_GrpDescription() {

	String Admin_GrpDescription = ps.getProperty("Admin_GrpDescription");
	return Admin_GrpDescription;
}

public static String getAdmins_SearchEditeduser() {

	String Admins_SearchEditeduser = ps.getProperty("Admins_SearchEditeduser");
	return Admins_SearchEditeduser;
}


public static String getAcc_newOrgManagerFirstname() {

	String Acc_newOrgManagerFirstname = ps.getProperty("Acc_newOrgManagerFirstname");
	return Acc_newOrgManagerFirstname;
}
	
	
public static String getAcc_newOrgManagerLastname() {

	String Acc_newOrgManagerLastname = ps.getProperty("Acc_newOrgManagerLastname");
	return Acc_newOrgManagerLastname;
}


public static String getAcc_newOrgManagerEmail() {

	String Acc_newOrgManagerEmail = ps.getProperty("Acc_newOrgManagerEmail");
	return Acc_newOrgManagerEmail;
}

public static String getAcc_newOrgcontactNumber() {

	String Acc_newOrgcontactNumber = ps.getProperty("Acc_newOrgcontactNumber");
	return Acc_newOrgcontactNumber;
}

public static String getAcc_newOrgcontactEmail() {

	String Acc_newOrgcontactEmail = ps.getProperty("Acc_newOrgcontactEmail");
	return Acc_newOrgcontactEmail;
}
public static String getAcc_newOrgcontactName() {

	String Acc_newOrgcontactName = ps.getProperty("Acc_newOrgcontactName");
	return Acc_newOrgcontactName;
}
public static String getAcc_Edited_Pri_Acc() {

	String Acc_Edited_Pri_Acc = ps.getProperty("Acc_Edited_Pri_Acc");
	return Acc_Edited_Pri_Acc;
}

public static String getAcc_N_O_Pri_Acc1() {

	String Acc_N_O_Pri_Acc1 = ps.getProperty("Acc_N_O_Pri_Acc1");
	return Acc_N_O_Pri_Acc1;
}

public static String getAcc_newOrgManagerFirstname1() {

	String Acc_newOrgManagerFirstname1 = ps.getProperty("Acc_newOrgManagerFirstname1");
	return Acc_newOrgManagerFirstname1;
}

public static String getAcc_newOrgManagerLastname1() {

	String Acc_newOrgManagerLastname1= ps.getProperty("Acc_newOrgManagerLastname1");
	return Acc_newOrgManagerLastname1;
}

public static String getAcc_newOrgManagerEmail1() {

	String Acc_newOrgManagerEmail1= ps.getProperty("Acc_newOrgManagerEmail1");
	return Acc_newOrgManagerEmail1;
}
	
//=======================verify======================================	

public static String getOrganization_Accounturl() {
	String Organization_Accounturl = ps.getProperty("Organization_Accounturl");
	return Organization_Accounturl;
}
	
public static String getOrganization_userurl() {
	String Organization_userurl = ps.getProperty("Organization_userurl");
	return Organization_userurl;
}	

	
public static String getOrganization_settingsurl() {
	String Organization_settingsurl = ps.getProperty("Organization_settingsurl");
	return Organization_settingsurl;
}	
	
public static String getAccounts_url() {
	String Accounts_url = ps.getProperty("Accounts_url");
	return Accounts_url;
}		
	
public static String getHierarchy_url() {
	String Hierarchy_url = ps.getProperty("Hierarchy_url");
	return Hierarchy_url;
}		
		
public static String getAccountssettings_url() {
	String Accountssettings_url = ps.getProperty("Accountssettings_url");
	return Accountssettings_url;
}	
	
public static String getWidge_url() {
	String Widge_url = ps.getProperty("Widge_url");
	return Widge_url;
}
	
public static String getReviewsManagement_url() {
	String ReviewsManagement_url = ps.getProperty("ReviewsManagement_url");
	return ReviewsManagement_url;
}
public static String getAdmin_url() {
	String Admin_url = ps.getProperty("Admin_url");
	return Admin_url;
}	
	
public static String getAdmingroup_url() {
	String Admingroup_url = ps.getProperty("Admingroup_url");
	return Admingroup_url;
}	
	
public static String getOnboardinggroup_url() {
	String Onboardinggroup_url = ps.getProperty("Onboardinggroup_url");
	return Onboardinggroup_url;
}	
	
public static String getlogout_url() {
	String logout_url = ps.getProperty("logout_url");
	return logout_url;
}	
public static String getlistings_url() {
	String listings_url = ps.getProperty("listings_url");
	return listings_url;	
	
	
	
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
