package com.V2SS.helpers;


import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
public class Excelwriter {
	public static void writeIntoExcel(String file, String sheet, int row_num, int cell_num) throws FileNotFoundException, IOException {
		XSSFWorkbook book = new XSSFWorkbook(new FileInputStream(file));
		XSSFSheet myExcelSheet = book.getSheet(sheet);
		
		Row row = myExcelSheet.getRow(row_num);
		Cell name = row.getCell(cell_num);
		name.setCellValue(Emailgenerator.newemail());
		myExcelSheet.autoSizeColumn(1);
		book.write(new FileOutputStream(file));
		book.close();
	}
//	
	public static void writeIntoExcel2(String file, String sheet, int row_num, int cell_num, int count) throws FileNotFoundException, IOException {
		
		XSSFWorkbook book = new XSSFWorkbook(new FileInputStream(file));
		XSSFSheet myExcelSheet = book.getSheet(sheet);
		
		Row row = myExcelSheet.getRow(row_num);
		Cell name = row.getCell(cell_num);
		name.setCellValue(Emailgenerator.newCode(count));
		myExcelSheet.autoSizeColumn(1);
		book.write(new FileOutputStream(file));
		book.close();
		
		
	}
	
//	void main(String[] args) {
//		try {
//			//writeIntoExcel("/Users/waquar/Desktop/Automation Upload File.xlsx", "Users", 1, 6);
//			for (int i = 1 ; i < 5; i++) {
//				Excelwriter.writeIntoExcel("/Users/waquar/Desktop/Automation Upload File.xlsx", "Users", i, 6);
//			}
//		} catch (IOException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}public static 
//	}
	public static void main(String[] args) {
		try {
		//writeIntoExcel("/Users/waquar/Desktop/Automation Upload File.xlsx", "Users", 1, 6);
		
		for (int i = 1 ; i <5; i++) {
			Excelwriter.writeIntoExcel("/Users/dineshkumar/Downloads/Automation Upload File1.xlsx", "Users", i, 6);
		}
		for (int i = 1 ; i <5; i++) {
			Excelwriter.writeIntoExcel2("/Users/dineshkumar/Downloads/Automation Upload File1.xlsx", "Users", i, 1, 8);
}
			for (int i = 1 ; i <5; i++) {
				Excelwriter.writeIntoExcel2("/Users/dineshkumar/Downloads/Automation Upload File1.xlsx", "Users", i, 2, 4);
	}
		
		} catch (IOException e) {
		// TODO Auto-generated catch block
	e.printStackTrace();
	}
	
	
	}
}

