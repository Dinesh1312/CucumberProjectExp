package com.V2SS.Stepdefinition;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.V2SS.helpers.Emailgenerator;
import com.V2SS.helpers.FileReaderManager;
import com.V2SS.helpers.PageObjectManager;
import com.V2SS.runner.Runnercls;
import com.baseclass.org.BaseClass;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class BBStepdefenitionAdmin extends BaseClass {

	public static WebDriver driver = Runnercls.driver;
	public static PageObjectManager pom = new PageObjectManager(driver);

	// ========================Adminpagination=================================

	@When("^user clicks the admin icon$")
	public void user_clicks_the_admin_icon() throws Throwable {
		Thread.sleep(1000);
		waitforvisibilityofelement(pom.getap().getAdminicon());
		clickOnElement(pom.getap().getAdminicon());
	}

	@When("^user scrolling down to the page$")
	public void user_scrolling_down_to_the_page() throws Throwable {
		Thread.sleep(2000);
		waitforvisibilityofelement(pom.getap().getArrow());
		scrollingup(pom.getap().getArrow());
	}

	@When("^user naviagates to next page$")
	public void user_naviagates_to_next_page() throws Throwable {
		Thread.sleep(2000);
		waitforvisibilityofelement(pom.getap().getLastArrow());
		clickOnElement(pom.getap().getLastArrow());

	}

	@When("^user navigates to the last page$")
	public void user_navigates_to_the_last_page() throws Throwable {
		Thread.sleep(2000);
		pom.getap().getLastpage().click();

	}

	@When("^user navigates to the previous page$")
	public void user_navigates_to_the_previous_page() throws Throwable {
		Thread.sleep(2000);
		pom.getap().getPreviouspage().click();
	}

	@Then("^user naviagtes to the admin list first page$")
	public void user_naviagtes_to_the_admin_list_first_page() throws Throwable {
		Thread.sleep(2000);
		pom.getap().getfirstpage().click();
	}

	// =============================filter admin ===============================

	@When("^user click the filter icon$")
	public void user_click_the_filter_icon() throws Throwable {

		waitforvisibilityofelement(pom.getap().getFilter_Organization());
		pom.getap().getFilter_Organization().click();
		Thread.sleep(2000);
	}

	@When("^user filter the admin by Onboarding group$")
	public void user_filter_the_admin_by_Onboarding_group() throws Throwable {
		WebElement filter_searchfield = pom.getap().getFilter_searchfield();
		filter_searchfield.click();
		Thread.sleep(2000);
		pom.getap().getFilter_OnboardingGroup().click();
	}

	@When("^user cancel the onboarding group filter$")
	public void user_cancel_the_onboarding_group_filter() throws Throwable {
		WebElement filter_Org_GroupClose = pom.getap().getFilter_Org_GroupClose();
		movetoelement(filter_Org_GroupClose);
		Thread.sleep(2000);
		clickk(filter_Org_GroupClose);
	}

	@When("^user filter the admin by customer group$")
	public void user_filter_the_admin_by_customer_group() throws Throwable {

		WebElement filter_searchfield = pom.getap().getFilter_searchfield();
		filter_searchfield.click();
		Thread.sleep(3000);
		pom.getap().getFilter_CustomersupportGroup().click();
	}

	@When("^user cancel the customer group filter$")
	public void user_cancel_the_customer_group_filter() throws Throwable {
		WebElement filter_Org_GroupClose = pom.getap().getFilter_Org_GroupClose();
		movetoelement(filter_Org_GroupClose);
		Thread.sleep(2000);
		clickk(filter_Org_GroupClose);
	}

	@When("^user filter the admin by sales group$")
	public void user_filter_the_admin_by_sales_group() throws Throwable {
		WebElement filter_searchfield = pom.getap().getFilter_searchfield();
		filter_searchfield.click();
		Thread.sleep(2000);
		pom.getap().getFilter_SalesGroup().click();
	}

	@When("^user cancel the sales group filter$")
	public void user_cancel_the_sales_group_filter() throws Throwable {
		WebElement filter_Org_GroupClose = pom.getap().getFilter_Org_GroupClose();
		movetoelement(filter_Org_GroupClose);
		Thread.sleep(2000);
		clickk(filter_Org_GroupClose);

	}

	@When("^user filter admin by activeadmin radio button$")
	public void user_filter_admin_by_activeadmin_radio_button() throws Throwable {
		WebElement radio_ActiveAdmins = pom.getap().getRadio_ActiveAdmins();
		movetoelement(radio_ActiveAdmins);
		Thread.sleep(2000);
		clickk(radio_ActiveAdmins);
		Thread.sleep(2000);
	}

	@When("^user filter admin by deactivated admin radio button$")
	public void user_filter_admin_by_deactivated_admin_radio_button() throws Throwable {
		WebElement radio_DeactivedAdmins = pom.getap().getRadio_DeactivedAdmins();
		movetoelement(radio_DeactivedAdmins);
		Thread.sleep(2000);
		clickk(radio_DeactivedAdmins);
		Thread.sleep(2000);

	}

	@When("^user filter admin by alladmin radio button$")
	public void user_filter_admin_by_alladmin_radio_button() throws Throwable {
		WebElement radio_AllAdmins = pom.getap().getRadio_AllAdmins();
		movetoelement(radio_AllAdmins);
		Thread.sleep(2000);
		clickk(radio_AllAdmins);
		Thread.sleep(2000);

	}

	@Then("^close the filter icon$")
	public void close_the_filter_icon() throws Throwable {
		pom.getap().getFilter_close().click();
		Thread.sleep(2000);
	}
	// =========================Sort admin list=================================

	@When("^user sort admin name from reverse alphabetical order$")
	public void user_sort_admin_name_from_reverse_alphabetical_order() throws Throwable {
		pom.getap().getNamesort_Uparrow().click();
		Thread.sleep(3000);
	}

	@When("^user sort admin name alphabetical order$")
	public void user_sort_admin_name_alphabetical_order() throws Throwable {
		pom.getap().getNamesort_Downarrow().click();
		Thread.sleep(3000);
	}

	@When("^user sort admin's organization from descending order$")
	public void user_sort_admin_s_organization_from_descending_order() throws Throwable {
		pom.getap().getOrgsort_Uparrow().click();
		Thread.sleep(3000);
	}

	@When("^user sort admin's organization from ascending order$")
	public void user_sort_admin_s_organization_from_ascending_order() throws Throwable {
		pom.getap().getOrgsort_Downarrow().click();
		Thread.sleep(3000);
	}

	@When("^user sort the admin list which is inactive status$")
	public void user_sort_the_admin_list_which_is_inactive_status() throws Throwable {
		pom.getap().getStatussort_Uparrow().click();
		Thread.sleep(3000);
	}

	@Then("^user sort the admin list which is in active status$")
	public void user_sort_the_admin_list_which_is_in_active_status() throws Throwable {
		pom.getap().getStatussort_Downarrow().click();
		Thread.sleep(3000);
	}

	// ==============================CREATENEWADMIN======================================================

	@And("^user click create new admin$")
	public void user_click_create_new_admin() throws Throwable {

		waitforvisibilityofelement(pom.getap().getCreatenewadminicon());
		pom.getap().getCreatenewadminicon().click();
	}

	// validate the mandatory fields
	@When("^user validate the required fields$")
	public void user_validate_the_required_fields() throws Throwable {
		waitforvisibilityofelement(pom.getap().getSubmitbtnlast());
		pom.getap().getSubmitbtnlast().click();
		Thread.sleep(3000);
		pom.getap().getclosepage_validate_emailid().click();
	}

	@When("^user click again create new admin$")
	public void user_click_again_create_new_admin() throws Throwable {

		Thread.sleep(2000);
		waitforvisibilityofelement(pom.getap().getCreatenewadminicon());
		pom.getap().getCreatenewadminicon().click();
	}

	@And("^user enter new emailid$")
	public void user_enter_new_emailid() throws Throwable {
		Thread.sleep(2000);
		String createnewAdminemail = Emailgenerator.CreatenewAdminemail();
		inputOnElement(pom.getap().getCreateemailid(), createnewAdminemail);

	}

	@And("^user enter firstname$")
	public void user_enter_firstname() throws Throwable {
		Thread.sleep(3000);
		String admins_NewUserFn = FileReaderManager.getInstance().getcrinstance().Admins_NewUserFn();
		waitforvisibilityofelement(pom.getap().getCreatefirstname());
		pom.getap().getCreatefirstname().click();
		pom.getap().getCreatefirstname().sendKeys(admins_NewUserFn.trim());
		Thread.sleep(4000);

	}

	@And("^user enter lastname$")
	public void user_enter_lastname() throws Throwable {
		String admins_NewUserLn = FileReaderManager.getInstance().getcrinstance().Admins_NewUserLn();
		waitforvisibilityofelement(pom.getap().getCreatelastname());
		inputOnElement(pom.getap().getCreatelastname(), admins_NewUserLn);

	}

	@And("^user add the new group$")
	public void user_add_the_new_group() throws Throwable {
		pom.getap().getClickgroup().click();
		Thread.sleep(2000);
		Thread.sleep(1000);
		pom.getap().getAddnewgroup().click();
		Thread.sleep(2000);

	}

	// user assign automationqa organizatin for admin
	@And("^user add the new oganization$")
	public void user_add_the_new_oganization() throws Throwable {
		waitforvisibilityofelement(pom.getap().getClickneworganization());
		clickOnElement(pom.getap().getClickneworganization());
		Thread.sleep(2000);
		WebElement addneworganization_automationqa = pom.getap().getAdd_neworganization_automationQA();
		waitforvisibilityofelement(addneworganization_automationqa);
		addneworganization_automationqa.click();

	}

	@And("^user click the submit button last$")
	public void user_click_the_submit_button_last() throws Throwable {
		waitforvisibilityofelement(pom.getap().getSubmitbtnlast());
		clickOnElement(pom.getap().getSubmitbtnlast());

	}

	// ===========================verifynewlycreated
	// admin=========================================

	@When("^user search for newly created admin$")
	public void user_search_for_newly_created_admin() throws Throwable {

		Thread.sleep(4000);
		waitforvisibilityofelement(pom.getap().getSearchiconlast());
		clickOnElement(pom.getap().getSearchiconlast());

		String admins_SearchNewUser = FileReaderManager.getInstance().getcrinstance().Admins_SearchNewUser();
		waitforvisibilityofelement(pom.getap().getEnternewadmin());
		inputOnElement(pom.getap().getEnternewadmin(), admins_SearchNewUser);
		Thread.sleep(5000);

	}

	// verifying the active status of new admin
	@SuppressWarnings("deprecation")
	@When("^user verify status of the new admin$")
	public void user_verify_status_of_the_new_admin() throws Throwable {

		List<WebElement> activestatus = driver.findElements(By.xpath("//span[text()='Active']"));

		if (activestatus.size() < 1) {
			Assert.fail("user should able to see active status ");
		}

	}

	@Then("^close the search field$")
	public void close_the_search_field() throws Throwable {

		Thread.sleep(2000);
		pom.getap().getsearch_fieldClose().click();

	}

	// ======================@EditadminName======================================

	@When("^user enters admin name in the search field$")
	public void user_enters_admin_name_in_the_search_field() throws Throwable {
		Thread.sleep(4000);
		waitforvisibilityofelement(pom.getap().getSearchiconlast());
		clickOnElement(pom.getap().getSearchiconlast());
		Thread.sleep(2000);
		String admins_SearchUser1 = FileReaderManager.getInstance().getcrinstance().getAdmins_SearchUser1().trim();
		waitforvisibilityofelement(pom.getap().getEnternewadmin());
		inputOnElement(pom.getap().getEnternewadmin(), admins_SearchUser1);

	}

	@When("^user click edit pencil icon$")
	public void user_click_edit_pencil_icon() throws Throwable {
		Thread.sleep(2000);
		waitforvisibilityofelement(pom.getap().getPencilicon1());
		clickOnElement(pom.getap().getPencilicon1());
	}

	// edit the admin first name
	@When("^user changes first name of admin$")
	public void user_changes_first_name_of_admin() throws Throwable {
		Thread.sleep(7000);
		pom.getap().getEditfirstname().clear();
		Thread.sleep(3000);
		String admins_EditFnUser1 = FileReaderManager.getInstance().getcrinstance().Admins_EditFnUser1();
		pom.getap().getAddfirstname().sendKeys(admins_EditFnUser1);
	}

	// edit the admin last name
	@When("^user changes last name of admin$")
	public void user_changes_last_name_of_admin() throws Throwable {
		Thread.sleep(2000);
		clearElement(pom.getap().getEditlastname());
		Thread.sleep(3000);
		String admins_EditLnUser1 = FileReaderManager.getInstance().getcrinstance().Admins_EditLnUser1();
		pom.getap().getAddlastname().sendKeys(admins_EditLnUser1);
	}

	@When("^user submit the edit drawer$")
	public void user_submit_the_edit_drawer() throws Throwable {
		waitforvisibilityofelement(pom.getap().getSubmitbtbn());
		clickOnElement(pom.getap().getSubmitbtbn());
	}

	// searching the edited admin from the admin list
	@When("^user search for the name edited admin$")
	public void user_search_for_the_name_edited_admin() throws Throwable {
		Thread.sleep(4000);
		pom.getap().getsearch_fieldClose().click();
		Thread.sleep(2000);
		waitforvisibilityofelement(pom.getap().getSearchiconlast());
		clickOnElement(pom.getap().getSearchiconlast());
		String admins_SearchEditeduser = FileReaderManager.getInstance().getcrinstance().getAdmins_SearchEditeduser()
				.trim();
		pom.getap().getEnteradmin().sendKeys(admins_SearchEditeduser);
	}

	// verify the edited name reflected in the admin list
	@SuppressWarnings("deprecation")
	@When("^user verify the edited name of the admin$")
	public void user_verify_the_edited_name_of_the_admin() throws Throwable {
		Thread.sleep(4000);
		String text = driver.findElement(By.xpath("//table/tbody/tr/td[1]")).getText();
		String admins_SearchEditeduser = FileReaderManager.getInstance().getcrinstance().getAdmins_SearchEditeduser();
		Assert.assertEquals(admins_SearchEditeduser.trim(), text.trim());
	}

	@When("^user again click edit pencil icon$")
	public void user_again_click_edit_pencil_icon() throws Throwable {
		Thread.sleep(2000);
		waitforvisibilityofelement(pom.getap().getPencilicon1());
		clickOnElement(pom.getap().getPencilicon1());

	}

	// again change the admin name into previous name
	@When("^user change the name into previous name$")
	public void user_change_the_name_into_previous_name() throws Throwable {
		Thread.sleep(3000);
		pom.getap().getEditfirstname().clear();
		Thread.sleep(3000);
		String admins_EditFnUser2 = FileReaderManager.getInstance().getcrinstance().Admins_EditFnUser2();
		pom.getap().getAddfirstname().sendKeys(admins_EditFnUser2);
		Thread.sleep(2000);
		clearElement(pom.getap().getEditlastname());
		Thread.sleep(3000);
		String admins_EditLnUser2 = FileReaderManager.getInstance().getcrinstance().Admins_EditLnUser2();
		pom.getap().getAddlastname().sendKeys(admins_EditLnUser2);

	}

	// validating by clicking submit
	@When("^user again click submit btn$")
	public void user_again_click_submit_btn() throws Throwable {
		waitforvisibilityofelement(pom.getap().getSubmitbtbn());
		clickOnElement(pom.getap().getSubmitbtbn());

	}

	// verify the edited name again from the admin list
	@SuppressWarnings("deprecation")
	@When("^user verify the  edited name again$")
	public void user_verify_the_edited_name_again() throws Throwable {

		Thread.sleep(4000);
		pom.getap().getsearch_fieldClose().click();
		Thread.sleep(2000);
		waitforvisibilityofelement(pom.getap().getSearchiconlast());
		clickOnElement(pom.getap().getSearchiconlast());
		String admins_SearchUser1 = FileReaderManager.getInstance().getcrinstance().getAdmins_SearchUser1().trim();
		pom.getap().getEnteradmin().sendKeys(admins_SearchUser1);
		Thread.sleep(3000);
		String text1 = driver.findElement(By.xpath("//table/tbody/tr/td[1]")).getText();
		Assert.assertEquals(admins_SearchUser1.trim(), text1.trim());

	}

	// =====================@verifyemailfield===================================

	@When("^user clicking edit pencil icon$")
	public void user_clicking_edit_pencil_icon() throws Throwable {
		Thread.sleep(4000);
		waitforvisibilityofelement(pom.getap().getPencilicon1());
		clickOnElement(pom.getap().getPencilicon1());
	}

	// verifying sales admin edit drawer email field should be disabled
	@SuppressWarnings("deprecation")
	@Then("^user verify email field is disabled$")
	public void user_verify_email_field_is_disabled() throws Throwable {
		WebElement email_field = pom.getap().getemail_field();
		System.out.println("condition of email field enabeld  " + email_field.isEnabled());
		Assert.assertEquals(true, email_field.isEnabled());

	}

	// =============================@verifyinactiveadmin========================================
	// changing the sales admin Active status into inactive status
	@When("^user click the inactive toggle button$")
	public void user_click_the_inactive_toggle_button() throws Throwable {

		waitforvisibilityofelement(pom.getap().getInactivetoggle());
		clickOnElement(pom.getap().getInactivetoggle());
		Thread.sleep(2000);
        pom.getap().getinactive_OKbtn().click();

	}

	@When("^user submitting the edited drawer$")
	public void user_submitting_the_edited_drawer() throws Throwable {
		waitforvisibilityofelement(pom.getap().getSubmitbtbn());
		clickOnElement(pom.getap().getSubmitbtbn());
	}

	// verify admin status should be inactive
	@SuppressWarnings("deprecation")
	@When("^user verify the inactive status of the admin$")
	public void user_verify_the_inactive_status_of_the_admin() throws Throwable {

		Thread.sleep(2000);
		pom.getap().getsearch_fieldClose().click();
		Thread.sleep(2000);
		waitforvisibilityofelement(pom.getap().getSearchiconlast());
		clickOnElement(pom.getap().getSearchiconlast());
		Thread.sleep(2000);
		String admins_SearchUser1 = FileReaderManager.getInstance().getcrinstance().getAdmins_SearchUser1().trim();
		waitforvisibilityofelement(pom.getap().getEnternewadmin());
		inputOnElement(pom.getap().getEnternewadmin(), admins_SearchUser1);
		Thread.sleep(3000);
		List<WebElement> InActiveStatus = driver.findElements(By.xpath("//span[text()='Inactive']"));

		if (InActiveStatus.size() != 1) {
			Assert.fail("sucessfully verified InActive Status of the admin");
		}
		Thread.sleep(3000);

	}
   //navigate to other tab for sales admin log in
	@When("^user navigates into other tab$")
	public void user_navigates_into_other_tab() throws Throwable {

		Thread.sleep(3000);
		ArrayList<String> tab = new ArrayList<>(driver.getWindowHandles());
		driver.switchTo().window(tab.get(3));

	}

	@When("^sales account admin  enter  \"([^\"]*)\" as useremailid$")
	public void sales_account_admin_enter_as_useremailid(String arg1) throws Throwable {

		Thread.sleep(2000);
		List<WebElement> admingrouptab = driver.findElements(By.xpath("//h2"));
		if (admingrouptab.size() == 1) {
			waitforvisibilityofelement(pom.getlp().getMail1());
			inputOnElement(pom.getlp().getMail1(), arg1);
		} else {
			waitforvisibilityofelement(pom.getlp().getMail());
			inputOnElement(pom.getlp().getMail(), arg1);
		}

	}

	@When("^sales account admin click the nextbutton icon$")
	public void sales_account_admin_click_the_nextbutton_icon() throws Throwable {

		List<WebElement> admingrouptab = driver.findElements(By.xpath("//h2"));
		if (admingrouptab.size() == 1) {
			waitforvisibilityofelement(pom.getlp().getNxtbtn1());
			clickOnElement(pom.getlp().getNxtbtn1());
		} else {
			waitforvisibilityofelement(pom.getlp().getNxtbtn());
			clickOnElement(pom.getlp().getNxtbtn());
		}

	}

	@When("^sales account admin \"([^\"]*)\" as password$")
	public void sales_account_admin_as_password(String arg2) throws Throwable {

		Thread.sleep(3000);
		List<WebElement> admingrouptab2 = driver.findElements(By.xpath("//div[text()='Sign in with Google']"));
		if (admingrouptab2.size() == 1) {
			waitforvisibilityofelement(pom.getlp().getPassword());
			inputOnElement(pom.getlp().getPassword(), arg2);

		} else {
			waitforvisibilityofelement(pom.getlp().getPassword1());
			inputOnElement(pom.getlp().getPassword1(), arg2);
		}

	}

	@When("^sales account admin click nextbtn again$")
	public void sales_account_admin_click_nextbtn_again() throws Throwable {
		List<WebElement> admingrouptab1 = driver.findElements(By.xpath("//div[text()='Sign in with Google']"));
		if (admingrouptab1.size() == 1) {
			waitforvisibilityofelement(pom.getlp().getPassbtn());
			clickOnElement(pom.getlp().getPassbtn());
			Thread.sleep(4000);

		} else {
			waitforvisibilityofelement(pom.getlp().getPassbtn1());
			clickOnElement(pom.getlp().getPassbtn1());
			Thread.sleep(4000);

		}

	}
  //inactive sales admin log in should throw error msg - verify the error msg
	@SuppressWarnings("deprecation")
	@When("^sales account admin verify the error msg$")
	public void sales_account_admin_verify_the_error_msg() throws Throwable {

		waitforvisibilityofelement(
				driver.findElement(By.xpath("(//div[@class='ant-notification-notice-message'])[1]")));

		List<WebElement> invalidtoken_error = driver
				.findElements(By.xpath("(//div[@class='ant-notification-notice-message'])[1]"));
		if (invalidtoken_error.size() != 1) {
			Assert.fail("invalid token error msg should be visible while login");
		}

	}

	// =======================@verifyActiveAdmin================================================
  // navigate to superadmin window
	@When("^user navigates to the superadmin tab$")
	public void user_navigates_to_the_superadmin_tab() throws Throwable {
		Thread.sleep(5000);
		ArrayList<String> tab = new ArrayList<>(driver.getWindowHandles());
		driver.switchTo().window(tab.get(0));

	}

	@When("^user clickss edits pencil icon$")
	public void user_clickss_edits_pencil_icon() throws Throwable {
		Thread.sleep(2000);
		waitforvisibilityofelement(pom.getap().getPencilicon1());
		clickOnElement(pom.getap().getPencilicon1());

	}
 // activate the sales admin  status into active
	@When("^user click the active toggle button$")
	public void user_click_the_active_toggle_button() throws Throwable {

		waitforvisibilityofelement(pom.getap().getActivetoggle());
		clickOnElement(pom.getap().getActivetoggle());
		Thread.sleep(2000);

		pom.getap().getactive_OKbtn().click();

	}

	@When("^users submitss the edited drawer$")
	public void users_submitss_the_edited_drawer() throws Throwable {
		waitforvisibilityofelement(pom.getap().getSubmitbtbn());
		clickOnElement(pom.getap().getSubmitbtbn());

	}
 // verify the sales admin active status
	@SuppressWarnings("deprecation")
	@When("^user verify the active status  of the admin$")
	public void user_verify_the_active_status_of_the_admin() throws Throwable {
		pom.getap().getsearch_fieldClose().click();
		Thread.sleep(2000);
		waitforvisibilityofelement(pom.getap().getSearchiconlast());
		clickOnElement(pom.getap().getSearchiconlast());
		Thread.sleep(2000);
		String admins_SearchUser1 = FileReaderManager.getInstance().getcrinstance().getAdmins_SearchUser1().trim();
		waitforvisibilityofelement(pom.getap().getEnternewadmin());
		inputOnElement(pom.getap().getEnternewadmin(), admins_SearchUser1);
		Thread.sleep(3000);

		List<WebElement> ActiveStatus = driver.findElements(By.xpath("//span[text()='Active']"));

		if (ActiveStatus.size() != 1) {
			Assert.fail("sucessfully verified Active Status of the admin");
		}

	}
	// now again naviagte to the sales admin window
	@When("^user navigating again to the sales account tab$")
	public void user_navigating_again_to_the_sales_account_tab() throws Throwable {

		Thread.sleep(1000);
		ArrayList<String> tab = new ArrayList<>(driver.getWindowHandles());
		driver.switchTo().window(tab.get(3));

	}
    // again login as sales admin
	@When("^sales account admin click login icon$")
	public void sales_account_admin_click_login_icon() throws Throwable {
		Thread.sleep(2000);
		pom.getlp().getIcon().click();
		Thread.sleep(3000);
		List<WebElement> admingrouptab1 = driver.findElements(By.xpath("//a[text()='Add account']"));
		if (admingrouptab1.size() == 1) {
			driver.findElement(By.xpath("//span[text()=' V2 Tester Superuser ']")).click();
			Thread.sleep(9000);

		} else {

			driver.findElement(By.xpath("//div[text()='V2 Tester Superuser']")).click();
			Thread.sleep(9000);

		}

	}
 // log in  sucessfull and verify landing page of sales admin
	@SuppressWarnings("deprecation")
	@Then("^user verify the landing page of sales account$")
	public void user_verify_the_landing_page_of_sales_account() throws Throwable {
		Thread.sleep(7000);
		String title = " SocialSurvey | Organizations  ";
		Assert.assertEquals(title.trim(), driver.getTitle().trim());

	}

	// =========================@verifydeletegroup==============================================
  // naviagte to super admin
	@When("^user navigating to superadmin account$")
	public void user_navigating_to_superadmin_account() throws Throwable {

		Thread.sleep(1000);
		ArrayList<String> tab = new ArrayList<>(driver.getWindowHandles());
		driver.switchTo().window(tab.get(0));

	}

	@When("^user click edit pencils icon$")
	public void user_click_edit_pencils_icon() throws Throwable {
		Thread.sleep(2000);
		waitforvisibilityofelement(pom.getap().getPencilicon1());
		clickOnElement(pom.getap().getPencilicon1());
	}

	@When("^user delete  all the  groups$")
	public void user_delete_all_the_groups() throws Throwable {
		Thread.sleep(4000);
		waitforvisibilityofelement(pom.getap().getDeletegroup());
		movetoelement(pom.getap().getDeletegroup());
		clickk(pom.getap().getDeletegroup());

	}

	@When("^user submit the edits drawers$")
	public void user_submit_the_edits_drawers() throws Throwable {
		waitforvisibilityofelement(pom.getap().getSubmitbtbn());
		clickOnElement(pom.getap().getSubmitbtbn());
	}
// verify no groups been assignd to the super admin
	@SuppressWarnings("deprecation")
	@When("^user verify no groups exist for admin$")
	public void user_verify_no_groups_exist_for_admin() throws Throwable {
		Thread.sleep(3000);
		List<WebElement> admintab = driver.findElements(By.xpath("//td//a[@class='sc-fzoVTD Atfvz']"));
		if (admintab.size() > 0) {
			Assert.fail("user verify no groups exist for admin");
		}

	}

	// =============================@verifyAddgroups========================================

	@When("^user clicks edit pencil icon$")
	public void user_clicks_edit_pencil_icon() throws Throwable {
		Thread.sleep(2000);
		waitforvisibilityofelement(pom.getap().getPencilicon1());
		clickOnElement(pom.getap().getPencilicon1());
	}
 // adding one group to the super admin
	@When("^user add  all the groups$")
	public void user_add_all_the_groups() throws Throwable {

		Thread.sleep(2000);
		pom.getap().getAddgroup_field().click();
		Thread.sleep(3000);
		pom.getap().getAdd_salesgroup().click();

	}

	@When("^user submits edit drawer$")
	public void user_submits_edit_drawer() throws Throwable {
		waitforvisibilityofelement(pom.getap().getSubmitbtbn());
		clickOnElement(pom.getap().getSubmitbtbn());
	}
    //verify the admin been assigned to the admin from admin list
	@SuppressWarnings("deprecation")
	@When("^user verify the  groups of the admin$")
	public void user_verify_the_groups_of_the_admin() throws Throwable {
		Thread.sleep(3000);

		List<WebElement> activestatus = driver.findElements(By.xpath("//td//a[@class='sc-fzoVTD Atfvz']"));

		if (activestatus.size() < 1) {
			Assert.fail(" user verify the  groups of the admin");
		}

	}

	// ==========================@verifydeleteorganization====================================
// delete the assigned  organization of the admin from edit drawer
	@When("^user clicks edit pencils icons$")
	public void user_clicks_edit_pencils_icons() throws Throwable {
		Thread.sleep(2000);
		waitforvisibilityofelement(pom.getap().getPencilicon1());
		clickOnElement(pom.getap().getPencilicon1());
	}

	@When("^user delete  one organization$")
	public void user_delete_one_organization() throws Throwable {

		Thread.sleep(2000);
		WebElement getdelete = pom.getap().getDeleteorganization();
		scrollingup(getdelete);
		Thread.sleep(3000);
		clickOnElement(pom.getap().getDeleteorganization());
		Thread.sleep(2000);

	}

	@When("^user submits the edited drawers$")
	public void user_submits_the_edited_drawers() throws Throwable {
		waitforvisibilityofelement(pom.getap().getSubmitbtbn());
		clickOnElement(pom.getap().getSubmitbtbn());
	}
// verify the admin have o org count from admin list
	@SuppressWarnings("deprecation")
	@When("^user verify the organization count for admin$")
	public void user_verify_the_organization_count_for_admin() throws Throwable {
		Thread.sleep(3000);
		String text2 = driver.findElement(By.xpath("//span[@class='ant-tag sc-jxBCLY kIZXio']")).getText().trim();
		System.out.println("after delete" + text2);
		Assert.assertEquals("0", text2);

	}

	@When("^user verify the org count button is enabled and click$")
	public void user_verify_the_org_count_button_is_enabled_and_click() throws Throwable {
		WebElement Org_countBtn = driver.findElement(By.xpath("//span[@class='ant-tag sc-jxBCLY kIZXio']"));
		if (Org_countBtn.isEnabled()) {

			Org_countBtn.click();
		}

	}
// verify the assigned organization name not exist in the admin's org drawer
	@SuppressWarnings("deprecation")
	@When("^user verify no assigned organization name exist$")
	public void user_verify_no_assigned_organization_name_exist() throws Throwable {
		Thread.sleep(5000);

		List<WebElement> ActiveStatus = driver.findElements(By.xpath("//div[text()='No organizations found']"));

		if (ActiveStatus.size() != 1) {
			Assert.fail("sucessfully verified no organization assigneds to the admin ");
		}

	}

	@Then("^user close the side drawer$")
	public void user_close_the_side_drawer() throws Throwable {

		driver.findElement(By.xpath("//button[@class='ant-drawer-close']")).click();

	}

	// ==============================@verifyaddorganization======================================

	@When("^users click edit pencil icon$")
	public void users_click_edit_pencil_icon() throws Throwable {
		Thread.sleep(2000);
		waitforvisibilityofelement(pom.getap().getPencilicon1());
		clickOnElement(pom.getap().getPencilicon1());
	}

	@When("^user add  one organization$")
	public void user_add_one_organization() throws Throwable {

		waitforvisibilityofelement(pom.getap().getClickneworganization());
		clickOnElement(pom.getap().getClickneworganization());
		Thread.sleep(2000);
		WebElement addneworganization_automationqa = pom.getap().getAdd_neworganization_automationQA();
		waitforvisibilityofelement(addneworganization_automationqa);
		movetoelement(addneworganization_automationqa);
		clickk(addneworganization_automationqa);

	}

	@When("^users submits the edited drawer$")
	public void users_submits_the_edited_drawer() throws Throwable {
		waitforvisibilityofelement(pom.getap().getSubmitbtbn());
		clickOnElement(pom.getap().getSubmitbtbn());
	}
   //verify the assignd org count for the super admin
	@SuppressWarnings("deprecation")
	@When("^user verify the organization count for the  admin$")
	public void user_verify_the_organization_count_for_the_admin() throws Throwable {
		Thread.sleep(3000);
		String text2 = driver.findElement(By.xpath("//span[@class='ant-tag sc-jxBCLY kIZXio']")).getText().trim();
		System.out.println(text2);
		Assert.assertEquals("1", text2);

	}

	@When("^user verify org count button is enabled and click$")
	public void user_verify_org_count_button_is_enabled_and_click() throws Throwable {

		WebElement Org_countBtn = driver.findElement(By.xpath("//span[@class='ant-tag sc-jxBCLY kIZXio']"));
		if (Org_countBtn.isEnabled()) {

			Org_countBtn.click();
		}

	}
	// verify the assigned organization name  exist in the admin's org drawer
	@SuppressWarnings("deprecation")
	@When("^user verify assigned organization name$")
	public void user_verify_assigned_organization_name() throws Throwable {
		Thread.sleep(3000);

		List<WebElement> ActiveStatus = driver.findElements(By.xpath("//div[text()='Admin Organization']"));

		if (ActiveStatus.size() != 1) {
			Assert.fail("sucessfully verified  organization assigneds to the admin ");
		}
	}

	@Then("^user closed the side drawers$")
	public void user_closed_the_side_drawers() throws Throwable {

		driver.findElement(By.xpath("//button[@class='ant-drawer-close']")).click();
	}

//==========================Existing email id admin =====================================

	@When("^user click the create new admin(\\d+)$")
	public void user_click_the_create_new_admin(int arg1) throws Throwable {
		Thread.sleep(2000);
		waitforvisibilityofelement(pom.getap().getCreatenewadminicon());
		pom.getap().getCreatenewadminicon().click();

	}
 // enter alrady exist email id for admin creation
	@And("^user enter existing emailid$")
	public void user_enter_existing_emailid() throws Throwable {
		String admins_ExistingMailId = FileReaderManager.getInstance().getcrinstance().Admins_ExistingMailId();
		waitforvisibilityofelement(pom.getap().getCreateexistingemailid());
		inputOnElement(pom.getap().getCreateexistingemailid(), admins_ExistingMailId);
		Thread.sleep(2000);
	}

	@And("^user enter the firstnameexist$")
	public void user_enter_the_firstnameexist() throws Throwable {
		String admins_ExistingMailFn = FileReaderManager.getInstance().getcrinstance().Admins_ExistingMailFn();
		waitforvisibilityofelement(pom.getap().getCreatefirstnameexist());
		inputOnElement(pom.getap().getCreatefirstnameexist(), admins_ExistingMailFn);

	}

	@And("^user enter the lastnameexist$")
	public void user_enter_the_lastnameexist() throws Throwable {
		String admins_ExistingMailLn = FileReaderManager.getInstance().getcrinstance().Admins_ExistingMailLn();
		waitforvisibilityofelement(pom.getap().getCreatelastnameexist());
		inputOnElement(pom.getap().getCreatelastnameexist(), admins_ExistingMailLn);

	}

	@When("^user selects for onboarding admin group$")
	public void user_selects_for_onboarding_admin_group() throws Throwable {
		pom.getap().getClickgroup().click();
		Thread.sleep(3000);
		pom.getap().getAddnewgroup().click();
	}

	@When("^user assign organization to the admin$")
	public void user_assign_organization_to_the_admin() throws Throwable {
		waitforvisibilityofelement(pom.getap().getClickneworganization());
		clickOnElement(pom.getap().getClickneworganization());
		Thread.sleep(2000);
		WebElement addneworganization_automationqa = pom.getap().getAdd_neworganization_automationQA();
		waitforvisibilityofelement(addneworganization_automationqa);
		addneworganization_automationqa.click();

	}
//  user validate the error msg by clicking submit button
	@Then("^user click the submitbuttonexist$")
	public void user_click_the_submitbuttonexist() throws Throwable {
		waitforvisibilityofelement(pom.getap().getSubmitbuttonexist());
		clickOnElement(pom.getap().getSubmitbuttonexist());
		Thread.sleep(3000);
		pom.getap().getClosepage_ext_emailid().click();

	}

}
