package com.V2SS.Stepdefinition;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.V2SS.helpers.Emailgenerator;
import com.V2SS.helpers.ExcelReader;
import com.V2SS.helpers.Excelwriter;
import com.V2SS.helpers.FileReaderManager;
import com.V2SS.helpers.PageObjectManager;
import com.V2SS.runner.Runnercls;
import com.baseclass.org.BaseClass;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class HHOnboardingAdminLogin extends BaseClass {

	public static WebDriver driver = Runnercls.driver;
	public static PageObjectManager pom = new PageObjectManager(driver);

	@When("^user Navigates to onboarding account window$")
	public void user_Navigates_to_onboarding_account_window() throws Throwable {
		Thread.sleep(2000);
		ArrayList<String> tab = new ArrayList<>(driver.getWindowHandles());
		driver.switchTo().window(tab.get(1));
	}

	// enter onboarding admin user email based g-suite display
	@When("^OnboardingAdminenter \"([^\"]*)\" as useremailid$")
	public void onboardingadminenter_as_useremailid(String arg1) throws Throwable {
		Thread.sleep(2000);
		List<WebElement> admingrouptab = driver.findElements(By.xpath("//h2"));
		if (admingrouptab.size() == 1) {
			waitforvisibilityofelement(pom.getlp().getMail1());
			inputOnElement(pom.getlp().getMail1(), arg1);
		} else {
			waitforvisibilityofelement(pom.getlp().getMail());
			inputOnElement(pom.getlp().getMail(), arg1);
		}

	}

	// click onboarding admin next based g-suite display
	@When("^OnboardingAdmin click the nextbutton icon$")
	public void onboardingadmin_click_the_nextbutton_icon() throws Throwable {

		List<WebElement> admingrouptab = driver.findElements(By.xpath("//h2"));
		if (admingrouptab.size() == 1) {
			waitforvisibilityofelement(pom.getlp().getNxtbtn1());
			clickOnElement(pom.getlp().getNxtbtn1());
		} else {
			waitforvisibilityofelement(pom.getlp().getNxtbtn());
			clickOnElement(pom.getlp().getNxtbtn());
		}

	}

	// enter onboarding admin user email based g-suite display
	@When("^OnboardingAdmin enter \"([^\"]*)\" as password$")
	public void onboardingadmin_enter_as_password(String arg1) throws Throwable {

		Thread.sleep(3000);
		List<WebElement> admingrouptab = driver.findElements(By.xpath("//span[text()='Welcome']"));
		if (admingrouptab.size() == 1) {
			waitforvisibilityofelement(pom.getlp().getPassword());
			inputOnElement(pom.getlp().getPassword(), arg1);

		} else {
			waitforvisibilityofelement(pom.getlp().getPassword1());
			inputOnElement(pom.getlp().getPassword1(), arg1);
		}
	}

	// click onboarding admin next based g-suite display
	@Then("^OnboardingAdmin verify the username in the homepage$")
	public void onboardingadmin_verify_the_username_in_the_homepage() throws Throwable {
		Thread.sleep(1000);
		List<WebElement> admingrouptab1 = driver.findElements(By.xpath("//span[text()='Welcome']"));
		if (admingrouptab1.size() == 1) {
			waitforvisibilityofelement(pom.getlp().getPassbtn());
			clickOnElement(pom.getlp().getPassbtn());
			Thread.sleep(6000);

		} else {
			waitforvisibilityofelement(pom.getlp().getPassbtn1());
			clickOnElement(pom.getlp().getPassbtn1());
			Thread.sleep(6000);

		}
	}

	// ==============================================================================================

	@When("^user verify the Onboarding ss logo menuicon$")
	public void user_verify_the_Onboarding_ss_logo_menuicon() throws Throwable {
		Thread.sleep(2000);
		WebElement sslogoicon = driver.findElement(By.xpath("//div[@class='sc-AxjAm sc-jXPivZ djHTWT']"));
		sslogoicon.click();
		Thread.sleep(3000);

	}

	@When("^user click display anywhere$")
	public void user_click_display_anywhere() throws Throwable {
		WebElement Onbclickdisplay = driver.findElement(By.xpath("(//a)[1]"));
		Onbclickdisplay.click();
		Thread.sleep(2000);

	}

// verify onb_organization icon exist
	@When("^user verify the Onboarding Organizations icon$")
	public void user_verify_the_Onboarding_Organizations_icon() throws Throwable {
		WebElement Orgicon = driver.findElement(By.xpath("//li[@path='/admin/organizations']"));
		Orgicon.click();
		Thread.sleep(2000);

	}

// verify the Onboarding Accounts icon
	@When("^user verify the Onboarding Accounts icon$")
	public void user_verify_the_Onboarding_Accounts_icon() throws Throwable {
		Thread.sleep(2000);
		WebElement OnbAccounticon = driver.findElement(By.xpath("//li[@path='/admin/accounts']"));
		OnbAccounticon.click();
		Thread.sleep(2000);

	}

//	user verify the onboarding grp dashboard icon
	@Then("^user verify the onboarding grp dashboard$")
	public void user_verify_the_onboarding_grp_dashboard() throws Throwable {
		WebElement Onbgrp = driver.findElement(By.xpath("//li[@path='/admin/onboardinggroupdashboard']"));
		Onbgrp.click();
		Thread.sleep(2000);
	}

	// =========================Onboarding Organizationmenu icon========================

	@When("^user click the Onboarding Organization menu icon$")
	public void user_click_the_Onboarding_Organization_menu_icon() throws Throwable {
		WebElement Orgicon = driver.findElement(By.xpath("//li[@path='/admin/organizations']"));
		Orgicon.click();
		Thread.sleep(2000);

	}

	@SuppressWarnings("deprecation")
	@When("^user verify lands on Onboarding Organization page$")
	public void user_verify_lands_on_Onboarding_Organization_page() throws Throwable {
		String text2 = "SocialSurvey | Organizations  ";
		Assert.assertEquals(text2.trim(), driver.getTitle().trim());
		System.out.println("succesfully verified the org landing page");
		Thread.sleep(3000);

	}

	@SuppressWarnings("deprecation")
	@When("^user verify the Onboarding body content on organization page$")
	public void user_verify_the_Onboarding_body_content_on_organization_page() throws Throwable {
		List<WebElement> orgtab = driver.findElements(By.xpath("//table/tbody/tr[1]/td[1]"));
		if (orgtab.size() == 0) {
			Assert.fail("Successfully verifeid the body content of organization page");
		}

	}

	@When("^user click Onboarding Organization no of accounts$")
	public void user_click_Onboarding_Organization_no_of_accounts() throws Throwable {
		Thread.sleep(2000);
		WebElement orgaccounticon = driver.findElement(By.xpath("(//span[@class='ant-tag sc-fznXWL cEvDCP'])[2]"));
		orgaccounticon.click();
		Thread.sleep(3000);

	}

	@When("^user click Onboarding Organization Accounts menu icon$")
	public void user_click_Onboarding_Organization_Accounts_menu_icon() throws Throwable {
		WebElement orgaccountbar = driver.findElement(By.xpath("//li[@path='/admin/organizations/accounts']"));
		orgaccountbar.click();
		Thread.sleep(2000);

	}

	@SuppressWarnings("deprecation")
	@When("^user verify lands on Onboarding Organization Accounts bar by title$")
	public void user_verify_lands_on_Onboarding_Organization_Accounts_bar_by_title() throws Throwable {
		String text = "SocialSurvey | ssqa org | Accounts";
		Assert.assertEquals(text.trim(), driver.getTitle().trim());
		System.out.println("succesfully verified the   Organization Accounts landing page by title");
		Thread.sleep(3000);
	}

	@SuppressWarnings("deprecation")
	@When("^user verify the Onboarding body content on Organization Account$")
	public void user_verify_the_Onboarding_body_content_on_Organization_Account() throws Throwable {
		List<WebElement> orgaccounnt = driver.findElements(By.xpath("//table/tbody/tr[1]/td[1]"));
		if (orgaccounnt.size() == 0) {
			Assert.fail("Successfully verifeid the body content of organization accounts page");
		}

	}

	@SuppressWarnings("deprecation")
	@When("^user verify Onboarding lands on Organization Accounts bar$")
	public void user_verify_Onboarding_lands_on_Organization_Accounts_bar() throws Throwable {
		String Organization_Acounturl = FileReaderManager.getInstance().getcrinstance().getOrganization_Accounturl();
		Assert.assertEquals(Organization_Acounturl.trim(), driver.getCurrentUrl().trim());
		System.out.println("succesfully verified the org Accounts landing page");
		Thread.sleep(3000);

	}

	@When("^user click Onboarding Organization users nav menu icon$")
	public void user_click_Onboarding_Organization_users_nav_menu_icon() throws Throwable {
		WebElement orguserbar = driver.findElement(By.xpath("//li[@path='/admin/organizations/users']"));
		orguserbar.click();
		Thread.sleep(2000);

	}

	@SuppressWarnings("deprecation")
	@When("^user verify Onboarding url lands on Organization user page$")
	public void user_verify_Onboarding_url_lands_on_Organization_user_page() throws Throwable {
		String Organization_userurl = FileReaderManager.getInstance().getcrinstance().getOrganization_userurl();
		Assert.assertEquals(Organization_userurl.trim(), driver.getCurrentUrl().trim());
		System.out.println("succesfully verified the org users landing page");
		Thread.sleep(4000);

	}

	@SuppressWarnings("deprecation")
	@When("^user verify lands on Onboarding Organization users page by title$")
	public void user_verify_lands_on_Onboarding_Organization_users_page_by_title() throws Throwable {
		String text = "SocialSurvey | ssqa org | Users";
		Assert.assertEquals(text.trim(), driver.getTitle().trim());
		System.out.println("succesfully verified the org user landing page by title");
		Thread.sleep(3000);
	}

	@SuppressWarnings("deprecation")
	@When("^user verify the Onboarding body content on Organization users$")
	public void user_verify_the_Onboarding_body_content_on_Organization_users() throws Throwable {
		List<WebElement> orgusertab = driver.findElements(By.xpath("//table/tbody/tr[1]/td[1]"));
		if (orgusertab.size() == 0) {
			Assert.fail("Successfully verifeid the body content of organization user page");
		}
	}

	@When("^user click Onboarding Organization Settings nav menu icon$")
	public void user_click_Onboarding_Organization_Settings_nav_menu_icon() throws Throwable {
		WebElement orgsettingsbar = driver.findElement(By.xpath("//li[@path='/admin/organizations/settings']"));
		orgsettingsbar.click();
		Thread.sleep(2000);

	}

	@SuppressWarnings("deprecation")
	@When("^user verify lands on Onboarding Organization settings page by title$")
	public void user_verify_lands_on_Onboarding_Organization_settings_page_by_title() throws Throwable {
		String text = "SocialSurvey | Organization settings | settings";
		Assert.assertEquals(text.trim(), driver.getTitle().trim());
		System.out.println("succesfully verified the org settings landing page by title");
		Thread.sleep(3000);
	}

	@SuppressWarnings("deprecation")
	@Then("^user verify Onboarding url lands on Organization Settings page$")
	public void user_verify_Onboarding_url_lands_on_Organization_Settings_page() throws Throwable {
		String Organization_settingsurl = FileReaderManager.getInstance().getcrinstance().getOrganization_settingsurl();
		Assert.assertEquals(Organization_settingsurl.trim(), driver.getCurrentUrl().trim());
		System.out.println("succesfully verified the org settings landing page");
		Thread.sleep(4000);

	}

	// ==============================Accounts and view nav menu icon==================

	@When("^user click the Onboarding SS logo icon$")
	public void user_click_the_Onboarding_SS_logo_icon() throws Throwable {
		WebElement sslogoicon = driver.findElement(By.xpath("//div[@class='sc-AxjAm sc-jXPivZ djHTWT']"));
		sslogoicon.click();
		Thread.sleep(3000);
	}

	@When("^user click Onboarding AllOrganization icon$")
	public void user_click_Onboarding_AllOrganization_icon() throws Throwable {
		WebElement AllOrgsbtn = driver.findElement(By.xpath("//a[text()='All Organizations']"));
		AllOrgsbtn.click();
		Thread.sleep(2000);
	}

	@When("^user click Onboarding Allorg button$")
	public void user_click_Onboarding_Allorg_button() throws Throwable {
		WebElement Allaccountsbtn = driver.findElement(By.xpath("(//span[@class='ant-table-column-title'])[2]"));
		Allaccountsbtn.click();
		Thread.sleep(2000);
	}

	@SuppressWarnings("deprecation")
	@When("^user verify lands on Onboarding Allorg page$")
	public void user_verify_lands_on_Onboarding_Allorg_page() throws Throwable {
		String text = "SocialSurvey | Organizations  ";
		Assert.assertEquals(text.trim(), driver.getTitle().trim());
		System.out.println("succesfully verified the org landing page by title");
		Thread.sleep(3000);
	}

	@When("^user click Onboarding Account button$")
	public void user_click_Onboarding_Account_button() throws Throwable {
		WebElement Accounticon = driver.findElement(By.xpath("//li[@path='/admin/accounts']"));
		Accounticon.click();
		Thread.sleep(2000);
	}

	@SuppressWarnings("deprecation")
	@When("^user verify lands on Onboarding Accounts page$")
	public void user_verify_lands_on_Onboarding_Accounts_page() throws Throwable {
		String Accounts_url = FileReaderManager.getInstance().getcrinstance().getAccounts_url();
		Assert.assertEquals(Accounts_url.trim(), driver.getCurrentUrl().trim());
		System.out.println("succesfully verified the accounts landing page");
		Thread.sleep(3000);

	}

	@SuppressWarnings("deprecation")
	@When("^user verify lands on Onboarding Accounts page by title$")
	public void user_verify_lands_on_Onboarding_Accounts_page_by_title() throws Throwable {
		String text1 = "SocialSurvey | Accounts  ";
		Assert.assertEquals(text1.trim(), driver.getTitle().trim());
		System.out.println("succesfully verified the Accounts landing page");
		Thread.sleep(3000);
	}

	@SuppressWarnings("deprecation")
	@When("^user verify Onboarding body content of Accounts page$")
	public void user_verify_Onboarding_body_content_of_Accounts_page() throws Throwable {
		List<WebElement> accounts = driver.findElements(By.xpath("//table/tbody/tr[1]/td[1]"));
		if (accounts.size() == 0) {
			Assert.fail("Successfully verifeid the body content of Accounts page");
		}
	}

	@When("^user click Onboarding view nav button$")
	public void user_click_Onboarding_view_nav_button() throws Throwable {
		WebElement viewnavbtn = driver.findElement(By.xpath("//button[@data-test-view-account-btn='10416']"));
		viewnavbtn.click();
		Thread.sleep(2000);

	}

	@When("^user click on Onboarding Hierarchy nav menu icon$")
	public void user_click_on_Onboarding_Hierarchy_nav_menu_icon() throws Throwable {
		WebElement hierarchynavbtn = driver.findElement(By.xpath("//li[@path='/admin/account/hierarchy']"));
		hierarchynavbtn.click();
		Thread.sleep(2000);

	}

	@SuppressWarnings("deprecation")
	@When("^user verfiy lands on Onboarding Hierarchy page$")
	public void user_verfiy_lands_on_Onboarding_Hierarchy_page() throws Throwable {
		String Hierarchy_url = FileReaderManager.getInstance().getcrinstance().getHierarchy_url();
		Assert.assertEquals(Hierarchy_url.trim(), driver.getCurrentUrl().trim());
		System.out.println("succesfully verified the hierarchy landing page");
		Thread.sleep(3000);

	}

	@SuppressWarnings("deprecation")
	@When("^user verify lands on Onboarding Hierarchy page by title$")
	public void user_verify_lands_on_Onboarding_Hierarchy_page_by_title() throws Throwable {
		String text7 = "SocialSurvey | AmericanQA107 | Hierarchy";
		Assert.assertEquals(text7.trim(), driver.getTitle().trim());
		System.out.println("succesfully verified the Hierarchy landing page by title");
		Thread.sleep(3000);
	}

	@SuppressWarnings("deprecation")
	@When("^user verify lands on Onboarding Hierarchy page by string$")
	public void user_verify_lands_on_Onboarding_Hierarchy_page_by_string() throws Throwable {
		List<WebElement> admingrouptab = driver.findElements(By.xpath("//table/tbody/tr[1]/td[2]"));
		if (admingrouptab.size() == 0) {
			Assert.fail("Successfully verifeid the body content of Hierarchy page by string");
		}
	}

	@When("^user click on Onboarding Settings menu icon$")
	public void user_click_on_Onboarding_Settings_menu_icon() throws Throwable {
		WebElement settingsmenuicon = driver.findElement(By.xpath("//li[@path='/admin/settings']"));
		settingsmenuicon.click();
		Thread.sleep(2000);

	}

	@SuppressWarnings("deprecation")
	@When("^user verify lands on Onboarding settings page$")
	public void user_verify_lands_on_Onboarding_settings_page() throws Throwable {
		String Accountssettings_url = FileReaderManager.getInstance().getcrinstance().getAccountssettings_url();
		Assert.assertEquals(Accountssettings_url.trim(), driver.getCurrentUrl().trim());
		System.out.println("succesfully verified Account settings landing page");
		Thread.sleep(3000);

	}

	@SuppressWarnings("deprecation")
	@When("^user verify lands on Onboarding settings page by title$")
	public void user_verify_lands_on_Onboarding_settings_page_by_title() throws Throwable {
		String text1 = "SocialSurvey | AmericanQA107 | Settings";
		Assert.assertEquals(text1.trim(), driver.getTitle().trim());
		System.out.println("succesfully verified the  settings landing page by title");
		Thread.sleep(3000);
	}

	@When("^user click Onboarding listings nav menu icon$")
	public void user_click_Onboarding_listings_nav_menu_icon() throws Throwable {
		WebElement Listingsnavbtn = driver.findElement(By.xpath("//li[@path='/admin/account/alllocations']"));
		Listingsnavbtn.click();
		Thread.sleep(2000);
	}

	@SuppressWarnings("deprecation")
	@When("^user verify lands on Onboarding Listings page by url$")
	public void user_verify_lands_on_Onboarding_Listings_page_by_url() throws Throwable {
		String listings_url = FileReaderManager.getInstance().getcrinstance().getlistings_url();
		Assert.assertEquals(listings_url.trim(), driver.getCurrentUrl().trim());
		System.out.println("succesfully verified Listings landing page by url");
		Thread.sleep(3000);
	}

	@SuppressWarnings("deprecation")
	@When("^user verify lands on Onboarding Listings page by title$")
	public void user_verify_lands_on_Onboarding_Listings_page_by_title() throws Throwable {
		String text1 = "SocialSurvey | AmericanQA107 | Listing / Locations";
		Assert.assertEquals(text1.trim(), driver.getTitle().trim());
		System.out.println("succesfully verified the settings landing page by title");
		Thread.sleep(3000);
	}

	@SuppressWarnings("deprecation")
	@When("^user verify lands on Onboarding listings page by string$")
	public void user_verify_lands_on_Onboarding_listings_page_by_string() throws Throwable {
		List<WebElement> hierarchy = driver.findElements(By.xpath("//table/tbody/tr[1]/td[2]"));
		if (hierarchy.size() == 0) {
			Assert.fail("Successfully verifeid the body content of Hierarchy page by string");
		}
	}

	@When("^user click on Onboarding Widget configuration$")
	public void user_click_on_Onboarding_Widget_configuration() throws Throwable {
		WebElement Widgetmenuicon = driver.findElement(By.xpath("//li[@path='/admin/account/widget/testimonials/configuration']"));
		Widgetmenuicon.click();
		Thread.sleep(2000);

	}

	@SuppressWarnings("deprecation")
	@When("^user verify lands on Onboarding Widget page$")
	public void user_verify_lands_on_Onboarding_Widget_page() throws Throwable {
		String Widge_url = FileReaderManager.getInstance().getcrinstance().getWidge_url();
		Assert.assertEquals(Widge_url.trim(), driver.getCurrentUrl().trim());
		System.out.println("succesfully verified the widget landing page");
		Thread.sleep(3000);

	}

	@SuppressWarnings("deprecation")
	@When("^user verify lands on Onboarding Widget page by title$")
	public void user_verify_lands_on_Onboarding_Widget_page_by_title() throws Throwable {
		String text1 = "SocialSurvey | AmericanQA107 | Testimonial Widget";
		Assert.assertEquals(text1.trim(), driver.getTitle().trim());
		System.out.println("succesfully verified the Widget landing page by title");
		Thread.sleep(3000);
	}

	@When("^user click Onboarding Reviews management menu icon$")
	public void user_click_Onboarding_Reviews_management_menu_icon() throws Throwable {
		WebElement Reviewsmenuicon = driver.findElement(By.xpath("//li[@path='/admin/account/reviews']"));
		Reviewsmenuicon.click();
		Thread.sleep(2000);

	}

	@SuppressWarnings("deprecation")
	@When("^user verify lands on Onboarding Reviews management by title$")
	public void user_verify_lands_on_Onboarding_Reviews_management_by_title() throws Throwable {
		String text1 = "SocialSurvey | AmericanQA107 | Reviews Management";
		Assert.assertEquals(text1.trim(), driver.getTitle().trim());
		System.out.println("succesfully verified the Reviews management landing page by title");
		Thread.sleep(3000);
	}

	@SuppressWarnings("deprecation")
	@Then("^user verify lands on Onboarding Reviews management page$")
	public void user_verify_lands_on_Onboarding_Reviews_management_page() throws Throwable {
		String ReviewsManagement_url = FileReaderManager.getInstance().getcrinstance().getReviewsManagement_url();
		Assert.assertEquals(ReviewsManagement_url.trim(), driver.getCurrentUrl().trim());
		System.out.println("succesfully verified the Review management landing page");
		Thread.sleep(3000);

	}
	// =================================Onboarding grp dashboard====================================

	@When("^user click the SS logo icon for onb dashboard$")
	public void user_click_the_SS_logo_icon_for_onb_dashboard() throws Throwable {
		WebElement SSlogoicon = driver.findElement(By.xpath("//div[@class='sc-AxjAm sc-jXPivZ djHTWT']"));
		SSlogoicon.click();
		Thread.sleep(2000);
	}

	@When("^user click the Onboarding Allorg button onb dashboard$")
	public void user_click_the_Onboarding_Allorg_button_onb_dashboard() throws Throwable {
		WebElement AllOrgsbtn = driver.findElement(By.xpath("//a[text()='All Organizations']"));
		AllOrgsbtn.click();
		Thread.sleep(2000);
	}

	@When("^user click on Onboarding dashboard$")
	public void user_click_on_Onboarding_dashboard() throws Throwable {
		WebElement onbgrpdash = driver.findElement(By.xpath("//li[@path='/admin/onboardinggroupdashboard']"));
		onbgrpdash.click();
		Thread.sleep(2000);
	}

	@SuppressWarnings("deprecation")
	@When("^user verify lands on Onboarding grp dashboard by url$")
	public void user_verify_lands_on_Onboarding_grp_dashboard_by_url() throws Throwable {
		String Onboardinggroup_url = FileReaderManager.getInstance().getcrinstance().getOnboardinggroup_url();
		Assert.assertEquals(Onboardinggroup_url.trim(), driver.getCurrentUrl().trim());
		System.out.println("succesfully verified the Onboarding group page");
		Thread.sleep(3000);
	}

	@SuppressWarnings("deprecation")
	@Then("^user verify lands on Onboarding grp dashboard by title$")
	public void user_verify_lands_on_Onboarding_grp_dashboard_by_title() throws Throwable {
		String text1 = "SocialSurvey | Onboarding Group Dashboard  ";
		Assert.assertEquals(text1.trim(), driver.getTitle().trim());
		System.out.println("succesfully verified the Onboarding grp  landing page by title");
		Thread.sleep(3000);
	}

	// ===================================Onboarding SSlogo logout menu nav icon========================================

	@When("^user  click the onbaording ss logo menuicon$")
	public void user_click_the_onbaording_ss_logo_menuicon() throws Throwable {
		WebElement SSlogoicon = driver.findElement(By.xpath("//div[@class='sc-AxjAm sc-jXPivZ djHTWT']"));
		SSlogoicon.click();
		Thread.sleep(2000);

	}

	@When("^user click the onbaording logout button$")
	public void user_click_the_onbaording_logout_button() throws Throwable {
		movetoelement(pom.getacc_pg().getSsicon_Logout());
		clickk(pom.getacc_pg().getSsicon_Logout());
		Thread.sleep(3000);

	}

	@SuppressWarnings("deprecation")
	@Then("^user verify onbaording Admin loged out from the application$")
	public void user_verify_onbaording_Admin_loged_out_from_the_application() throws Throwable {
		String logout_url = FileReaderManager.getInstance().getcrinstance().getlogout_url();
		Assert.assertEquals(logout_url.trim(), driver.getCurrentUrl().trim());
		System.out.println("succesfully verified user loggrd out ");
		Thread.sleep(3000);
		pom.getlp().getIcon().click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//div[text()='V2 Tester Onboarding']")).click();
		Thread.sleep(5000);
	}

//============================Onb_verification====================================
 //OnboardingAdmin verify accounts page and create accounts should be visibl
	@SuppressWarnings("deprecation")
	@When("^OnboardingAdmin verify accounts page and create accounts should be visible$")
	public void onboardingadmin_verify_accounts_page_and_create_accounts_should_be_visible() throws Throwable {

		Thread.sleep(4000);
		pom.getacc_pg().getaccounts_icon().click();
        Thread.sleep(3000);
		List<WebElement> createaccount = driver.findElements(By.cssSelector("button[data-test-new-account-btn=true]"));
		if (createaccount.size() != 1) {
			Assert.fail("Create account must be visible to an onboarding account");
		}

	}
//OnboardingAdmin verify admin icon should not be visible
	@SuppressWarnings("deprecation")
	@When("^OnboardingAdmin verify admin icon should not be visible$")
	public void onboardingadmin_verify_admin_icon_should_not_be_visible() throws Throwable {
       Thread.sleep(3000);
		List<WebElement> admintab = driver.findElements(By.cssSelector("li[path='/admin/adminslist']"));
		if (admintab.size() > 0) {
			Assert.fail("Admin icon should not be visible in onboarding admin");
		}

	}

	// ==========================@Onb_admingroupverification==================================================

	@SuppressWarnings("deprecation")
	@Then("^OnboardingAdmin verify admin group icon should not be visible$")
	public void onboardingadmin_verify_admin_group_icon_should_not_be_visible() throws Throwable {
        Thread.sleep(3000);
		List<WebElement> admingrouptab = driver.findElements(By.cssSelector("li[path='/admin/groups']"));
		if (admingrouptab.size() > 0) {
			Assert.fail("AdminGroup icon should not be visible in onboarding admin");
		}
	}

	// =========================@OnboardingAdmin_createAccount=====================================

	@When("^OnboardingAdmin clicks on new account icon$")
	public void onboardingadmin_clicks_on_new_account_icon() throws Throwable {
        Thread.sleep(2000);
		waitforvisibilityofelement(pom.getacc_pg().getNew_Account());
		clickOnElement(pom.getacc_pg().getNew_Account());
		Thread.sleep(2000);

	}

	@When("^OnboardingAdmin enters account name$")
	public void onboardingadmin_enters_account_name() throws Throwable {
        String acc_N_O_Pri_Acc1 = FileReaderManager.getInstance().getcrinstance().getAcc_N_O_Pri_Acc1();
		waitforvisibilityofelement(pom.getacc_pg().getPrimaryaccount());
		inputOnElement(pom.getacc_pg().getPrimaryaccount(), acc_N_O_Pri_Acc1);

	}

	@When("^OnboardingAdmin select business catagory$")
	public void onboardingadmin_select_business_catagory() throws Throwable {
		waitforvisibilityofelement(pom.getacc_pg().getSelectBusiness_catogory());
		clickOnElement(pom.getacc_pg().getSelectBusiness_catogory());
        Thread.sleep(2000);
        pom.getacc_pg().getBusinessCatagory_Mortagage().click();

	}

	@When("^OnboardingAdmin selects the blueprint$")
	public void onboardingadmin_selects_the_blueprint() throws Throwable {
        Thread.sleep(1000);
		waitforvisibilityofelement(pom.getacc_pg().getselectblueprint());
		pom.getacc_pg().getselectblueprint().click();
		Thread.sleep(1000);
		waitforvisibilityofelement(pom.getacc_pg().getadd_defaultBluePrint());
		pom.getacc_pg().getadd_defaultBluePrint().click();

	}

	@When("^OnboardingAdmin selects the organization from dropdown$")
	public void onboardingadmin_selects_the_organization_from_dropdown() throws Throwable {
        Thread.sleep(2000);
		waitforvisibilityofelement(pom.getacc_pg().getSelectOrganization());
		pom.getacc_pg().getSelectOrganization().click();
        Thread.sleep(4000);
		movetoelement(pom.getacc_pg().getadd_Org_AutomationQaTeam());
		clickk(pom.getacc_pg().getadd_Org_AutomationQaTeam());

	}

	@When("^OnboardingAdmin click add new manager$")
	public void onboardingadmin_click_add_new_manager() throws Throwable {
        Thread.sleep(3000);
		pom.getacc_pg().getAdd_New_Manager().click();
		Thread.sleep(1000);
		scrollingup(pom.getacc_pg().getManager_email());

	}

	@When("^OnboardingAdmin enter first name of manager$")
	public void onboardingadmin_enter_first_name_of_manager() throws Throwable {
		Thread.sleep(2000);
		String acc_newOrgManagerFirstname1 = FileReaderManager.getInstance().getcrinstance()
				.getAcc_newOrgManagerFirstname1();
		pom.getacc_pg().getManager_firstname().sendKeys(acc_newOrgManagerFirstname1);

	}

	@When("^OnboardingAdmin enter last name of manager$")
	public void onboardingadmin_enter_last_name_of_manager() throws Throwable {
          Thread.sleep(2000);
		String acc_newOrgManagerLastname1 = FileReaderManager.getInstance().getcrinstance().getAcc_newOrgManagerLastname1();
		pom.getacc_pg().geManager_lastname().sendKeys(acc_newOrgManagerLastname1);

	}

	@When("^OnboardingAdmin enter email of manager$")
	public void onboardingadmin_enter_email_of_manager() throws Throwable {
		Thread.sleep(1000);
		String newAccmanageremail = Emailgenerator.newAccmanageremail();
		pom.getacc_pg().getManager_email().sendKeys(newAccmanageremail);

	}

	@When("^OnboardingAdmin clicksthe submit button$")
	public void onboardingadmin_clicksthe_submit_button() throws Throwable {
		Thread.sleep(2000);
		clickOnElement(pom.getacc_pg().getSubmit_newacc());
	}

	//OnboardingAdmin verify account created popup msg sucessfully
	@SuppressWarnings("deprecation")
	@When("^OnboardingAdmin verify account created sucessfully message$")
	public void onboardingadmin_verify_account_created_sucessfully_message() throws Throwable {
		Thread.sleep(2000);
		waitforvisibilityofelement(pom.getOnb_pg().getAcc_createSucessPopup());
		List<WebElement> createaccountsucess = driver
				.findElements(By.xpath("//span[text()='Account created Successfully.']"));

		if (createaccountsucess.size() != 1) {
			Assert.fail("Create account sucessful msg should pop up");
		}

	}
//OnboardingAdmin verify user created pop up msg sucessfully
	@SuppressWarnings("deprecation")
	@Then("^OnboardingAdmin verify user created sucessfully message$")
	public void onboardingadmin_verify_user_created_sucessfully_message() throws Throwable {

		Thread.sleep(1000);

		List<WebElement> usercreatesucess = driver
				.findElements(By.xpath("//span[text()='User created and assigned successfully']"));

		if (usercreatesucess.size() != 1) {
			Assert.fail("user create and assigned sucessful msg should pop up");
		}

	}

	// ==============================@Onb_Admin NewAccountverify===========================

	@When("^OnboardingAdmin Navigates to all accounts page for onboarding$")
	public void onboardingadmin_Navigates_to_all_accounts_page_for_onboarding() throws Throwable {

	}

	@When("^OnboardingAdmin Clicks on accounts page search icon for onboarding$")
	public void onboardingadmin_Clicks_on_accounts_page_search_icon_for_onboarding() throws Throwable {
		Thread.sleep(2000);
		pom.getacc_pg().getSearch_Icon().click();
	}

	@When("^OnboardingAdmin  Enter  new account name on field for onboarding$")
	public void onboardingadmin_Enter_new_account_name_on_field_for_onboarding() throws Throwable {
		Thread.sleep(2000);
		String acc_N_O_Pri_Acc1 = FileReaderManager.getInstance().getcrinstance().getAcc_N_O_Pri_Acc1();
		waitforvisibilityofelement(pom.getacc_pg().getSearch_Account());
		inputOnElement(pom.getacc_pg().getSearch_Account(), acc_N_O_Pri_Acc1);
	}
//OnboardingAdmin verify the deactivated status for the accoun
	@SuppressWarnings("deprecation")
	@When("^OnboardingAdmin verify the deactivated status for the account$")
	public void onboardingadmin_verify_the_deactivated_status_for_the_account() throws Throwable {
		Thread.sleep(4000);
		List<WebElement> inactivestatus = driver.findElements(By.xpath("//span[text()='Inactive']"));
		if (inactivestatus.size() != 1) {
			Assert.fail("Inactive status should be visible in account");
		}
	}
   //OnboardingAdmin verify the info is onboarding from account list
	@SuppressWarnings("deprecation")
	@When("^OnboardingAdmin verify the info is onboarding$")
	public void onboardingadmin_verify_the_info_is_onboarding() throws Throwable {

		Thread.sleep(1000);
		List<WebElement> onboardingstatus = driver.findElements(By.xpath("//span[text()='Onboarding']"));
		if (onboardingstatus.size() != 1) {
			Assert.fail("account info should be in onboarding status");
		}

	}
 // verify sync to v1 is not enabled before upload the file
	@SuppressWarnings("deprecation")
	@Then("^OnboardingAdmin verify  the v(\\d+) sync is disabled$")
	public void onboardingadmin_verify_the_v_sync_is_disabled(int arg1) throws Throwable {
		Thread.sleep(1000);
		WebElement btndisabled = pom.getOnb_pg().getBefore_Synctov1btn();
		System.out.println("condition of Enabled for disabled btn " + btndisabled.isEnabled());
		Assert.assertEquals(false, btndisabled.isEnabled());

	}

	// =============================@Onb_Admin BulkUpload// ======================================
// write random user email to the xlsx file and store in an arraylist
	@When("^OnboardingAdmin Clicks on view button for the account onboarding$")
	public void onboardingadmin_Clicks_on_view_button_for_the_account_onboarding() throws Throwable {
        Thread.sleep(2000);
		pom.getacc_pg().getView().click();

		// implement file writer here
		for (int i = 1; i < 5; i++) {
			Excelwriter.writeIntoExcel("/Users/dineshkumar/Downloads/Automation Upload File3.xlsx", "Users", i, 6);
		}

		// file reader
		ArrayList<String> ar1 = new ArrayList<String>();
		for (int i = 1; i < 5; i++) {
			ar1.add(ExcelReader.readFromExcel("/Users/dineshkumar/Downloads/Automation Upload File3.xlsx", "Tiers", i,
					1));
		}

		// Assert will be like

		String Region1 = ar1.get(0);
		String Region2 = ar1.get(1);
		String Branch1 = ar1.get(2);
		String Branch2 = ar1.get(3);

	}
 
	// verify the blank status of the hierarchy page 
	@SuppressWarnings("deprecation")
	@When("^OnboardingAdmin verify no tiers present in the hieararchy page$")
	public void onboardingadmin_verify_no_tiers_present_in_the_hieararchy_page() throws Throwable {

		Thread.sleep(2000);
		List<WebElement> notiermsg = driver
				.findElements(By.xpath("//td[text()='Please upload file to view the account hierarchy']"));
		if (notiermsg.size() != 1) {
			Assert.fail("verify no tiers present in the hieararchy page");
		}
	}

	//click upload button
	@When("^OnboardingAdmin clicks upload button for onboarding$")
	public void onboardingadmin_clicks_upload_button_for_onboarding() throws Throwable {

		Thread.sleep(8000);
		pom.getOnb_pg().getUpload_Button().click();
	}
   
	@When("^OnboardingAdmin clicks bulk upload button for onboarding$")
	public void onboardingadmin_clicks_bulk_upload_button_for_onboarding() throws Throwable {
		pom.getOnb_pg().getBulk_upload_click().sendKeys("/Users/dineshkumar/Downloads/Automation Upload File3.xlsx");
        Thread.sleep(32000);
	}
 // verification of uplaod sucessful msg 
	@SuppressWarnings("deprecation")
	@When("^OnboardingAdmin verify the upload sucessfull message$")
	public void onboardingadmin_verify_the_upload_sucessfull_message() throws Throwable {
		waitforvisibilityofelement(pom.getOnb_pg().getUpload_successful());
		List<WebElement> uploadsuccess = driver.findElements(By.xpath("//div[text()='Upload Successful! ']"));
		if (uploadsuccess.size() != 1) {
			Assert.fail("upload sucessful msg should be visible in account");
		}

	}
   
	@Then("^OnboardingAdmin close the drawer$")
	public void onboardingadmin_close_the_drawer() throws Throwable {
      Thread.sleep(2000);
		pom.getOnb_pg().getupload_drawerClose().click();

	}

	// ==========================@Onb_Admin hierarchyverify================================================

	@When("^OnboardingAdmin expands the  tier hierarchy$")
	public void onboardingadmin_expands_the_tier_hierarchy() throws Throwable {
		Thread.sleep(2000);
		driver.navigate().refresh();
		Thread.sleep(3000);
		pom.getOnb_pg().getFirst_Expand().click();
		Thread.sleep(2000);
		pom.getOnb_pg().getSecond_Expand().click();
		Thread.sleep(2000);
		pom.getOnb_pg().getThird_Expand().click();
		Thread.sleep(2000);
		pom.getOnb_pg().getForth_Expand().click();

	}
// verify the hq name and page title  text same
	@SuppressWarnings("deprecation")
	@When("^OnboardingAdmin verify the HQ name in the  tier$")
	public void onboardingadmin_verify_the_HQ_name_in_the_tier() throws Throwable {

		String Hq_text = pom.getOnb_pg().getHq_Text().getText();
		System.out.println(Hq_text);
		String hq = pom.getOnb_pg().getHq_element().getText();
		System.out.println(hq);
		Assert.assertEquals(Hq_text.trim(), hq.trim());

	}
 // verify the  tier regions , xlsx tier region are same
	@SuppressWarnings("deprecation")
	@When("^OnboardingAdmin verify the regions name in the tier$")
	public void onboardingadmin_verify_the_regions_name_in_the_tier() throws Throwable {
		// file reader
		ArrayList<String> ar1 = new ArrayList<String>();
		for (int i = 1; i < 5; i++) {
			ar1.add(ExcelReader.readFromExcel("/Users/dineshkumar/Downloads/Automation Upload File3.xlsx", "Tiers", i,
					1));
		}

		// Assert will be like
		String Region1 = ar1.get(0);
		String Region2 = ar1.get(1);
		String UI_Region1 = pom.getOnb_pg().getRegion1_element().getText();
		Assert.assertEquals(Region1, UI_Region1);
		String UI_Region2 = pom.getOnb_pg().getRegion2_element().getText();
		Assert.assertEquals(Region2, UI_Region2);

	}
	 // verify the  tier branches , xlsx tier branches are same
	@SuppressWarnings("deprecation")
	@When("^OnboardingAdmin verify the branches name in the tier$")
	public void onboardingadmin_verify_the_branches_name_in_the_tier() throws Throwable {

		// file reader
		ArrayList<String> ar1 = new ArrayList<String>();
		for (int i = 1; i < 5; i++) {
			ar1.add(ExcelReader.readFromExcel("/Users/dineshkumar/Downloads/Automation Upload File3.xlsx", "Tiers", i,
					1));
		}

		// Assert will be like

		String Branch1 = ar1.get(2);
		String Branch2 = ar1.get(3);
		String UI_branch1 = pom.getOnb_pg().getBranch1_element().getText();
		Assert.assertEquals(Branch1, UI_branch1);
		String UI_branch2 = pom.getOnb_pg().getBranch2_element().getText();
		Assert.assertEquals(Branch2, UI_branch2);

	}
	// verify the  tier users, xlsx  users are same
	@SuppressWarnings("deprecation")
	@When("^OnboardingAdmin verify the users name in the tier$")
	public void onboardingadmin_verify_the_users_name_in_the_tier() throws Throwable {

		ArrayList<String> ar1 = new ArrayList<String>();
		for (int i = 1; i < 5; i++) {

			for (int j = 1; j < 3; j++) {
				System.out.print(ar1.add(ExcelReader
						.readFromExcel("/Users/dineshkumar/Downloads/Automation Upload File3.xlsx", "Users", i, j)));

			}
			System.out.println();
		}
		String user1 = ar1.get(0) + " " + ar1.get(1);
		String camelcasevalue_user1 = ExcelReader.camelcasevalue(user1);
		System.out.println(camelcasevalue_user1);
		String UI_user1 = pom.getOnb_pg().getUser1_element().getText();
		Assert.assertEquals(camelcasevalue_user1.trim(), UI_user1.trim());

		String user2 = ar1.get(2) + " " + ar1.get(3);
		String camelcasevalue_user2 = ExcelReader.camelcasevalue(user2);
		System.out.println(camelcasevalue_user2);
		String UI_user2 = pom.getOnb_pg().getUser2_element().getText();
		Assert.assertEquals(camelcasevalue_user2.trim(), UI_user2.trim());

		String user3 = ar1.get(4) + " " + ar1.get(5);
		String camelcasevalue_user3 = ExcelReader.camelcasevalue(user3);
		System.out.println(camelcasevalue_user3);
		String UI_user3 = pom.getOnb_pg().getUser3_element().getText();
		Assert.assertEquals(camelcasevalue_user3.trim(), UI_user3.trim());

		String user4 = ar1.get(6) + " " + ar1.get(7);
		String camelcasevalue_user4 = ExcelReader.camelcasevalue(user4);
		System.out.println(camelcasevalue_user4);
		String UI_user4 = pom.getOnb_pg().getUser4_element().getText();
		Assert.assertEquals(camelcasevalue_user4.trim(), UI_user4.trim());

	}

	@When("^OnboardingAdmin naviagate to user page$")
	public void onboardingadmin_naviagate_to_user_page() throws Throwable {
		Thread.sleep(3000);
		pom.getOnb_pg().getUsers_tab().click();
		Thread.sleep(3000);
		WebElement users_firstPage = pom.getOnb_pg().getUsers_firstPage();
		scrollingup(users_firstPage);
		Thread.sleep(2000);

	}
 // verify user name and assigned role in the UI
	@SuppressWarnings({ "deprecation", "unlikely-arg-type" })
	@When("^OnboardingAdmin verify the user name and assigned role$")
	public void onboardingadmin_verify_the_user_name_and_assigned_role() throws Throwable {

		ArrayList<String> ar1 = new ArrayList<String>();
		for (int i = 1; i < 5; i++) {

			for (int j = 1; j < 3; j++) {
				System.out.print(ar1.add(ExcelReader
						.readFromExcel("/Users/dineshkumar/Downloads/Automation Upload File3.xlsx", "Users", i, j)));

			}
			System.out.println();
		}

		System.out.println(ar1);

		String user1 = ar1.get(0) + " " + ar1.get(1);
		String camelcasevalue_user1 = ExcelReader.camelcasevalue(user1);
		List<WebElement> findElements = driver.findElements(By.xpath("//table/tbody/tr/td[2]"));
		for (int i = 0; i < findElements.size(); i++) {
			if (findElements.get(i).equals(camelcasevalue_user1)) {
				Assert.assertEquals(camelcasevalue_user1.trim(), findElements.get(i).getText().trim());
				break;
			} else {
				continue;
			}

		}

	}

	// ===============================@Onb_Addmin SynctoV1==========================================

	@When("^OnboardingAdmin navigates to the account page$")
	public void onboardingadmin_navigates_to_the_account_page() throws Throwable {
		Thread.sleep(3000);
		movetoelement(pom.getacc_pg().getssicon());
		waitforvisibilityofelement(pom.getacc_pg().getSsicon_allorganization());
		movetoelement(pom.getacc_pg().getSsicon_allorganization());
		clickk(pom.getacc_pg().getSsicon_allorganization());
		Thread.sleep(1000);
		movetoelement(pom.getOrg_pg().getNew_Organization());
		pom.getacc_pg().getaccounts_icon().click();
		Thread.sleep(2000);
		movetoelement(pom.getOnbAdmin_pg().getOnb_SearchClose());
		clickk(pom.getOnbAdmin_pg().getOnb_SearchClose());
	}

	@When("^OnboardingAdmin search for uploaded account$")
	public void onboardingadmin_search_for_uploaded_account() throws Throwable {
         Thread.sleep(2000);
		pom.getacc_pg().getSearch_Icon().click();
		Thread.sleep(1000);
		String acc_N_O_Pri_Acc1 = FileReaderManager.getInstance().getcrinstance().getAcc_N_O_Pri_Acc1();
		waitforvisibilityofelement(pom.getacc_pg().getSearch_Account());
		inputOnElement(pom.getacc_pg().getSearch_Account(), acc_N_O_Pri_Acc1);

	}
// verification for sync to v1 button - should enable
	@SuppressWarnings("deprecation")
	@When("^OnboardingAdmin Verify SynctoV(\\d+) button gets enabled$")
	public void onboardingadmin_Verify_SynctoV_button_gets_enabled(int arg1) throws Throwable {
		Thread.sleep(1000);
		WebElement btenabled = pom.getOnb_pg().getSynctov1btn();

		System.out.println("condition of Enabled for enabeld btn " + btenabled.isEnabled());

		Assert.assertEquals(true, btenabled.isEnabled());

	}
//verify sync to v1 drawer
	@SuppressWarnings("deprecation")
	@When("^OnboardingAdmin Click SynctoV(\\d+) and  verify side drawer opens$")
	public void onboardingadmin_Click_SynctoV_and_verify_side_drawer_opens(int arg1) throws Throwable {
		Thread.sleep(2000);
		pom.getOnb_pg().getNot_sync().click();
		Thread.sleep(2000);
		List<WebElement> draweropenverify = driver.findElements(By.xpath(
				"//div[text()='This account is not currently synced with version 1, would you like to sync now?']"));

		if (draweropenverify.size() != 1) {
			Assert.fail("sucessful verify the side drawer open");
		}

	}

	@When("^OnboardingAdmin Click SynctoV(\\d+) within side drawer to confirm$")
	public void onboardingadmin_Click_SynctoV_within_side_drawer_to_confirm(int arg1) throws Throwable {

		Thread.sleep(2000);
		pom.getOnb_pg().getSync_to_V1Btn_submit().click();
		Thread.sleep(12000);
	}
// verify sync to v1 status
	@SuppressWarnings("deprecation")
	@When("^OnboardingAdmin verify Successfully synced notification$")
	public void onboardingadmin_verify_Successfully_synced_notification() throws Throwable {

		List<WebElement> v1syncSucessful = driver
				.findElements(By.xpath("//div[text()='The account has been successfully synced to V1!']"));

		if (v1syncSucessful.size() != 1) {
			Assert.fail("sucessfully verified V1 sync message ");

		}
		pom.getOnb_pg().getSyncToV1_drawerclose().click();

	}
// verification ofsucessfully verified V1 sync column button disable
	@SuppressWarnings("deprecation")
	@When("^OnboardingAdmin Verify SynctoV(\\d+) button is now disabled$")
	public void onboardingadmin_Verify_SynctoV_button_is_now_disabled(int arg1) throws Throwable {
		List<WebElement> v1syncdisabled = driver.findElements(By.xpath("//span[text()='Synced']"));

		if (v1syncdisabled.size() != 1) {
			Assert.fail("sucessfully verified V1 sync column button disable ");
		}

	}
  
	@When("^OnboardingAdmin click on view dropdown$")
	public void onboardingadmin_click_on_view_dropdown() throws Throwable {
		Thread.sleep(2000);
		pom.getacc_pg().getViewdropdown().click();
	}

	@When("^OnboardingAdmin click on activate in the dropdown$")
	public void onboardingadmin_click_on_activate_in_the_dropdown() throws Throwable {
		Thread.sleep(2000);
		pom.getOnb_pg().getActivated_dropdown().click();
		

	}

	@When("^OnboardingAdmin click activate button for confirmation$")
	public void onboardingadmin_click_activate_button_for_confirmation() throws Throwable {
		Thread.sleep(2000);
		pom.getOnb_pg().getActive_confirmation().click();

		Thread.sleep(2000);
	}
//  after sync to v1 activate the account with verification
	@SuppressWarnings("deprecation")
	@When("^OnboardingAdmin verify Account activated popup$")
	public void onboardingadmin_verify_Account_activated_popup() throws Throwable {

		List<WebElement> activatedpopup = driver
				.findElements(By.xpath("//span[text()='Account status updated successfully']"));

		if (activatedpopup.size() != 1) {
			Assert.fail("sucessfully verified account activated popup message ");

		}

	}
// then activated account should not exist in the onboarding admin account
	@SuppressWarnings("deprecation")
	@Then("^OnboardingAdmin verify account does not exist in onboarding$")
	public void onboardingadmin_verify_account_does_not_exist_in_onboarding() throws Throwable {
		Thread.sleep(2000);
		pom.getOnbAdmin_pg().getOnb_SearchClose().click();
		Thread.sleep(2000);
		pom.getacc_pg().getSearch_Icon().click();
		Thread.sleep(2000);
		String acc_N_O_Pri_Acc1 = FileReaderManager.getInstance().getcrinstance().getAcc_N_O_Pri_Acc1();
		waitforvisibilityofelement(pom.getacc_pg().getSearch_Account());
		inputOnElement(pom.getacc_pg().getSearch_Account(), acc_N_O_Pri_Acc1);

		Thread.sleep(3000);
		List<WebElement> firstrow_firstdata = driver
				.findElements(By.xpath("//table/tbody//tr[1]//td[@class='ant-table-row-cell-break-word'][1]"));
		if (firstrow_firstdata.size() > 0) {
			Assert.fail("activated account should not exist in onboarding admin account");
		}
		pom.getOnb_pg().getsearch_close_Onb().click();

	}
// move to super admin
	@When("^user Navigate to super admin account window$")
	public void user_Navigate_to_super_admin_account_window() throws Throwable {
		Thread.sleep(2000);
		ArrayList<String> tab = new ArrayList<>(driver.getWindowHandles());
		driver.switchTo().window(tab.get(0));

	}
// verify the activated account exist in the super admin
	@When("^user search for the activated  account$")
	public void user_search_for_the_activated_account() throws Throwable {

		Thread.sleep(3000);
		pom.getacc_pg().getaccounts_icon().click();
		Thread.sleep(2000);
		waitforvisibilityofelement(pom.getacc_pg().getAll_Accounts());
		movetoelement(pom.getacc_pg().getAll_Accounts());
		clickk(pom.getacc_pg().getAll_Accounts());
		Thread.sleep(1000);
		pom.getacc_pg().getSearch_Icon().click();
		Thread.sleep(2000);

		String acc_N_O_Pri_Acc1 = FileReaderManager.getInstance().getcrinstance().getAcc_N_O_Pri_Acc1();
		waitforvisibilityofelement(pom.getacc_pg().getSearch_Account());
		inputOnElement(pom.getacc_pg().getSearch_Account(), acc_N_O_Pri_Acc1);

	}

	// verify the account sync to v1 column should be blank
	@SuppressWarnings("deprecation")
	@When("^user verify sync to v(\\d+) button is not displayed$")
	public void user_verify_sync_to_v_button_is_not_displayed(int arg1) throws Throwable {
		Thread.sleep(5000);
		List<WebElement> synctov1 = driver.findElements(By.xpath("//span[text()='Not Synced']"));
		if (synctov1.size() > 0) {
			Assert.fail("Sync to v1 should not be visible in super admin");
		}

	}
    // verify the active status of the account
	@SuppressWarnings("deprecation")
	@Then("^user  verify the account in Active status$")
	public void user_verify_the_account_in_Active_status() throws Throwable {
		List<WebElement> ActiveStatus = driver.findElements(By.xpath("//span[text()='Active']"));

		if (ActiveStatus.size() != 1) {
			Assert.fail("sucessfully verified Active Status of the account ");
		}
		pom.getOnb_pg().getsearch_close_sup().click();

	}
 // navigates to the super admin
	@When("^user Navigate to customersupport account window$")
	public void user_Navigate_to_customersupport_account_window() throws Throwable {

		Thread.sleep(2000);
		ArrayList<String> tab = new ArrayList<>(driver.getWindowHandles());
		driver.switchTo().window(tab.get(2));

	}

	@When("^Customer SupportAdmin \"([^\"]*)\" as useremailid$")
	public void customer_SupportAdmin_as_useremailid(String arg1) throws Throwable {

		Thread.sleep(2000);
		waitforvisibilityofelement(pom.getlp().getMail());
		inputOnElement(pom.getlp().getMail(), arg1);

	}

	@When("^Customer SupportAdmin click the nextbutton icon$")
	public void customer_SupportAdmin_click_the_nextbutton_icon() throws Throwable {

		waitforvisibilityofelement(pom.getlp().getNxtbtn());
		clickOnElement(pom.getlp().getNxtbtn());

	}

	@When("^Customer SupportAdmin enter \"([^\"]*)\" as password$")
	public void customer_SupportAdmin_enter_as_password(String arg1) throws Throwable {
		Thread.sleep(2000);
		waitforvisibilityofelement(pom.getlp().getPassword());
		inputOnElement(pom.getlp().getPassword(), arg1);

	}

	@When("^Customer SupportAdmin verify the username in the homepage$")
	public void customer_SupportAdmin_verify_the_username_in_the_homepage() throws Throwable {
		Thread.sleep(1000);
		waitforvisibilityofelement(pom.getlp().getPassbtn());
		clickOnElement(pom.getlp().getPassbtn());
		Thread.sleep(8000);

	}
// verify the activated account exist in the cs admin accounts
	@SuppressWarnings("deprecation")
	@Then("^Customer SupportAdmin verify activated account exist in CS Admin account$")
	public void customer_SupportAdmin_verify_activated_account_exist_in_CS_Admin_account() throws Throwable {

		pom.getacc_pg().getaccounts_icon().click();
		Thread.sleep(3000);
		pom.getacc_pg().getSearch_Icon().click();
		Thread.sleep(2000);

		String acc_N_O_Pri_Acc1 = FileReaderManager.getInstance().getcrinstance().getAcc_N_O_Pri_Acc1();
		waitforvisibilityofelement(pom.getacc_pg().getSearch_Account());
		inputOnElement(pom.getacc_pg().getSearch_Account(), acc_N_O_Pri_Acc1);

		List<WebElement> firstroFirstdata = driver
				.findElements(By.xpath("(//table/tbody/tr/td[@class='ant-table-row-cell-break-word'])[1]"));

		if (firstroFirstdata.size() != 1) {
			Assert.fail("sucessfully activated account exist in the Cs admin ");

		}

		Thread.sleep(2000);
		pom.getCSAdmin_pg().getSearch_close_Cs().click();

	}
}
