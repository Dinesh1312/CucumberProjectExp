package com.V2SS.Stepdefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.V2SS.helpers.PageObjectManager;
import com.V2SS.runner.Runnercls;
import com.baseclass.org.BaseClass;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class FFStepdefinitionUsers extends BaseClass{

	public static WebDriver driver = Runnercls.driver;
	public static PageObjectManager pom = new PageObjectManager(driver);
	
	@When("^User Navigates to the user tab in hierarchy page$")
	public void user_Navigates_to_the_user_tab_in_hierarchy_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   
		Thread.sleep(2000);
		pom.getUser_pg().getuser_tab().click();
		
	}

	@When("^User click user filter button$")
	public void user_click_user_filter_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000);
	    pom.getUser_pg().getUser_filter().click();
	}

	@When("^User search user by their name$")
	public void user_search_user_by_their_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000);
	   pom.getUser_pg().getSearch_Name_Field().sendKeys("dine");
	   
	}

	@When("^User clears the user name from search field$")
	public void user_clears_the_user_name_from_search_field() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(4000);
		//(//i[@class='anticon anticon-close'])[1]
	driver.findElement(By.xpath("(//i[@class='anticon anticon-close'])[2]")).click();
		// pom.getUser_pg().getSearch_Name_Field().clear();
	}

	@When("^User click the select the role$")
	public void user_click_the_select_the_role() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(3000);
	    pom.getUser_pg().getsearchRole_field().click();
	}

	@When("^User select the agent role from dropdown$")
	public void user_select_the_agent_role_from_dropdown() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000);
		movetoelement(pom.getUser_pg().getSearch_Agent());
		clickk(pom.getUser_pg().getSearch_Agent());
		Thread.sleep(2000);
	    driver.findElement(By.xpath("//div[@class='ant-select-selection__rendered']")).click();
	}

	@When("^User select the Tier manager from dropdown$")
	public void user_select_the_Tier_manager_from_dropdown() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000);
		movetoelement(pom.getUser_pg().getSearch_Manager());
		clickk(pom.getUser_pg().getSearch_Manager());
		Thread.sleep(2000);
		  driver.findElement(By.xpath("//div[@class='ant-select-selection__rendered']")).click();
	    
	}

	@When("^User select the show all from dropdown$")
	public void user_select_the_show_all_from_dropdown() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000);
		movetoelement(pom.getUser_pg().getSearch_ShowAll());
		clickk(pom.getUser_pg().getSearch_ShowAll());
	}

	@Then("^User click the clear filter button$")
	public void user_click_the_clear_filter_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000);
	   pom.getUser_pg().getUser_filter_close().click();
	}

	@When("^user sort user based on  alphabetical order of user name$")
	public void user_sort_user_based_on_alphabetical_order_of_user_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000);
	   pom.getUser_pg().getUser_Name_upward().click();
	}

	@When("^user sort org based on reverse alphabetical order user  of name$")
	public void user_sort_org_based_on_reverse_alphabetical_order_user_of_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000);
		 pom.getUser_pg().getUser_Name_Downward().click();
	}

	@When("^user sort user based on alphabetical order of user email$")
	public void user_sort_user_based_on_alphabetical_order_of_user_email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000);
	    pom.getUser_pg().getUser_Email_upward().click();
	}

	@When("^user sort user based on reverse alphabetical order of user email$")
	public void user_sort_user_based_on_reverse_alphabetical_order_of_user_email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000);
	    pom.getUser_pg().getUser_Email_Downward().click();
	}

	@When("^user sort user based on alphabetical order of tier name$")
	public void user_sort_user_based_on_alphabetical_order_of_tier_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000);
	   pom.getUser_pg().getUser_Tier_upward().click();
	}

	@Then("^user sort user based on reverse alphabetical order of tier name$")
	public void user_sort_user_based_on_reverse_alphabetical_order_of_tier_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000);
	    pom.getUser_pg().getUser_Tier_Downward().click();
	}
	@When("^User click the create user button icon$")
	public void user_click_the_create_user_button_icon() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000);
	    pom.getUser_pg().getcreateUser_btn().click();
	}

	@When("^User enter first name of the user$")
	public void user_enter_first_name_of_the_user() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000);
	    pom.getUser_pg().getfirst_name().sendKeys("dinesh");
	}

	@When("^User enter last name of the user$")
	public void user_enter_last_name_of_the_user() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000);
	    pom.getUser_pg().getlast_name().sendKeys("kumar");
	}

	@When("^User enter email id of the user$")
	public void user_enter_email_id_of_the_user() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000);
	    pom.getUser_pg().getemail_user().sendKeys("dinesh+111@gmail.com");
	}

	@When("^User ON Opt-in to SocialSurvey login toggle$")
	public void user_ON_Opt_in_to_SocialSurvey_login_toggle() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000);
	    pom.getUser_pg().getoptIn_SS_loginToggle().click();
	}

	@When("^User click select tier field$")
	public void user_click_select_tier_field() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000);
	    pom.getUser_pg().getselect_tier_field().click();;
	}

	@When("^User select the tier from the dropdown$")
	public void user_select_the_tier_from_the_dropdown() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000);
		 pom.getUser_pg().getchennai_tier().click();
	   
	}

	@When("^User click the select tier role field$")
	public void user_click_the_select_tier_role_field() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000);
		 pom.getUser_pg().getselect_roles_field_create().click();
	}

	@When("^User select the tier role from dropdown$")
	public void user_select_the_tier_role_from_dropdown() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000);
	    pom.getUser_pg().getAgent_role().click();
	}

	@When("^User click add tier and role button$")
	public void user_click_add_tier_and_role_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000);
	    pom.getUser_pg().getTier_role_Adding().click();
	}

	@Then("^User click the create user button$")
	public void user_click_the_create_user_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000);
	    pom.getUser_pg().getCreate_user().click();
	}


	
	
}





