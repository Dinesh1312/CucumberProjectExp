package com.V2SS.Stepdefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.V2SS.helpers.FileReaderManager;
import com.V2SS.helpers.PageObjectManager;
import com.V2SS.runner.Runnercls;
import com.baseclass.org.BaseClass;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class EEStepdefinitionHierarchy extends BaseClass {
  
	
	public static WebDriver driver = Runnercls.driver;
	public static PageObjectManager pom = new PageObjectManager(driver);
	

@When("^User Navigate to all accounts page$")
public void user_Navigate_to_all_accounts_page() throws Throwable {
    Thread.sleep(3000);
	movetoelement(pom.getacc_pg().getssicon());
	waitforvisibilityofelement(pom.getacc_pg().getSsicon_allorganization());
	movetoelement(pom.getacc_pg().getSsicon_allorganization());
	clickk(pom.getacc_pg().getSsicon_allorganization());
	Thread.sleep(1000);
	movetoelement(pom.getOrg_pg().getNew_Organization());
	pom.getacc_pg().getaccounts_icon().click();
	Thread.sleep(2000);
}

@When("^User Click on accounts page search icon$")
public void user_Click_on_accounts_page_search_icon() throws Throwable {
	Thread.sleep(2000);
    pom.getacc_pg().getSearch_Icon().click();
    
}

@When("^User Enter account name for filter$")
public void user_Enter_account_name_for_filter() throws Throwable {
	Thread.sleep(4000);
	String hie_AccountName = FileReaderManager.getInstance().getcrinstance().getHie_AccountName();
    pom.getacc_pg().getSearch_Account().sendKeys(hie_AccountName);
}

@When("^User Click on view button for the account$")
public void user_Click_on_view_button_for_the_account() throws Throwable {
	Thread.sleep(8000);    
	pom.getacc_pg().getView().click();
}

@When("^User Navigate to hierarchy icon$")
public void user_Navigate_to_hierarchy_icon() throws Throwable {
   waitforvisibilityofelement(pom.getHie_pg().getHierarchy_icon());
    pom.getHie_pg().getHierarchy_icon().click();
}

@When("^User Expand the tiers hierarchy$")
public void user_Expand_the_tiers_hierarchy() throws Throwable {
    Thread.sleep(3000);
    pom.getHie_pg().getFirst_Expand().click();
    Thread.sleep(2000);
    pom.getHie_pg().getSecond_Expand().click();
    Thread.sleep(3000);
    pom.getHie_pg().getThird_Expand().click();
    Thread.sleep(2000);
    
}



@When("^User click plus icon for create tier$")
public void user_click_plus_icon_for_create_tier() throws Throwable {
	waitforvisibilityofelement( pom.getHie_pg().getCreateTier());
    pom.getHie_pg().getCreateTier().click();
}

@When("^User Enter the new tier name$")
public void user_Enter_the_new_tier_name() throws Throwable {
	Thread.sleep(2000);
	waitforvisibilityofelement(pom.getHie_pg().getTierName());
	String hie_NewTierName = FileReaderManager.getInstance().getcrinstance().getHie_NewTierName();
    pom.getHie_pg().getTierName().sendKeys(hie_NewTierName);
}

@When("^User Select the parent tier from dropdow$")
public void user_Select_the_parent_tier_from_dropdow() throws Throwable {
    pom.getHie_pg().getParenttier_Name().click();
    Thread.sleep(2000);
   WebElement newyork_tier = pom.getHie_pg().getNewyork_tier();
    movetoelement(newyork_tier);
    Thread.sleep(1000);
    clickk(newyork_tier);
}
@When("^User click create tier button$")
public void user_click_create_tier_button() throws Throwable {
	waitforvisibilityofelement( pom.getHie_pg().getCreateTier_Submit());
    pom.getHie_pg().getCreateTier_Submit().click();
   
}
//-===================================@SearchandFilterTiers======================================================

    
@When("^User click the filter hierarchy button$")
public void user_click_the_filter_hierarchy_button() throws Throwable {
    Thread.sleep(4000);
	waitforvisibilityofelement(pom.getHie_pg().getHierarchy_Filter());
    pom.getHie_pg().getHierarchy_Filter().click();
    
}

@When("^User search tier name in the search field$")
public void user_search_tier_name_in_the_search_field() throws Throwable {
    Thread.sleep(2000);
    pom.getHie_pg().getHierarchy_Search_field().sendKeys("Banglore");
    
}

@When("^User clear the search name in thenfield$")
public void user_clear_the_search_name_in_thenfield() throws Throwable {
    Thread.sleep(2000);
    pom.getHie_pg().getHierarchy_Search_field_close().click();
    
}

@When("^User search the tier catagory in the search field$")
public void user_search_the_tier_catagory_in_the_search_field() throws Throwable {
     Thread.sleep(2000);
     pom.getHie_pg().getHierarchy_Search_field().sendKeys("California");
    
}

@When("^User clear the search catagory in thesearch field$")
public void user_clear_the_search_catagory_in_thesearch_field() throws Throwable {
   Thread.sleep(2000);
    pom.getHie_pg().getHierarchy_Search_field_close().click();
}

@When("^User click the catagory field$")
public void user_click_the_catagory_field() throws Throwable {
    Thread.sleep(2000);
    pom.getHie_pg().getHierarchy_catagory_field().click();
}

@When("^User select the HQ from the dropdown$")
public void user_select_the_HQ_from_the_dropdown() throws Throwable {
	 Thread.sleep(2000);
    pom.getHie_pg().getCatagory_HQ().click();
    Thread.sleep(2000);
    pom.getHie_pg().getHierarchy_catagory_field().click();
}

@When("^User select the Region from the dropdown$")
public void user_select_the_Region_from_the_dropdown() throws Throwable {
   Thread.sleep(2000);
   pom.getHie_pg().getCatagory_REGION().click();
   Thread.sleep(2000);
   pom.getHie_pg().getHierarchy_catagory_field().click();
}

@When("^User select the branch from the dropdown$")
public void user_select_the_branch_from_the_dropdown() throws Throwable {
     Thread.sleep(2000);
    pom.getHie_pg().getCatagory_BRANCH().click();
    Thread.sleep(2000);
    pom.getHie_pg().getHierarchy_catagory_field().click();
}

@When("^User select the showall from the dropdown$")
public void user_select_the_showall_from_the_dropdown() throws Throwable {
   Thread.sleep(2000);
   pom.getHie_pg().getCatagory_showall().click();
}

@When("^User deselect the catagory column$")
public void user_deselect_the_catagory_column() throws Throwable {
   Thread.sleep(2000);
   pom.getHie_pg().getCatagory_column().click();
}

@When("^User deselect the users column$")
public void user_deselect_the_users_column() throws Throwable {
    Thread.sleep(2000);
   pom.getHie_pg().getUsers_column().click();
}

@When("^User deselect the created date$")
public void user_deselect_the_created_date() throws Throwable {
    Thread.sleep(2000);
    pom.getHie_pg().getCreatedDate_column().click();
}

@When("^User select the created date$")
public void user_select_the_created_date() throws Throwable {
	 Thread.sleep(2000);
	 pom.getHie_pg().getCreatedDate_column().click();
}

@When("^User select the users column$")
public void user_select_the_users_column() throws Throwable {
    Thread.sleep(2000);
	 pom.getHie_pg().getUsers_column().click();
}

@When("^User select the catagory column$")
public void user_select_the_catagory_column() throws Throwable {
     Thread.sleep(2000);
	 pom.getHie_pg().getCatagory_column().click();
}

@Then("^User click the close filter$")
public void user_click_the_close_filter() throws Throwable {
    Thread.sleep(2000);
	 pom.getHie_pg().getHierarchy_filter_close().click();
}



@When("^User Click on settings icon next to the Tier you want to Edit$")
public void user_Click_on_settings_icon_next_to_the_Tier_you_want_to_Edit() throws Throwable {
  pom.getHie_pg().getTier_Hierarchy8().click();
    Thread.sleep(2000);
}

@When("^User Edit tier name from the drawer$")
public void user_Edit_tier_name_from_the_drawer() throws Throwable {
   
	Thread.sleep(3000);
    pom.getHie_pg().getEdit_tiername().clear();
    Thread.sleep(4000);
    String hie_NewEdittierName = FileReaderManager.getInstance().getcrinstance().getHie_NewEdittierName();
    pom.getHie_pg().getEdit_tiername().sendKeys(hie_NewEdittierName);
    Thread.sleep(2000);
}


@When("^User toggle off Enable public pages toggle$")
public void user_toggle_off_Enable_public_pages_toggle() throws Throwable {
	Thread.sleep(2000);
	driver.findElement(By.xpath("//button[@id='editTierSettings_enablePublicProfile']")).click();
	
	}

@When("^User toggle on Enable public pages toggle$")
public void user_toggle_on_Enable_public_pages_toggle() throws Throwable {
	Thread.sleep(1000);
	movetoelement(pom.getHie_pg().getEnable_publicpages());
	clickk(pom.getHie_pg().getEnable_publicpages());
    
}

@When("^User toggle off Enable agent's public profiles toggle$")
public void user_toggle_off_Enable_agent_s_public_profiles_toggle() throws Throwable {
    Thread.sleep(2000);
	pom.getHie_pg().getEnable_agent_publicprofiles().click();
}

@When("^User toggle on Enable agent's public profiles toggle$")
public void user_toggle_on_Enable_agent_s_public_profiles_toggle() throws Throwable {
   Thread.sleep(1000);
   pom.getHie_pg().getEnable_agent_publicprofiles().click();
}

@When("^User toggle off Display hierarchy on public pages toggle$")
public void user_toggle_off_Display_hierarchy_on_public_pages_toggle() throws Throwable {
    Thread.sleep(2000);
	pom.getHie_pg().getDisplay_hierarchy_publicpages().click();
}

@When("^User toggle on Display hierarchy on public pages toggle$")
public void user_toggle_on_Display_hierarchy_on_public_pages_toggle() throws Throwable {
   Thread.sleep(1000);
   pom.getHie_pg().getDisplay_hierarchy_publicpages().click();
}

@When("^User toggle off Show contact form on public pages true toggle$")
public void user_toggle_off_Show_contact_form_on_public_pages_true_toggle() throws Throwable {
    Thread.sleep(2000);
    pom.getHie_pg().getShowcontactform_publicpages_true().click();
}

@When("^User toggle on Show contact form on public pages true toggle$")
public void user_toggle_on_Show_contact_form_on_public_pages_true_toggle() throws Throwable {
  Thread.sleep(1000);
  pom.getHie_pg().getShowcontactform_publicpages_true().click();
}

@When("^User close the agent block$")
public void user_close_the_agent_block() throws Throwable {
    Thread.sleep(1000);
	WebElement text = driver.findElement(By.xpath("//span[text()='Maximum number of posts per day']"));
	scrollingup(text);
	Thread.sleep(2000);
	waitforvisibilityofelement(pom.getHie_pg().getAgent_close());
	pom.getHie_pg().getAgent_close().click();
	
}

@When("^User close the manager block$")
public void user_close_the_manager_block() throws Throwable {
    Thread.sleep(3000);
	waitforvisibilityofelement(pom.getHie_pg().getManager_close());
    pom.getHie_pg().getManager_close().click();
}

@When("^User click Send contact form to field$")
public void user_click_Send_contact_form_to_field() throws Throwable {
     Thread.sleep(2000);
	waitforvisibilityofelement(pom.getHie_pg().getSend_contact_formto_field());
    pom.getHie_pg().getSend_contact_formto_field().click();
}
@When("^User Add manager to the field$")
public void user_Add_manager_to_the_field() throws Throwable {
    Thread.sleep(2000);
	driver.findElement(By.xpath("(//i[@class='anticon anticon-check ant-select-selected-icon'])[1]")).click();
	
}



@When("^User Add agent to the field$")
public void user_Add_agent_to_the_field() throws Throwable {
   
	Thread.sleep(2000);
	driver.findElement(By.xpath("(//i[@class='anticon anticon-check ant-select-selected-icon'])[2]")).click();
	
	}


@When("^User drag Minimum score to auto-post on social media slide bar$")
public void user_drag_Minimum_score_to_auto_post_on_social_media_slide_bar() throws Throwable {
    Thread.sleep(2000);
	waitforvisibilityofelement(pom.getHie_pg().getSlide_auto_post_on_social_media());
   WebElement slide_auto_post_on_social_media = pom.getHie_pg().getSlide_auto_post_on_social_media();
   Sliding(slide_auto_post_on_social_media);
   
}

@When("^User clear Maximum number of posts per day field$")
public void user_clear_Maximum_number_of_posts_per_day_field() throws Throwable {
   Thread.sleep(2000);
   waitforvisibilityofelement(pom.getHie_pg().getMaximum_number_ofpostsper_day_field());
   pom.getHie_pg().getMaximum_number_ofpostsper_day_field().clear();
}

@When("^User edit Maximum number of posts per day field$")
public void user_edit_Maximum_number_of_posts_per_day_field() throws Throwable {
	Thread.sleep(2000);
	waitforvisibilityofelement(pom.getHie_pg().getMaximum_number_ofpostsper_day_field());
	 pom.getHie_pg().getMaximum_number_ofpostsper_day_field().sendKeys("4");
	
}

@When("^User clear Minimum gap between posts time$")
public void user_clear_Minimum_gap_between_posts_time() throws Throwable {
    Thread.sleep(2000);
	waitforvisibilityofelement( pom.getHie_pg().getMinimum_gap_between_posts_Close());
   pom.getHie_pg().getMinimum_gap_between_posts_Close().click();
}

@When("^User click Minimum gap between posts field$")
public void user_click_Minimum_gap_between_posts_field() throws Throwable {
    Thread.sleep(2000);
	waitforvisibilityofelement(pom.getHie_pg().getSelectTime_filed());
   pom.getHie_pg().getSelectTime_filed().click();
}

@When("^User Select hour from dropdown$")
public void user_Select_hour_from_dropdown() throws Throwable {
    Thread.sleep(2000);
	waitforvisibilityofelement(pom.getHie_pg().getSelectTime_Hour_17());
	movetoelement(pom.getHie_pg().getSelectTime_Hour_17());
	clickk(pom.getHie_pg().getSelectTime_Hour_17());
}

@When("^User select minutes from dropdown$")
public void user_select_minutes_from_dropdown() throws Throwable {
	Thread.sleep(2000);
	movetoelement(pom.getHie_pg().getSelectTime_Min_10());
	clickk(pom.getHie_pg().getSelectTime_Min_10());
}

@When("^User drag Minimum to send survey completion email to agents slide bar$")
public void user_drag_Minimum_to_send_survey_completion_email_to_agents_slide_bar() throws Throwable {
    Thread.sleep(2000);
	waitforvisibilityofelement(pom.getHie_pg().getSlide_survey_completion_emailto_agents());
	WebElement slide_survey_completion_emailto_agents = pom.getHie_pg().getSlide_survey_completion_emailto_agents();
	Sliding(slide_survey_completion_emailto_agents);
}

@When("^User drag Minimum to send survey completion SMS to agents slide bar$")
public void user_drag_Minimum_to_send_survey_completion_SMS_to_agents_slide_bar() throws Throwable {
    Thread.sleep(2000);
	WebElement slide_survey_completionSMS_agents = pom.getHie_pg().getSlide_survey_completionSMS_agents();
	Sliding(slide_survey_completionSMS_agents);
	
}

@When("^User clicks submit button$")
public void user_clicks_submit_button() throws Throwable {
   Thread.sleep(2000);
    pom.getHie_pg().getEdit_Submit().click();
}

@Then("^User clicks confirm button$")
public void user_clicks_confirm_button() throws Throwable {
     Thread.sleep(2000);
    driver.findElement(By.xpath("(//button[@class='ant-btn ant-btn-primary'])[2]")).click();
}





@When("^User Click on settings icon next to the Tier you want to Move$")
public void user_Click_on_settings_icon_next_to_the_Tier_you_want_to_Move() throws Throwable {
   Thread.sleep(4000);
	pom.getHie_pg().getTier_Hierarchy8().click();
}


@When("^user change the parent for the tier$")
public void user_change_the_parent_for_the_tier() throws Throwable {
   Thread.sleep(4000);
   pom.getHie_pg().getEditParent_move().click();
   movetoelement(pom.getHie_pg().getCalifornia_tier());
   Thread.sleep(2000);
   clickk(pom.getHie_pg().getCalifornia_tier());
   
}

@Then("^user click the submit for move tier$")
public void user_click_the_submit_for_move_tier() throws Throwable {
    Thread.sleep(2000);
    pom.getHie_pg().getEdit_Submit().click();
    Thread.sleep(2000);
 
}


@Then("^User click the confirm button$")
public void user_click_the_confirm_button() throws Throwable {
     Thread.sleep(2000);
    driver.findElement(By.xpath("(//button[@class='ant-btn ant-btn-primary'])[2]")).click();
}







@When("^User Click on settings icon next to the Tier you want to Delete$")
public void user_Click_on_settings_icon_next_to_the_Tier_you_want_to_Delete() throws Throwable {
    Thread.sleep(5000);
    pom.getHie_pg().getTier_Hierarchy5().click();
	
}



@When("^User click the delete this tier button$")
public void user_click_the_delete_this_tier_button() throws Throwable {
  Thread.sleep(3000);
 scrollingup( pom.getHie_pg().getDeletethisTier_button());
   pom.getHie_pg().getDeletethisTier_button().click();
}

@When("^user click back to edit button$")
public void user_click_back_to_edit_button() throws Throwable {
   
	Thread.sleep(3000);
   pom.getHie_pg().getBacktoEDit().click();
}
@When("^user again click the delete this tier button$")
public void user_again_click_the_delete_this_tier_button() throws Throwable {
    Thread.sleep(1000);
	scrollingup( pom.getHie_pg().getDeletethisTier_button());
	Thread.sleep(2000);
	 pom.getHie_pg().getDeletethisTier_button().click();
}

@Then("^user click delete button$")
public void user_click_delete_button() throws Throwable {
  Thread.sleep(2000);
  pom.getHie_pg().getDeleteTier().click();
	   
	 
	  
}

}

