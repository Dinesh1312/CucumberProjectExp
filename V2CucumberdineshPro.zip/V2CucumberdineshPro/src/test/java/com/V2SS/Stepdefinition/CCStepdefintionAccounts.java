package com.V2SS.Stepdefinition;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.V2SS.helpers.FileReaderManager;
import com.V2SS.helpers.PageObjectManager;
import com.V2SS.runner.Runnercls;
import com.baseclass.org.BaseClass;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class CCStepdefintionAccounts extends BaseClass {

	public static WebDriver driver = Runnercls.driver;
	public static PageObjectManager pom = new PageObjectManager(driver);

	
	// ------------------------verify requiredfields----------------------------------------------

		@When("^user click new account$")
		public void user_click_new_account() throws Throwable {
		Thread.sleep(4000);
		pom.getacc_pg().getAccounts_Tab().click();
		 Thread.sleep(2000);
	     waitforvisibilityofelement(pom.getacc_pg().getNew_Account());
	     clickOnElement(pom.getacc_pg().getNew_Account());

		}

		@When("^user click submit button$")
		public void user_click_submit_button() throws Throwable {
			waitforvisibilityofelement(pom.getacc_pg().getSubmit_newacc());
			clickOnElement(pom.getacc_pg().getSubmit_newacc());
		}
		//verify the create account  requird fields validation
		@SuppressWarnings("deprecation")
		@When("^user verify the required field msgs$")
		public void user_verify_the_required_field_msgs() throws Throwable {
		 Thread.sleep(3000);
		List<WebElement> validation1 = driver
					.findElements(By.xpath("//div[text()='Please enter valid Primary Account Name']"));

			if (validation1.size() != 1) {
				Assert.fail(" verify Please enter valid Primary Account Name");
			}
			
			 Thread.sleep(1000);
			List<WebElement> validation2 = driver
					.findElements(By.xpath("//div[text()='Please select a Business Category']"));

			if (validation2.size() != 1) {
				Assert.fail(" verify Please select a Business Category");
			}
			
			 Thread.sleep(1000);
			List<WebElement> validation3 = driver
					.findElements(By.xpath("//div[text()='Please select a Blueprint']"));

			if (validation3.size() != 1) {
				Assert.fail(" verify Please select a Blueprint");
			}
			
			 Thread.sleep(1000);
			List<WebElement> validation4 = driver
					.findElements(By.xpath("//div[text()='Please select an Organization']"));

			if (validation4.size() != 1) {
				Assert.fail(" verify Please select an Organization");
			}
		}

		
      //close the drawer 
		@Then("^user close the new account page$")
		public void user_close_the_new_account_page() throws Throwable {

			waitforvisibilityofelement(pom.getacc_pg().getNewaccPage_close());
			clickOnElement(pom.getacc_pg().getNewaccPage_close());
		}

	
	
	
		// --------------------create new account with existing organization--------------------------

		@When("^user click on new account icon$")
		public void user_click_on_new_account_icon() throws Throwable {
			
			waitforvisibilityofelement(pom.getacc_pg().getNew_Account());
			clickOnElement(pom.getacc_pg().getNew_Account());
			Thread.sleep(2000);
		}

		@When("^user enter account name$")
		public void user_enter_account_name() throws Throwable {
			
			 String acc_E_O_Pri_Acc = FileReaderManager.getInstance().getcrinstance().getAcc_E_O_Pri_Acc();
			waitforvisibilityofelement(pom.getacc_pg().getPrimaryaccount());
			inputOnElement(pom.getacc_pg().getPrimaryaccount(),acc_E_O_Pri_Acc);

		}

		
      //user select the business catagory 
		@When("^user select business catagory$")
		public void user_select_business_catagory() throws Throwable {
			
			waitforvisibilityofelement(pom.getacc_pg().getSelectBusiness_catogory());
			clickOnElement(pom.getacc_pg().getSelectBusiness_catogory());

			Thread.sleep(2000);

			pom.getacc_pg().getBusinessCatagory_Mortagage().click();
		}
		
		@When("^user select the blueprint$")
		public void user_select_the_blueprint() throws Throwable {
		    // Write code here that turns the phrase above into concrete actions
			Thread.sleep(1000);
			waitforvisibilityofelement(pom.getacc_pg().getselectblueprint());
			pom.getacc_pg().getselectblueprint().click();
			Thread.sleep(1000);
			waitforvisibilityofelement(pom.getacc_pg().getadd_defaultBluePrint());
			pom.getacc_pg().getadd_defaultBluePrint().click();
		   
		}

		
		@When("^user selectsthe organization from dropdown$")
		public void user_selectsthe_organization_from_dropdown() throws Throwable {
		    
			Thread.sleep(2000);
			waitforvisibilityofelement(pom.getacc_pg().getSelectOrganization());
			clickOnElement(pom.getacc_pg().getSelectOrganization());

			Thread.sleep(5000);

			pom.getacc_pg().getAdd_Org_QAteamOrganization().click();
			
			
		}

	/*	@When("^user clicks add new manager$")
		public void user_clicks_add_new_manager() throws Throwable {
		    
			Thread.sleep(3000);
		    pom.getacc_pg().getAdd_New_Manager().click();
		    Thread.sleep(1000);
		    scrollingup(pom.getacc_pg().getManager_email());
		}

		@When("^user enters first name of manager$")
		public void user_enters_first_name_of_manager() throws Throwable {
		   
			Thread.sleep(2000);
			   pom.getacc_pg().getManager_firstname().sendKeys("manager");
		}

		@When("^user enters last name of manager$")
		public void user_enters_last_name_of_manager() throws Throwable {
		    
			Thread.sleep(2000);
			   pom.getacc_pg().geManager_lastname().sendKeys("last");
			
		}

		@When("^user enters email of manager$")
		public void user_enters_email_of_manager() throws Throwable {
		    
			Thread.sleep(1000);
		    pom.getacc_pg().getManager_email().sendKeys("lokeshfrf+3@gamil.com");
			
		}
*/

		@When("^user click the submit button$")
		public void user_click_the_submit_button() throws Throwable {
			
			Thread.sleep(2000);
			clickOnElement(pom.getacc_pg().getSubmit_newacc());
			
		}
		
		@SuppressWarnings("deprecation")
		@Then("^user verify the account create sucessfully msg$")
		public void user_verify_the_account_create_sucessfully_msg() throws Throwable {
			Thread.sleep(2000);
			waitforvisibilityofelement(pom.getOnb_pg().getAcc_createSucessPopup());
			List<WebElement> createaccountsucess = driver
					.findElements(By.xpath("//span[text()='Account created Successfully.']"));

			if (createaccountsucess.size() != 1) {
				Assert.fail("Create account sucessful msg should pop up");
			}

			
		}
		

		// -------------------------creataccountwith new organization--------------------------------------------

		@When("^user clicking on new account icon$")
		public void user_clicking_on_new_account_icon() throws Throwable {
			Thread.sleep(3000);
			waitforvisibilityofelement(pom.getacc_pg().getNew_Account());
			clickOnElement(pom.getacc_pg().getNew_Account());

		}

		@When("^user enters account name$")
		public void user_enters_account_name() throws Throwable {
			Thread.sleep(2000);
			waitforvisibilityofelement(pom.getacc_pg().getPrimaryaccount());
			clearElement(pom.getacc_pg().getPrimaryaccount());
			Thread.sleep(2000);
			String acc_N_O_Pri_Acc = FileReaderManager.getInstance().getcrinstance().getAcc_N_O_Pri_Acc();
			inputOnElement(pom.getacc_pg().getPrimaryaccount(), acc_N_O_Pri_Acc);

		}

		@When("^user clicks business catagory$")
		public void user_clicks_business_catagory() throws Throwable {
			Thread.sleep(2000);
            waitforvisibilityofelement(pom.getacc_pg().getSelectBusiness_catogory());
			clickOnElement(pom.getacc_pg().getSelectBusiness_catogory());

		}

		@When("^user selects business catagory$")
		public void user_selects_business_catagory() throws Throwable {
			Thread.sleep(2000);
            pom.getacc_pg().getBusinessCatagory_RealEstate().click();

		}
		
		@When("^user selects blueprint$")
		public void user_selects_blueprint() throws Throwable {
		   Thread.sleep(1000);
			waitforvisibilityofelement(pom.getacc_pg().getselectblueprint());
			pom.getacc_pg().getselectblueprint().click();
			Thread.sleep(1000);
			waitforvisibilityofelement(pom.getacc_pg().getadd_defaultBluePrint());
			pom.getacc_pg().getadd_defaultBluePrint().click();
		   
		}


		@When("^user clicks organization of the account$")
		public void user_clicks_organization_of_the_account() throws Throwable {
			Thread.sleep(2000);
            waitforvisibilityofelement(pom.getacc_pg().getSelectOrganization());
			clickOnElement(pom.getacc_pg().getSelectOrganization());
		}

		@When("^user clicks create new organization$")
		public void user_clicks_create_new_organization() throws Throwable {
			Thread.sleep(2000);
			waitforvisibilityofelement(pom.getacc_pg().getCreateNewOrg());
			clickOnElement(pom.getacc_pg().getCreateNewOrg());
		}

		@When("^user enters organization name$")
		public void user_enters_organization_name() throws Throwable {
			Thread.sleep(2000);
			String acc_newOrgName = FileReaderManager.getInstance().getcrinstance().getAcc_newOrgName();
			waitforvisibilityofelement(pom.getacc_pg().getEnternewOrg());
			inputOnElement(pom.getacc_pg().getEnternewOrg(), acc_newOrgName);
		}
		
		@When("^user enters orgnaization contact name$")
		public void user_enters_orgnaization_contact_name() throws Throwable {
			Thread.sleep(2000);
			String acc_newOrgcontactName = FileReaderManager.getInstance().getcrinstance().getAcc_newOrgcontactName();
		   pom.getacc_pg().getEnternewOrg_ContactName().sendKeys(acc_newOrgcontactName);
		}

		@When("^user enters organizations contact email$")
		public void user_enters_organizations_contact_email() throws Throwable {
			
			Thread.sleep(2000);
			String acc_newOrgcontactEmail = FileReaderManager.getInstance().getcrinstance().getAcc_newOrgcontactEmail();
		    pom.getacc_pg().getEnternewOrg_ContactEmail().sendKeys(acc_newOrgcontactEmail);
		    Thread.sleep(1000);
		    scrollingup(pom.getacc_pg().getAdd_New_Manager());
		}

		@When("^user enters organizations contact number$")
		public void user_enters_organizations_contact_number() throws Throwable {
			Thread.sleep(2000);
			String acc_newOrgcontactNumber = FileReaderManager.getInstance().getcrinstance().getAcc_newOrgcontactNumber();
		    pom.getacc_pg().getEnternewOrg_ContactNumber().sendKeys(acc_newOrgcontactNumber);
		}

		@When("^user clicks onboarding owner field$")
		public void user_clicks_onboarding_owner_field() throws Throwable {
			Thread.sleep(2000);
		    pom.getacc_pg().getEnternewOrg_OnboardingOwner().click();
		    
		}

		@When("^user select admin from dropdown for onboarding owner$")
		public void user_select_admin_from_dropdown_for_onboarding_owner() throws Throwable {
			Thread.sleep(2000);
		  movetoelement(pom.getacc_pg().getOnboardingOwner_onboardingadmin());
		  clickk(pom.getacc_pg().getOnboardingOwner_onboardingadmin());
		}

		@When("^user click add new manager$")
		public void user_click_add_new_manager() throws Throwable {
			Thread.sleep(3000);
		    pom.getacc_pg().getAdd_New_Manager().click();
		    Thread.sleep(1000);
		    scrollingup(pom.getacc_pg().getManager_email());
		}

		@When("^user enter first name of manager$")
		public void user_enter_first_name_of_manager() throws Throwable {
			Thread.sleep(2000);
			String acc_newOrgManagerFirstname = FileReaderManager.getInstance().getcrinstance().getAcc_newOrgManagerFirstname();
		   pom.getacc_pg().getManager_firstname().sendKeys(acc_newOrgManagerFirstname);
		}

		@When("^user enter last name of manager$")
		public void user_enter_last_name_of_manager() throws Throwable {
			Thread.sleep(2000);
			String acc_newOrgManagerLastname = FileReaderManager.getInstance().getcrinstance().getAcc_newOrgManagerLastname();
		   pom.getacc_pg().geManager_lastname().sendKeys(acc_newOrgManagerLastname);
		}

		@When("^user enter email of manager$")
		public void user_enter_email_of_manager() throws Throwable {
			Thread.sleep(1000);
			String acc_newOrgManagerEmail = FileReaderManager.getInstance().getcrinstance().getAcc_newOrgManagerEmail();
		    pom.getacc_pg().getManager_email().sendKeys(acc_newOrgManagerEmail);
		}



		@When("^user clicks the submit button$")
		public void user_clicks_the_submit_button() throws Throwable {
		    Thread.sleep(2000);
			clickOnElement(pom.getacc_pg().getSubmit_newacc());
			Thread.sleep(3000);
			}
		// verify the account and managr user create pop up msg 
		@SuppressWarnings("deprecation")
		@Then("^user verify the account and user create sucessfully msg$")
		public void user_verify_the_account_and_user_create_sucessfully_msg() throws Throwable {
		   Thread.sleep(2000);
			waitforvisibilityofelement(pom.getOnb_pg().getAcc_createSucessPopup());
			List<WebElement> createaccountsucess = driver
					.findElements(By.xpath("//span[text()='Account created Successfully.']"));

			if (createaccountsucess.size() != 1) {
				Assert.fail("Create account sucessful msg should pop up");
			}
			
			Thread.sleep(1000);

			List<WebElement> usercreatesucess = driver
					.findElements(By.xpath("//span[text()='User created and assigned successfully']"));

			if (usercreatesucess.size() != 1) {
				Assert.fail("user create and assigned sucessful msg should pop up");
			}
		}
	
  // ----------------------AssignAdmins------------------------------------------------//

	@When("^user click the searchicon button$")
	public void user_click_the_searchicon_button() throws Throwable {
        Thread.sleep(2000);
		waitforvisibilityofelement(pom.getacc_pg().getSearch_Icon());
		clickOnElement(pom.getacc_pg().getSearch_Icon());
		Thread.sleep(2000);
	}

	@When("^user enter search keyword for account company$")
	public void user_enter_search_keyword_for_account_company() throws Throwable {

		waitforvisibilityofelement(pom.getacc_pg().getSearch_Account());
		  String acc_E_O_Pri_Acc = FileReaderManager.getInstance().getcrinstance().getAcc_E_O_Pri_Acc();
		inputOnElement(pom.getacc_pg().getSearch_Account(), acc_E_O_Pri_Acc);

		clickOnElement(pom.getacc_pg().getAll_Accounts());
		Thread.sleep(5000);

	}

	@When("^user click on down arrow in View tab for the account$")
	public void user_click_on_down_arrow_in_View_tab_for_the_account() throws Throwable {

		waitforvisibilityofelement(pom.getacc_pg().getViewdropdown());
		clickOnElement(pom.getacc_pg().getViewdropdown());
	}

	@When("^user click on assign admin$")
	public void user_click_on_assign_admin() throws Throwable {                        
	waitforvisibilityofelement(pom.getacc_pg().getAssignadmin());
		clickOnElement(pom.getacc_pg().getAssignadmin());

	}

	@When("^user Search the CSM name from dropdown$")
	public void user_Search_the_CSM_name_from_dropdown() throws Throwable {
       waitforvisibilityofelement(pom.getacc_pg().getSelectadmin());
		clickOnElement(pom.getacc_pg().getSelectadmin());
		Thread.sleep(2000);

	}

	@When("^user select the name from dropdown$")
	public void user_select_the_name_from_dropdown() throws Throwable {
        Thread.sleep(3000);
		pom.getacc_pg().getDinesh_dropdown_admin().click();
		Thread.sleep(2000);

	}
// user choose any admin from dropdown
	@When("^user click Assign Admin$")
	public void user_click_Assign_Admin() throws Throwable {
         waitforvisibilityofelement(pom.getacc_pg().getAssignbtn());
		clickOnElement(pom.getacc_pg().getAssignbtn());
		Thread.sleep(3000);
	}

	@Then("^user navigate to my accounts tab$")
	public void user_navigate_to_my_accounts_tab() throws Throwable {
		waitforvisibilityofelement(pom.getacc_pg().getSearchclose());
		clickOnElement(pom.getacc_pg().getSearchclose());
		Thread.sleep(3000);
		clickOnElement(pom.getacc_pg().getMy_Accounts());
		Thread.sleep(2000);

	}
	
	// ----------------------AssignManager------------------------------------------------//
	@When("^user search for the newly create account$")
	public void user_search_for_the_newly_create_account() throws Throwable {
		 Thread.sleep(2000);
			waitforvisibilityofelement(pom.getacc_pg().getSearch_Icon());
			clickOnElement(pom.getacc_pg().getSearch_Icon());
			Thread.sleep(2000);
			waitforvisibilityofelement(pom.getacc_pg().getSearch_Account());
			  String acc_E_O_Pri_Acc = FileReaderManager.getInstance().getcrinstance().getAcc_E_O_Pri_Acc();
			inputOnElement(pom.getacc_pg().getSearch_Account(), acc_E_O_Pri_Acc);
            clickOnElement(pom.getacc_pg().getAll_Accounts());
			Thread.sleep(3000);
		
	}

	@SuppressWarnings("deprecation")
	@Then("^user verify the assigned account in myaccounts$")
	public void user_verify_the_assigned_account_in_myaccounts() throws Throwable {
		Thread.sleep(3000);
        List<WebElement> accountrow = driver.findElements(By.xpath("//table/tbody/tr"));
        if (accountrow.size() != 1) {
			Assert.fail("user verify the assigned account in myaccounts");
		}
	}

	@When("^user click assign manager from view dropdown$")
	public void user_click_assign_manager_from_view_dropdown() throws Throwable {
		waitforvisibilityofelement(pom.getacc_pg().getViewdropdown());
		clickOnElement(pom.getacc_pg().getViewdropdown());
		waitforvisibilityofelement(pom.getacc_pg().getAssign_Manager_DropDown());
		pom.getacc_pg().getAssign_Manager_DropDown().click();
	}

	@When("^user select the account manager from manager list$")
	public void user_select_the_account_manager_from_manager_list() throws Throwable {
		Thread.sleep(3000);
		pom.getacc_pg().getAssignManagerDD_field().click();
		Thread.sleep(2000);
		waitforvisibilityofelement(pom.getacc_pg().getNithin_Manager());
		pom.getacc_pg().getNithin_Manager().click();
		Thread.sleep(2000);
	}

	@When("^user click Assign button$")
	public void user_click_Assign_button() throws Throwable {
		waitforvisibilityofelement(pom.getacc_pg().getAssignbtn());
		clickOnElement(pom.getacc_pg().getAssignbtn());
		
		
	}
    //verify the account manager pop up msg 
	@SuppressWarnings("deprecation")
	@When("^user verify the assigned account manager sucessfully$")
	public void user_verify_the_assigned_account_manager_sucessfully() throws Throwable {
		Thread.sleep(2000);
		List<WebElement> AccMangaerpopup = driver.findElements(By.xpath("//span[text()='Account manager assigned successfully']"));
          if (AccMangaerpopup.size() != 1) {
			Assert.fail("user verify the assigned account manager sucessfully");
		}
		
	}
     
	@When("^user click edit account from dropdown$")
	public void user_click_edit_account_from_dropdown() throws Throwable {
		waitforvisibilityofelement(pom.getacc_pg().getViewdropdown());
		clickOnElement(pom.getacc_pg().getViewdropdown());
		waitforvisibilityofelement(pom.getacc_pg().getEdit_Account_Dropdown());
		pom.getacc_pg().getEdit_Account_Dropdown().click();
	}
    //verify the edit account drawe
	@SuppressWarnings("deprecation")
	@When("^user verify the edit account drawer$")
	public void user_verify_the_edit_account_drawer() throws Throwable {
		Thread.sleep(2000);
		List<WebElement> editdrawerverify = driver.findElements(By.xpath("//div[text()='Edit Account']"));
        if (editdrawerverify.size() != 1) {
			Assert.fail("user verify the edit account drawer");
		}
		
		
	}
   //user edit the account name from drawer
	@When("^user edit the primary account name$")
	public void user_edit_the_primary_account_name() throws Throwable {
		Thread.sleep(4000);
	    pom.getacc_pg().getEditAccount_Name().clear();
	    Thread.sleep(4000);
	    String acc_Edited_Pri_Acc = FileReaderManager.getInstance().getcrinstance().getAcc_Edited_Pri_Acc();
	    pom.getacc_pg().getEditAccount_Name().sendKeys(acc_Edited_Pri_Acc);
	    Thread.sleep(2000);
	}

	@When("^user change the primary catagory of account$")
	public void user_change_the_primary_catagory_of_account() throws Throwable {
	    waitforvisibilityofelement(pom.getacc_pg().getEdit_BusinessCatagory());
		pom.getacc_pg().getEdit_BusinessCatagory().click();
		waitforvisibilityofelement(pom.getacc_pg().getEditBusiness_catagory_accounting());
		pom.getacc_pg().getEditBusiness_catagory_accounting().click();
	}

	@When("^user click submit for edit$")
	public void user_click_submit_for_edit() throws Throwable {
		Thread.sleep(2000);
		waitforvisibilityofelement(pom.getacc_pg().getEdit_submit());
		pom.getacc_pg().getEdit_submit().click();
	}

	@SuppressWarnings("deprecation")
	@When("^user verify the Account updated sucessfully msg$")
	public void user_verify_the_Account_updated_sucessfully_msg() throws Throwable {
	    Thread.sleep(2000);
		List<WebElement> accountupdatepopup = driver.findElements(By.xpath("//span[text()='Account updated successfully!']"));
         if (accountupdatepopup.size() != 1) {
			Assert.fail("user verify the Account updated sucessfully msg");
		}
	}
	
	//vrify the editded account name from the account list
		@SuppressWarnings("deprecation")
		@When("^user search and verify edited account$")
		public void user_search_and_verify_edited_account() throws Throwable {
			waitforvisibilityofelement(pom.getacc_pg().getSearchclose());
			clickOnElement(pom.getacc_pg().getSearchclose());
			 Thread.sleep(2000);
			waitforvisibilityofelement(pom.getacc_pg().getSearch_Icon());
			clickOnElement(pom.getacc_pg().getSearch_Icon());
			Thread.sleep(2000);
			waitforvisibilityofelement(pom.getacc_pg().getSearch_Account());
			String acc_Edited_Pri_Acc = FileReaderManager.getInstance().getcrinstance().getAcc_Edited_Pri_Acc();
			pom.getacc_pg().getSearch_Account().sendKeys(acc_Edited_Pri_Acc);
			Thread.sleep(3000);	
			List<WebElement> accountrow = driver.findElements(By.xpath("//table/tbody/tr"));
            if (accountrow.size() != 1) {
					Assert.fail("user verify the assigned account in myaccounts");
				}	
		pom.getacc_pg().getSearchclose().click();
		}

		   
	}


	
	

