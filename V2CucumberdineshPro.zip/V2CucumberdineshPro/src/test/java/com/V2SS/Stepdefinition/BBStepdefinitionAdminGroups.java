package com.V2SS.Stepdefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.V2SS.helpers.FileReaderManager;
import com.V2SS.helpers.PageObjectManager;
import com.V2SS.runner.Runnercls;
import com.baseclass.org.BaseClass;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class BBStepdefinitionAdminGroups extends BaseClass {

	public static WebDriver driver = Runnercls.driver;
	public static PageObjectManager pom = new PageObjectManager(driver);
	
	//==========================adminlisPagination======================================

	@When("^user navigates to admingroup tab$")
	public void user_navigates_to_admingroup_tab() throws Throwable {
	    Thread.sleep(5000);
		waitforvisibilityofelement(pom.getadm_grp().getTab_EnlargeIcon());
		pom.getadm_grp().getTab_EnlargeIcon().click();
		Thread.sleep(2000); 
		waitforvisibilityofelement(pom.getadm_grp().getAdminGroupIcon());
	   pom.getadm_grp().getAdminGroupIcon().click();
	   
	}
// select one admin group from the dashboard -
	@When("^user select the admin group page$")
	public void user_select_the_admin_group_page() throws Throwable {
	   
		Thread.sleep(2000); 
	   WebElement adminGroup_Page = pom.getadm_grp().getAdminGroup_Page();
	   movetoelement(adminGroup_Page);
	   clickk(adminGroup_Page);
	}
 // click onboarding admin group
	@When("^user click onboarding admin group list$")
	public void user_click_onboarding_admin_group_list() throws Throwable {
	   
		Thread.sleep(2000); 
		waitforvisibilityofelement(pom.getadm_grp().getMembers_List());
	    pom.getadm_grp().getMembers_List().click();
	    
	}

	@When("^user click nextpage of onboarding admin list$")
	public void user_click_nextpage_of_onboarding_admin_list() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000); 
		waitforvisibilityofelement(pom.getadm_grp().getMembers_List());
		pom.getadm_grp().getPg_NextPg_Arrow().click();
	}

	@When("^user click lastpage of onboarding admin list$")
	public void user_click_lastpage_of_onboarding_admin_list() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000); 
		pom.getadm_grp().getLastPg().click();
	}

	@When("^user click previouspage of onboarding admin list$")
	public void user_click_previouspage_of_onboarding_admin_list() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000); 
		pom.getadm_grp().getPg_PreviousPg_Arrow().click();
	}

	@When("^user click firstpage of onboarding admin list$")
	public void user_click_firstpage_of_onboarding_admin_list() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000); 
		pom.getadm_grp().getFirstPg_Arrow().click();
	}

	@Then("^user close the onboarding admin list page$")
	public void user_close_the_onboarding_admin_list_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000); 
		pom.getadm_grp().getAdminList_Close().click();
		
		
		
	}

	//===============================admingroupEdit========================================================
	
	@When("^user click the edit pencil icon of onboardinng group$")
	public void user_click_the_edit_pencil_icon_of_onboardinng_group() throws Throwable {
		waitforvisibilityofelement(pom.getadm_grp().getOnboarding_EditPencil());
		Thread.sleep(2000); 
		pom.getadm_grp().getOnboarding_EditPencil().click();
	}

	@When("^user edit the group name$")
	public void user_edit_the_group_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000);
		pom.getadm_grp().getOnboarding_groupName().clear();
		Thread.sleep(2000); 
		String admin_GrpName = FileReaderManager.getInstance().getcrinstance().getAdmin_GrpName();
		pom.getadm_grp().getOnboarding_groupName().sendKeys(admin_GrpName);
	}

	@When("^user edit the description of onboarding group$")
	public void user_edit_the_description_of_onboarding_group() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000);
		pom.getadm_grp().getText_area().clear();
		Thread.sleep(2000); 
		 String admin_GrpDescription = FileReaderManager.getInstance().getcrinstance().getAdmin_GrpDescription();
		pom.getadm_grp().getText_area().sendKeys(admin_GrpDescription);
	}
// assign anton waugh admin to the onboarding admin grp
	@When("^user select the admin for onboarding group$")
	public void user_select_the_admin_for_onboarding_group() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    WebElement admin_comboboxField = pom.getadm_grp().getAdmin_comboboxField();
	    admin_comboboxField.click();
	    Thread.sleep(2000);
	    
	    WebElement antonWaugh_Admin = pom.getadm_grp().getAntonWaugh_Admin();
	    waitforvisibilityofelement(pom.getadm_grp().getAntonWaugh_Admin());
	    movetoelement(antonWaugh_Admin);
	    clickk(antonWaugh_Admin);
	    Thread.sleep(2000); 
	   
	}
//validate by click submit  
	@When("^user click submit button of onboarding edit drawer$")
	public void user_click_submit_button_of_onboarding_edit_drawer() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   pom.getadm_grp().getEditOnb_Group_Submit().click();
	   Thread.sleep(4000); 
	}

	@When("^user click again the edit pencil icon of onboardinng group$")
	public void user_click_again_the_edit_pencil_icon_of_onboardinng_group() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    pom.getadm_grp().getOnboarding_EditPencil().click();
	    Thread.sleep(2000); 
	}
// again navigate to the edit 
	@When("^user navigate to the last page of onboarding admin list$")
	public void user_navigate_to_the_last_page_of_onboarding_admin_list() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   scrollingup(pom.getadm_grp().getPg_NextPg_Arrow());
	   Thread.sleep(1000); 
	   pom.getadm_grp().getLastPg().click();
	   
	   Thread.sleep(2000); 
	}

	// delete the  assigned admin from onb_grp and verify the count
	@When("^user delete the onboarding admin from the onboarding group$")
	public void user_delete_the_onboarding_admin_from_the_onboarding_group() throws Throwable {
		Thread.sleep(2000); 
		WebElement anton_waugh_delete = pom.getadm_grp().getAnton_waugh_delete();
		   movetoelement(anton_waugh_delete);
		   clickk(anton_waugh_delete);
		  Thread.sleep(2000); 
		 pom.getadm_grp().getEditOnb_Group_Submit().click(); 
		 Thread.sleep(1000);
		 pom.getadm_grp().getAdminGroupIcon().click();
		 Thread.sleep(2000);
		 
	}


	
}
