package com.V2SS.Stepdefinition;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.V2SS.helpers.FileReaderManager;
import com.V2SS.helpers.PageObjectManager;
import com.V2SS.runner.Runnercls;
import com.baseclass.org.BaseClass;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class GGStepdefinitionOnboarding extends BaseClass{

	
	public static WebDriver driver = Runnercls.driver;
	public static PageObjectManager pom = new PageObjectManager(driver);
	
	
	
	//======================@Onboarding Acc creation=========================================
	
	

	@When("^user clicks on new account icon$")
	public void user_clicks_on_new_account_icon() throws Throwable {
		
		pom.getacc_pg().getaccounts_icon().click();
		Thread.sleep(2000);
		waitforvisibilityofelement(pom.getacc_pg().getNew_Account());
		clickOnElement(pom.getacc_pg().getNew_Account());
		Thread.sleep(2000);
	}

	@When("^users enters account name$")
	public void users_enters_account_name() throws Throwable {
		
		String acc_N_O_Pri_Acc = FileReaderManager.getInstance().getcrinstance().getAcc_N_O_Pri_Acc();
		waitforvisibilityofelement(pom.getacc_pg().getPrimaryaccount());
		inputOnElement(pom.getacc_pg().getPrimaryaccount(),acc_N_O_Pri_Acc);
	}

	@When("^users selects business catagory$")
	public void users_selects_business_catagory() throws Throwable {

		waitforvisibilityofelement(pom.getacc_pg().getSelectBusiness_catogory());
		clickOnElement(pom.getacc_pg().getSelectBusiness_catogory());
         Thread.sleep(2000);
        pom.getacc_pg().getBusinessCatagory_Mortagage().click();
	}

	@When("^users selects the blueprint$")
	public void users_selects_the_blueprint() throws Throwable {
		Thread.sleep(1000);
		waitforvisibilityofelement(pom.getacc_pg().getselectblueprint());
		pom.getacc_pg().getselectblueprint().click();
		Thread.sleep(1000);
		waitforvisibilityofelement(pom.getacc_pg().getadd_defaultBluePrint());
		pom.getacc_pg().getadd_defaultBluePrint().click();
	}
       
	@When("^users selects the organization from dropdown$")
	public void users_selects_the_organization_from_dropdown() throws Throwable {
		 Thread.sleep(2000);
		 waitforvisibilityofelement(pom.getacc_pg().getSelectOrganization());
		 clickOnElement(pom.getacc_pg().getSelectOrganization());
          Thread.sleep(5000);
          pom.getacc_pg().getAdd_Org_QAteamOrganization().click();
	}

	@When("^users click add new manager$")
	public void users_click_add_new_manager() throws Throwable {
		Thread.sleep(3000);
	    pom.getacc_pg().getAdd_New_Manager().click();
	    Thread.sleep(1000);
	    scrollingup(pom.getacc_pg().getManager_email());
	}

	@When("^users enter first name of manager$")
	public void users_enter_first_name_of_manager() throws Throwable {
		Thread.sleep(2000);
		 String acc_newOrgManagerFirstname = FileReaderManager.getInstance().getcrinstance().getAcc_newOrgManagerFirstname();
		   pom.getacc_pg().getManager_firstname().sendKeys(acc_newOrgManagerFirstname);
	}

	@When("^users enter last name of manager$")
	public void users_enter_last_name_of_manager() throws Throwable {
		   Thread.sleep(2000);
		   String acc_newOrgManagerLastname = FileReaderManager.getInstance().getcrinstance().getAcc_newOrgManagerLastname();
		   pom.getacc_pg().geManager_lastname().sendKeys(acc_newOrgManagerLastname);
		   
	}

	@When("^users enter email of manager$")
	public void users_enter_email_of_manager() throws Throwable {
		  Thread.sleep(1000);
		  String acc_newOrgManagerEmail = FileReaderManager.getInstance().getcrinstance().getAcc_newOrgManagerEmail();
	     pom.getacc_pg().getManager_email().sendKeys(acc_newOrgManagerEmail);
	}

	@When("^users clicksthe submit button$")
	public void users_clicksthe_submit_button() throws Throwable {
		Thread.sleep(2000);
		clickOnElement(pom.getacc_pg().getSubmit_newacc());
		
	}

	@SuppressWarnings("deprecation")
	@When("^users verify account created sucessfully message$")
	public void users_verify_account_created_sucessfully_message() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		Thread.sleep(2000); 
  List<WebElement> createaccountsucess = driver.findElements(By.xpath("//span[text()='Account created Successfully.']"));

   if (createaccountsucess.size() != 1) {
	  Assert.fail("Create account sucessful msg should pop up");
}
		
		
	}

	@SuppressWarnings("deprecation")
	@Then("^users verify user created sucessfully message$")
	public void users_verify_user_created_sucessfully_message() throws Throwable {
	     Thread.sleep(1000);
		
		 List<WebElement> usercreatesucess = driver.findElements(By.xpath("//span[text()='User created and assigned successfully']"));
		// waitforvisibilityofelements(usercreatesucess);
		   if (usercreatesucess.size() != 1) {
			  Assert.fail("user create and assigned sucessful msg should pop up");
		}
				
		
	}
	
	
	
	
	//==============================@NewAccountverify===========================
	

	@When("^User Navigates to all accounts page for onboarding$")
	public void user_Navigates_to_all_accounts_page_for_onboarding() throws Throwable {
	   
		Thread.sleep(3000);
		movetoelement(pom.getacc_pg().getssicon());
		waitforvisibilityofelement(pom.getacc_pg().getSsicon_allorganization());
		movetoelement(pom.getacc_pg().getSsicon_allorganization());
		clickk(pom.getacc_pg().getSsicon_allorganization());
		Thread.sleep(1000);
		movetoelement(pom.getOrg_pg().getNew_Organization());
		pom.getacc_pg().getaccounts_icon().click();
		Thread.sleep(2000);
		waitforvisibilityofelement(pom.getacc_pg().getAll_Accounts());
		movetoelement(pom.getacc_pg().getAll_Accounts());
		clickk(pom.getacc_pg().getAll_Accounts());
		
	}

	@When("^User Clicks on accounts page search icon for onboarding$")
	public void user_Clicks_on_accounts_page_search_icon_for_onboarding() throws Throwable {
		Thread.sleep(2000);
		   pom.getacc_pg().getSearch_Icon().click();
		
		
	}

	@When("^User Enter  new account name on field for onboarding$")
	public void user_Enter_new_account_name_on_field_for_onboarding() throws Throwable {
		Thread.sleep(2000);
		String acc_N_O_Pri_Acc = FileReaderManager.getInstance().getcrinstance().getAcc_N_O_Pri_Acc();
		waitforvisibilityofelement(pom.getacc_pg().getSearch_Account());
		inputOnElement(pom.getacc_pg().getSearch_Account(),acc_N_O_Pri_Acc);
	}

	@SuppressWarnings("deprecation")
	@When("^user verify the deactivated status for the account$")
	public void user_verify_the_deactivated_status_for_the_account() throws Throwable {
		Thread.sleep(4000);
		 List<WebElement> inactivestatus = driver.findElements(By.xpath("//span[text()='Inactive']"));
		   if (inactivestatus.size() != 1) {
			  Assert.fail("Inactive status should be visible in account");
		}
		
	}

	@SuppressWarnings("deprecation")
	@When("^user verify the info is onboarding$")
	public void user_verify_the_info_is_onboarding() throws Throwable {
		Thread.sleep(1000);
		
		 List<WebElement> onboardingstatus = driver.findElements(By.xpath("//span[text()='Onboarding']"));
		   if (onboardingstatus.size() != 1) {
			  Assert.fail("account info should be in onboarding status");
		}
		
	}

	
	@SuppressWarnings("deprecation")
	@Then("^user verify  the v(\\d+) sync is disabled$")
	public void user_verify_the_v_sync_is_disabled(int arg1) throws Throwable {
		Thread.sleep(1000);
		WebElement btndisabled = driver.findElement(By.xpath("//button[@class='ant-btn sc-ptDSg eYGQDi']"));
		  
			   
			   
			System.out.println("condition of Enabled for disabled btn " +btndisabled.isEnabled());
			 
			  Assert.assertEquals(false, btndisabled.isEnabled());
		   
			  
		   
	}
	
	
	//=====================================@BulkUpload ======================================

	
	@When("^User Clicks on view button for the account onboarding$")
	public void user_Clicks_on_view_button_for_the_account_onboarding() throws Throwable {
	    
		Thread.sleep(2000);
		   pom.getacc_pg().getView().click();
		
		
	}

	@When("^User clicks upload button for onboarding$")
	public void user_clicks_upload_button_for_onboarding() throws Throwable {
		Thread.sleep(10000);
	    pom.getOnb_pg().getUpload_Button().click();
		
	}

	@When("^User clicks bulk upload button for onboarding$")
	public void user_clicks_bulk_upload_button_for_onboarding() throws Throwable {
	    
		pom.getOnb_pg().getBulk_upload_click().sendKeys("/Users/dineshkumar/Downloads/Arpit file16.xlsx");
		
		Thread.sleep(25000);
	}

	@SuppressWarnings("deprecation")
	@When("^user verify the upload sucessfull message$")
	public void user_verify_the_upload_sucessfull_message() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		
		 List<WebElement> uploadsuccess = driver.findElements(By.xpath("//div[text()='Upload Successful! ']"));
		   if (uploadsuccess .size() != 1) {
			  Assert.fail("Inactive status should be visible in account");
		}
		
		
		
	}

	@Then("^user close the drawer$")
	public void user_close_the_drawer() throws Throwable {
	   Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@class='ant-drawer-close']")).click();
		
	}
	
	//==========================@hierarchyverify================================================
	

	@When("^user expands the  tier hierarchy$")
	public void user_expands_the_tier_hierarchy() throws Throwable {
	   
	Thread.sleep(3000);
	pom.getOnb_pg().getFirst_Expand().click();	 
	Thread.sleep(2000);
	pom.getOnb_pg().getSecond_Expand().click();
	Thread.sleep(2000);
	pom.getOnb_pg().getThird_Expand().click();
	
			
			
			
		
	}

	@When("^user verify the HQ name in the  tier$")
	public void user_verify_the_HQ_name_in_the_tier() throws Throwable {
	   
	}

	@When("^user verify the regions name in the tier$")
	public void user_verify_the_regions_name_in_the_tier() throws Throwable {
	  
	}

	@When("^user verify the branches name in the tier$")
	public void user_verify_the_branches_name_in_the_tier() throws Throwable {
	   
		
		
	}

	@When("^user naviagate to user page$")
	public void user_naviagate_to_user_page() throws Throwable {
		Thread.sleep(3000);
		pom.getOnb_pg().getUsers_tab().click();
		//driver.findElement(By.xpath("//button[@class='ant-btn sc-pYPmd higWmH']")).click();
		Thread.sleep(3000);
		WebElement users_firstPage = pom.getOnb_pg().getUsers_firstPage();
		
		scrollingup(users_firstPage);
		Thread.sleep(2000);
	}

	@When("^user verify the user name and assigned role$")
	public void user_verify_the_user_name_and_assigned_role() throws Throwable {
	    
		
		
	}

	
	//===============================@SynctoV1==========================================
	
	
	@When("^user navigates to the account page$")
	public void user_navigates_to_the_account_page() throws Throwable {
	    
		Thread.sleep(3000);
		movetoelement(pom.getacc_pg().getssicon());
		waitforvisibilityofelement(pom.getacc_pg().getSsicon_allorganization());
		movetoelement(pom.getacc_pg().getSsicon_allorganization());
		clickk(pom.getacc_pg().getSsicon_allorganization());
		Thread.sleep(1000);
		movetoelement(pom.getOrg_pg().getNew_Organization());
		pom.getacc_pg().getaccounts_icon().click();
		Thread.sleep(2000);
		//pom.getacc_pg().getSearchclose().click();
		pom.getacc_pg().getSearchclose().click();
		
	}

	@When("^user search for uploaded account$")
	public void user_search_for_uploaded_account() throws Throwable {
	    
		Thread.sleep(2000);
		pom.getacc_pg().getSearch_Icon().click();
		String acc_N_O_Pri_Acc = FileReaderManager.getInstance().getcrinstance().getAcc_N_O_Pri_Acc();
		waitforvisibilityofelement(pom.getacc_pg().getSearch_Account());
		inputOnElement(pom.getacc_pg().getSearch_Account(),acc_N_O_Pri_Acc );
	}

	@SuppressWarnings("deprecation")
	@When("^user Verify SynctoV(\\d+) button gets enabled$")
	public void user_Verify_SynctoV_button_gets_enabled(int arg1) throws Throwable {
	    
		Thread.sleep(1000);                               
		WebElement btenabled = driver.findElement(By.xpath("//span[text()='Not Synced']"));
		  
			   
		System.out.println("condition of Enabled for enabeld btn " +btenabled.isEnabled());
			 
			  Assert.assertEquals(true, btenabled.isEnabled());
		   
		
	}

	@SuppressWarnings("deprecation")
	@When("^user Click SynctoV(\\d+) and  verify side drawer opens$")
	public void user_Click_SynctoV_and_verify_side_drawer_opens(int arg1) throws Throwable {
	    Thread.sleep(2000);
		pom.getOnb_pg().getNot_sync().click();
		Thread.sleep(2000); 
		  List<WebElement> draweropenverify = driver.findElements(By.xpath("//div[text()='This account is not currently synced with version 1, would you like to sync now?']"));

		   if (draweropenverify.size() != 1) {
			  Assert.fail("sucessful verify the side drawer open");
		   }
	}

	@When("^user Click SynctoV(\\d+) within side drawer to confirm$")
	public void user_Click_SynctoV_within_side_drawer_to_confirm(int arg1) throws Throwable {
		Thread.sleep(2000);
		pom.getOnb_pg().getSync_to_V1Btn_submit().click();
		Thread.sleep(12000);
		
	}

	@SuppressWarnings("deprecation")
	@When("^user verify Successfully synced notification$")
	public void user_verify_Successfully_synced_notification() throws Throwable {
	   
	 List<WebElement> v1syncSucessful = driver.findElements(By.xpath("//div[text()='The account has been successfully synced to V1!']"));

 if (v1syncSucessful.size() != 1) {
	 Assert.fail("sucessfully verified V1 sync message ");
		   
 }
		
		driver.findElement(By.xpath("(//button[@class='ant-drawer-close'])[3]")).click();
		
	}

	@SuppressWarnings("deprecation")
	@When("^user Verify SynctoV(\\d+) button is now disabled$")
	public void user_Verify_SynctoV_button_is_now_disabled(int arg1) throws Throwable {
		
		 List<WebElement> v1syncdisabled = driver.findElements(By.xpath("//span[text()='Synced']"));

		 if (v1syncdisabled .size() != 1) {
			 Assert.fail("sucessfully verified V1 sync column button disable ");
		 }
				   
		
	}
	
	//==============================@ActivateAccount=================================
	
	

	@When("^user click on view dropdown$")
	public void user_click_on_view_dropdown() throws Throwable {
		Thread.sleep(2000);
		pom.getacc_pg().getViewdropdown().click();
		
	}

	@When("^user click on activate in the dropdown$")
	public void user_click_on_activate_in_the_dropdown() throws Throwable {
		Thread.sleep(2000);
		movetoelement(pom.getOnb_pg().getActivated_dropdown());
		clickk(pom.getOnb_pg().getActivated_dropdown());
		
	}

	@When("^user click activate button for confirmation$")
	public void user_click_activate_button_for_confirmation() throws Throwable {
		Thread.sleep(2000);
		pom.getOnb_pg().getActive_confirmation().click();
		
		Thread.sleep(2000);
	}

	@SuppressWarnings("deprecation")
	@When("^user verify sync to v(\\d+) button not available$")
	public void user_verify_sync_to_v_button_not_available(int arg1) throws Throwable {
	    
		Thread.sleep(3000);
		List<WebElement> v1syncpresent = driver.findElements(By.xpath("//span[text()='Synced']"));
		if (v1syncpresent.size() > 0) {
			Assert.fail("v1 sync button should not available in the page");
		}

		
		
	}

	@SuppressWarnings("deprecation")
	@Then("^user verify the active status for account$")
	public void user_verify_the_active_status_for_account() throws Throwable {
	    
		
		 List<WebElement> ActiveStatus = driver.findElements(By.xpath("//span[text()='Active']"));

		 if (ActiveStatus.size() != 1) {
			 Assert.fail("sucessfully verified Active Status of the account ");
				   
		 }
		
		 
		 
		 
	}
	
	
	//=================================@Onb_AdminAccverify==========================
	

	@When("^user Navigate to onboarding account window$")
	public void user_Navigate_to_onboarding_account_window() throws Throwable {
		Thread.sleep(2000);
		ArrayList<String>tab =new ArrayList<>(driver.getWindowHandles());
		driver.switchTo().window(tab.get(1));
		
	}

	@When("^Onboarding Admin enter \"([^\"]*)\" as useremailid$")
	public void onboarding_Admin_enter_as_useremailid(String arg1) throws Throwable {
		Thread.sleep(2000);
		waitforvisibilityofelement(pom.getlp().getMail()) ;
		inputOnElement(pom.getlp().getMail(), arg1) ;
		
	}

	@When("^Onboarding Admin click the nextbutton icon$")
	public void onboarding_Admin_click_the_nextbutton_icon() throws Throwable {
	    
		waitforvisibilityofelement(pom.getlp().getNxtbtn()) ;
		clickOnElement(pom.getlp().getNxtbtn());
		
	}

	@When("^Onboarding Admin enter \"([^\"]*)\" as password$")
	public void onboarding_Admin_enter_as_password(String arg1) throws Throwable {
		Thread.sleep(2000);
		waitforvisibilityofelement(pom.getlp().getPassword()) ;
		inputOnElement(pom.getlp().getPassword(), arg1) ;
		
	}

	@When("^Onboarding Admin verify the username in the homepage$")
	public void onboarding_Admin_verify_the_username_in_the_homepage() throws Throwable {
	    
		Thread.sleep(1000);
		waitforvisibilityofelement(pom.getlp().getPassbtn()) ;
		clickOnElement(pom.getlp().getPassbtn());
		Thread.sleep(6000);
		
	}

	@Then("^Onboarding Admin verify the account does not exist in onboarding admin account$")
	public void onboarding_Admin_verify_the_account_does_not_exist_in_onboarding_admin_account() throws Throwable {
	
		
		pom.getacc_pg().getaccounts_icon().click();
		Thread.sleep(2000);
		pom.getacc_pg().getSearch_Icon().click();
		Thread.sleep(1000);
		String acc_N_O_Pri_Acc = FileReaderManager.getInstance().getcrinstance().getAcc_N_O_Pri_Acc();
		waitforvisibilityofelement(pom.getacc_pg().getSearch_Account());
		inputOnElement(pom.getacc_pg().getSearch_Account(),acc_N_O_Pri_Acc);
		Thread.sleep(3000);
	
		
		
		
	}
	
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


