package com.V2SS.Stepdefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.V2SS.helpers.FileReaderManager;
import com.V2SS.helpers.PageObjectManager;
import com.V2SS.runner.Runnercls;
import com.baseclass.org.BaseClass;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class DDStepdefinitionOrganization extends BaseClass {
	
	public static WebDriver driver = Runnercls.driver;
	public static PageObjectManager pom = new PageObjectManager(driver);
	
//======================================@OrgList=====================================================	
	
	@When("^user navigate to the Organization menu tab$")
	public void user_navigate_to_the_Organization_menu_tab() throws Throwable {
		Thread.sleep(2000);
		waitforvisibilityofelement(pom.getOrg_pg().getOrganization_icon());
		pom.getOrg_pg().getOrganization_icon().click();
	   Thread.sleep(2000);
	}

	@When("^user click next page of the list$")
	public void user_click_next_page_of_the_list() throws Throwable {
	   waitforvisibilityofelement(pom.getOrg_pg().getNextpage_Arrow());
		scrollingup(pom.getOrg_pg().getNextpage_Arrow());
		pom.getOrg_pg().getNextpage_Arrow().click();
		Thread.sleep(3000);
	}

	@When("^user click last page of the list$")
	public void user_click_last_page_of_the_list() throws Throwable {
	   waitforvisibilityofelement(pom.getOrg_pg().getLastPage());
		pom.getOrg_pg().getLastPage().click();
		Thread.sleep(3000);
	}

	@When("^user click previous page of the list$")
	public void user_click_previous_page_of_the_list() throws Throwable {
	   waitforvisibilityofelement(pom.getOrg_pg().getPreviouspage());
		pom.getOrg_pg().getPreviouspage().click();
		Thread.sleep(3000);
	}

	@Then("^user click first page of the list$")
	public void user_click_first_page_of_the_list() throws Throwable {
	    waitforvisibilityofelement(pom.getOrg_pg().getFirstpage());
		pom.getOrg_pg().getFirstpage().click();
		Thread.sleep(3000);
	}
	
 //===============================@Search_Sort_Organization======================================
	
	@When("^User search the Organization by its name$")
	public void user_search_the_Organization_by_its_name() throws Throwable {
	    pom.getOrg_pg().getOrganization_searchIcon().click();
	    Thread.sleep(2000);
	    String org_Searchby_OrgName = FileReaderManager.getInstance().getcrinstance().getOrg_Searchby_OrgName();
	    pom.getOrg_pg().getOrg_searchField().sendKeys(org_Searchby_OrgName);
	    Thread.sleep(4000);
	}
	@When("^User clear the search field$")
	public void user_clear_the_search_field() throws Throwable {
	   pom.getOrg_pg().getOrg_searchField().clear();
	    Thread.sleep(2000);
	    
	}

	@When("^User search the organization by its owner$")
	public void user_search_the_organization_by_its_owner() throws Throwable {
	    String org_Searchby_Owner = FileReaderManager.getInstance().getcrinstance().getOrg_Searchby_Owner();
	    pom.getOrg_pg().getOrg_searchField().sendKeys(org_Searchby_Owner);
	    Thread.sleep(5000);
	}

	@When("^User close the search filed Organization$")
	public void user_close_the_search_filed_Organization() throws Throwable {
	   pom.getOrg_pg().getSearch_fieldClose().click();
	    Thread.sleep(2000);
	}

	@When("^user sort org based on reverse alphabetical order of org name$")
	public void user_sort_org_based_on_reverse_alphabetical_order_of_org_name() throws Throwable {
	   pom.getOrg_pg().getOrgNamesort_Uparrow().click();
	    Thread.sleep(2000);
	}

	@When("^user sort org based on alphabetical order of name$")
	public void user_sort_org_based_on_alphabetical_order_of_name() throws Throwable {
	    pom.getOrg_pg().getOrgNamesort_Downarrow().click();
	    Thread.sleep(2000);
	}

	@When("^user sort org based on reverse alphabetical order of owner name$")
	public void user_sort_org_based_on_reverse_alphabetical_order_of_owner_name() throws Throwable {
	    pom.getOrg_pg().getOwnerNamesort_Uparrow().click();
	    Thread.sleep(2000);
	}

	@When("^user sort org based on alphabetical order of its owner name$")
	public void user_sort_org_based_on_alphabetical_order_of_its_owner_name() throws Throwable {
	    pom.getOrg_pg().getOwnerNamesort_Downarrow().click();
	    Thread.sleep(2000);
	}

	@When("^user sort org based on no of accounts from descending order$")
	public void user_sort_org_based_on_no_of_accounts_from_descending_order() throws Throwable {
	     pom.getOrg_pg().getNo_Of_Acc_sort_Uparrow().click();
	    Thread.sleep(2000);
	}

	
	@When("^user sort org based on no of accounts from ascending order$")
	public void user_sort_org_based_on_no_of_accounts_from_ascending_order() throws Throwable {
	   pom.getOrg_pg().getNO_of_Acc_sort_Downarrow().click();
	    Thread.sleep(2000);
	}


	@When("^user sort org based on created date newer to older$")
	public void user_sort_org_based_on_created_date_newer_to_older() throws Throwable {
	   pom.getOrg_pg().getCreatedOn_sort_Uparrow().click();
	    Thread.sleep(2000);
	}

	@When("^user sort org based on created date older to newer$")
	public void user_sort_org_based_on_created_date_older_to_newer() throws Throwable {
	     pom.getOrg_pg().getCreatedOn_sort_Downarrow().click();
	    Thread.sleep(2000);
	}

	@When("^user sort org based on status which is inactive$")
	public void user_sort_org_based_on_status_which_is_inactive() throws Throwable {
	  pom.getOrg_pg().getStatus_sort_Uparrow().click();
	   Thread.sleep(2000);
	}

	@Then("^user sort  org based on status which is active$")
	public void user_sort_org_based_on_status_which_is_active() throws Throwable {
	    pom.getOrg_pg().getStatus_sort_Downarrow().click();
	   Thread.sleep(2000);
	}


//===================================@EditOrganization==========================================
	
	
	
	@When("^user click organization search  icon$")
	public void user_click_organization_search_icon() throws Throwable {
	   waitforvisibilityofelement(pom.getOrg_pg().getOrganization_searchIcon());
		pom.getOrg_pg().getOrganization_searchIcon().click();
		Thread.sleep(2000);
	}

	@When("^user enter organization name to be edited$")
	public void user_enter_organization_name_to_be_edited() throws Throwable {
	   waitforvisibilityofelement(pom.getOrg_pg().getOrg_searchField());
		String org_OrgnameTo_update_searchbar = FileReaderManager.getInstance().getcrinstance().getOrg_OrgnameTo_update_searchbar();
		pom.getOrg_pg().getOrg_searchField().sendKeys(org_OrgnameTo_update_searchbar);
		Thread.sleep(3000);
	}

	@When("^user click the pencil icon for the org$")
	public void user_click_the_pencil_icon_for_the_org() throws Throwable {
	    waitforvisibilityofelement(pom.getOrg_pg().getPencilIcon_Org());
		pom.getOrg_pg().getPencilIcon_Org().click();
		Thread.sleep(5000);
	   
	}

	@When("^user clear the Organization name$")
	public void user_clear_the_Organization_name() throws Throwable {
	    waitforvisibilityofelement(pom.getOrg_pg().getOrganization_Name());
		pom.getOrg_pg().getOrganization_Name().clear();
		Thread.sleep(5000);
	}

	@When("^user enter the Organization name$")
	public void user_enter_the_Organization_name() throws Throwable {
	   waitforvisibilityofelement(pom.getOrg_pg().getOrganization_Name());
		String org_Edited_Orgname_field = FileReaderManager.getInstance().getcrinstance().getOrg_Edited_Orgname_field();
		pom.getOrg_pg().getOrganization_Name().sendKeys(org_Edited_Orgname_field);
		Thread.sleep(3000);
		
		
	}

	@When("^user clear the contact name$")
	public void user_clear_the_contact_name() throws Throwable {
	    waitforvisibilityofelement(pom.getOrg_pg().getContact_Name_Org());
		pom.getOrg_pg().getContact_Name_Org().clear();
		Thread.sleep(3000);
	   
	}

	@When("^user enter the contact name$")
	public void user_enter_the_contact_name() throws Throwable {
	    waitforvisibilityofelement(pom.getOrg_pg().getContact_Name_Org());
		String org_Edited_Contactname_field = FileReaderManager.getInstance().getcrinstance().getOrg_Edited_Contactname_field();
		pom.getOrg_pg().getContact_Name_Org().sendKeys(org_Edited_Contactname_field );
		Thread.sleep(3000);
	}

	@When("^user clear the contact number$")
	public void user_clear_the_contact_number() throws Throwable {
	   waitforvisibilityofelement(pom.getOrg_pg().getContact_Number_Org());
		pom.getOrg_pg().getContact_Number_Org().clear();;
		Thread.sleep(3000);
	}

	@When("^user enter the contact number$")
	public void user_enter_the_contact_number() throws Throwable {
	   waitforvisibilityofelement(pom.getOrg_pg().getContact_Number_Org());
	   String org_Edited_Contactnum_field = FileReaderManager.getInstance().getcrinstance().getOrg_Edited_Contactnum_field();
		pom.getOrg_pg().getContact_Number_Org().sendKeys(org_Edited_Contactnum_field);
		Thread.sleep(3000);
	}

	@When("^user clear the contact email$")
	public void user_clear_the_contact_email() throws Throwable {
	   waitforvisibilityofelement(pom.getOrg_pg().getContact_Email_Org());
		pom.getOrg_pg().getContact_Email_Org().clear();
		Thread.sleep(2000);
	}

	@When("^user enter the contact email$")
	public void user_enter_the_contact_email() throws Throwable {
	   waitforvisibilityofelement(pom.getOrg_pg().getContact_Email_Org());
	   String org_Edited_Contactmail_field = FileReaderManager.getInstance().getcrinstance().getOrg_Edited_Contactmail_field();
		pom.getOrg_pg().getContact_Email_Org().sendKeys(org_Edited_Contactmail_field);
	   
	}

	@When("^user disable active organization toggle$")
	public void user_disable_active_organization_toggle() throws Throwable {
	    Thread.sleep(2000);
		waitforvisibilityofelement(pom.getOrg_pg().getOrg_deactivation_toggle());
		pom.getOrg_pg().getOrg_deactivation_toggle().click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@class='ant-btn ant-btn-primary ant-btn-sm']")).click();
		Thread.sleep(1000);
	   
	    
	}

	@When("^user enable active organization toggle$")
	public void user_enable_active_organization_toggle() throws Throwable {
	   waitforvisibilityofelement(pom.getOrg_pg().getOrg_activation_toggle());
		pom.getOrg_pg().getOrg_activation_toggle().click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@class='ant-btn ant-btn-primary ant-btn-sm']")).click();
		Thread.sleep(2000);
	}

	@Then("^user click the submit button for edit$")
	public void user_click_the_submit_button_for_edit() throws Throwable {
	   waitforvisibilityofelement(pom.getOrg_pg().getSubmit_Org());
		pom.getOrg_pg().getSubmit_Org().click();
		Thread.sleep(3000);
	}
	
	//====================================@Naviagating_Org_Acc==================================================
	
	@When("^user close the search bar$")
	public void user_close_the_search_bar() throws Throwable {
	    waitforvisibilityofelement(pom.getOrg_pg().getSearch_fieldClose());
		pom.getOrg_pg().getSearch_fieldClose().click();
		Thread.sleep(2000);
	}

	@When("^user click the search icon$")
	public void user_click_the_search_icon() throws Throwable {
	   waitforvisibilityofelement(pom.getOrg_pg().getOrganization_searchIcon());
		pom.getOrg_pg().getOrganization_searchIcon().click();
		Thread.sleep(2000);
	}

	@When("^user enter organization name for filtered$")
	public void user_enter_organization_name_for_filtered() throws Throwable {
	   waitforvisibilityofelement(pom.getOrg_pg().getOrg_searchField());
		String org_OrgnameTo_update_searchbar = FileReaderManager.getInstance().getcrinstance().getOrg_OrgnameTo_update_searchbar();
		pom.getOrg_pg().getOrg_searchField().sendKeys(org_OrgnameTo_update_searchbar);
		Thread.sleep(2000);
	}

	@When("^users click the pencil icon for the org$")
	public void users_click_the_pencil_icon_for_the_org() throws Throwable {
	    waitforvisibilityofelement(pom.getOrg_pg().getPencilIcon_Org());
		pom.getOrg_pg().getPencilIcon_Org().click();
		Thread.sleep(2000);
	}

	@When("^user click the account which to be navigate$")
	public void user_click_the_account_which_to_be_navigate() throws Throwable {
	    waitforvisibilityofelement(pom.getOrg_pg().getFirstpage_inner_orgedit());
		scrollingup(pom.getOrg_pg().getFirstpage_inner_orgedit());
		Thread.sleep(2000);
		pom.getOrg_pg().getNavigating_account().click();
	}

	@When("^user navigate to the all accounts dashboard$")
	public void user_navigate_to_the_all_accounts_dashboard() throws Throwable {
	    Thread.sleep(2000);
	    waitforvisibilityofelement(pom.getacc_pg().getssicon());
		movetoelement(pom.getacc_pg().getssicon());
		waitforvisibilityofelement(pom.getacc_pg().getSsicon_allorganization());
		movetoelement(pom.getacc_pg().getSsicon_allorganization());
		clickk(pom.getacc_pg().getSsicon_allorganization());
		Thread.sleep(1000);
	}

	@Then("^user return to the organization menu tab$")
	public void user_return_to_the_organization_menu_tab() throws Throwable {
	   waitforvisibilityofelement(pom.getOrg_pg().getOrganization_icon());
		
	}
  //===================================@CreateOrganization==============================================
	
	@When("^user click new Organization$")
	public void user_click_new_Organization() throws Throwable {
	  waitforvisibilityofelement(pom.getOrg_pg().getNew_Organization());
	 pom.getOrg_pg().getNew_Organization().click();
	Thread.sleep(2000);
	}

	@When("^user click submit button for create org$")
	public void user_click_submit_button_for_create_org() throws Throwable {
	    waitforvisibilityofelement(pom.getOrg_pg().getSubmit_Org());
		pom.getOrg_pg().getSubmit_Org().click();
		Thread.sleep(2000);
	}

	@When("^user enter valid Organization name$")
	public void user_enter_valid_Organization_name() throws Throwable {
	    waitforvisibilityofelement(pom.getOrg_pg().getOrganization_Name());
		String org_NewOrgName = FileReaderManager.getInstance().getcrinstance().getOrg_NewOrgName();
		pom.getOrg_pg().getOrganization_Name().sendKeys(org_NewOrgName);
		Thread.sleep(2000);
		
	}

	@When("^user enter valid contact name$")
	public void user_enter_valid_contact_name() throws Throwable {
	    waitforvisibilityofelement(pom.getOrg_pg().getContact_Name_Org());
		String org_NewContactName = FileReaderManager.getInstance().getcrinstance().getOrg_NewContactName();
		pom.getOrg_pg().getContact_Name_Org().sendKeys(org_NewContactName);
		Thread.sleep(2000);
	}

	@When("^user enter valid contact number$")
	public void user_enter_valid_contact_number() throws Throwable {
	    waitforvisibilityofelement(pom.getOrg_pg().getContact_Number_Org());
		String org_NewContactnum = FileReaderManager.getInstance().getcrinstance().getOrg_NewContactnum();
		pom.getOrg_pg().getContact_Number_Org().sendKeys(org_NewContactnum);
		Thread.sleep(2000);
		
	}

	@When("^user enter valid email address$")
	public void user_enter_valid_email_address() throws Throwable {
	   waitforvisibilityofelement(pom.getOrg_pg().getContact_Email_Org());
		String org_NewContactMail = FileReaderManager.getInstance().getcrinstance().getOrg_NewContactMail();
		pom.getOrg_pg().getContact_Email_Org().sendKeys(org_NewContactMail);
		Thread.sleep(2000);
	}

	@Then("^user click the submit button again$")
	public void user_click_the_submit_button_again() throws Throwable {
	    waitforvisibilityofelement(pom.getOrg_pg().getSubmit_Org());
		pom.getOrg_pg().getSubmit_Org().click();
	}


}