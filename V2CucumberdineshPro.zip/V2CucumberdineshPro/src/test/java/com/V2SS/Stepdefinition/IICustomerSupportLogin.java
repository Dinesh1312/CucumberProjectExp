package com.V2SS.Stepdefinition;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.V2SS.helpers.FileReaderManager;
import com.V2SS.helpers.PageObjectManager;
import com.V2SS.runner.Runnercls;
import com.baseclass.org.BaseClass;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class IICustomerSupportLogin extends BaseClass{

	public static WebDriver driver = Runnercls.driver;
	public static PageObjectManager pom = new PageObjectManager(driver);
	
	@When("^user Navigating to customersupport account window$")
	public void user_Navigating_to_customersupport_account_window() throws Throwable {
	   Thread.sleep(2000);
		ArrayList<String> tab = new ArrayList<>(driver.getWindowHandles());
		driver.switchTo().window(tab.get(2));
	}

	@When("^CustomerSupportAdmin \"([^\"]*)\" as useremailid$")
	public void customersupportadmin_as_useremailid(String arg1) throws Throwable {
	    
		List<WebElement> admingrouptab = driver.findElements(By.xpath("//h2"));
		if (admingrouptab.size() == 1) {
			waitforvisibilityofelement(pom.getlp().getMail1());
			inputOnElement(pom.getlp().getMail1(), arg1);
		} else {
			waitforvisibilityofelement(pom.getlp().getMail());
			inputOnElement(pom.getlp().getMail(), arg1);
		}
	}

	@When("^CustomerSupportAdmin click the nextbutton icon$")
	public void customersupportadmin_click_the_nextbutton_icon() throws Throwable {
	   
		List<WebElement> admingrouptab = driver.findElements(By.xpath("//h2"));
		if (admingrouptab.size() == 1) {
			waitforvisibilityofelement(pom.getlp().getNxtbtn1());
			clickOnElement(pom.getlp().getNxtbtn1());
		} else {
			waitforvisibilityofelement(pom.getlp().getNxtbtn());
			clickOnElement(pom.getlp().getNxtbtn());
		}
	}

	@When("^CustomerSupportAdmin enter \"([^\"]*)\" as password$")
	public void customersupportadmin_enter_as_password(String arg1) throws Throwable {
	   
		Thread.sleep(3000);
		List<WebElement> admingrouptab2 = driver.findElements(By.xpath("//div[text()='Sign in with Google']"));
		if (admingrouptab2.size() == 1) {
			waitforvisibilityofelement(pom.getlp().getPassword());
			inputOnElement(pom.getlp().getPassword(), arg1);

		} else {
			waitforvisibilityofelement(pom.getlp().getPassword1());
			inputOnElement(pom.getlp().getPassword1(), arg1);
		}

		
	}

	@Then("^CustomerSupportAdmin verify the username in the homepage$")
	public void customersupportadmin_verify_the_username_in_the_homepage() throws Throwable {
	   
		Thread.sleep(2000);
		List<WebElement> admingrouptab1 = driver.findElements(By.xpath("//div[text()='Sign in with Google']"));
		if (admingrouptab1.size() == 1) {
			waitforvisibilityofelement(pom.getlp().getPassbtn());
			clickOnElement(pom.getlp().getPassbtn());
			Thread.sleep(9000);

		} else {
			waitforvisibilityofelement(pom.getlp().getPassbtn1());
			clickOnElement(pom.getlp().getPassbtn1());
			Thread.sleep(9000);
		}
		
	}
	
	//===================CSAdminverify============================================
	
	
	@SuppressWarnings("deprecation")
	@When("^CustomerSupportAdmin  verify accounts page and create accounts should not be visible$")
	public void customersupportadmin_verify_accounts_page_and_create_accounts_should_not_be_visible() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    
	    Thread.sleep(4000);
		driver.findElement(By.cssSelector("li[path='/admin/accounts']")).click();
		Thread.sleep(3000);
		List<WebElement> createaccount = driver.findElements(By.cssSelector("button[data-test-new-account-btn=true]"));
		if (createaccount.size() > 0) {
			Assert.fail("Create account should not be visible to an CS Admin account");
	    
	}
	}

	

	@SuppressWarnings("deprecation")
	@When("^CustomerSupportAdmin verify admin icon should not be visible$")
	public void customersupportadmin_verify_admin_icon_should_not_be_visible() throws Throwable {
	    
		Thread.sleep(3000);
		List<WebElement> admintab = driver.findElements(By.cssSelector("li[path='/admin/adminslist']"));
		if (admintab.size() > 0) {
			Assert.fail("Admin icon should not be visible in onboarding admin");
		}
	}
		
	//==========================@Onb_admingroupverification==================================================	
		
	

	@SuppressWarnings("deprecation")
	@When("^CustomerSupportAdmin verify admin group icon should not be visible$")
	public void customersupportadmin_verify_admin_group_icon_should_not_be_visible() throws Throwable {
	   
		Thread.sleep(3000);
		List<WebElement> admingrouptab = driver.findElements(By.cssSelector("li[path='/admin/groups']"));
		if (admingrouptab.size() > 0) {
			Assert.fail("AdminGroup icon should not be visible in onboarding admin");
		}
		WebElement Orgicon = driver.findElement(By.xpath("//li[@path='/admin/organizations']"));
		Orgicon.click();
		Thread.sleep(2000);
	}
	//===============================================================================================
		
	@When("^user verify the Customer ss logo menuicon$")
    public void user_verify_the_Customer_ss_logo_menuicon() throws Throwable {
        WebElement SSlogoicon = driver.findElement(By.xpath("//div[@class='sc-AxjAm sc-jXPivZ djHTWT']"));
        SSlogoicon.click();
        Thread.sleep(2000);
        
    }
    @When("^user click Customer display$")
    public void user_click_Customer_display() throws Throwable {
        WebElement customerclickdisplay = driver.findElement(By.xpath("(//span[@class='ant-table-column-title'])[1]"));
        customerclickdisplay.click();
        Thread.sleep(2000);
        
    }
    @When("^user verify the Customer Organizations icon$")
    public void user_verify_the_Customer_Organizations_icon() throws Throwable {
        WebElement Orgicon = driver.findElement(By.xpath("//li[@path='/admin/organizations']"));
        Orgicon.click();
        Thread.sleep(2000);
        
    }
    @Then("^user verify the Customer Accounts icon$")
    public void user_verify_the_Customer_Accounts_icon() throws Throwable {
        Thread.sleep(4000);
        WebElement OnbAccounticon = driver.findElement(By.xpath("//li[@path='/admin/accounts']"));
        OnbAccounticon.click();
        Thread.sleep(3000);
        
        
    }
    //========================customer Organization menu icon========================
    
    
    @When("^user click the Customer Organization menu icon$")
    public void user_click_the_Customer_Organization_menu_icon() throws Throwable {
        WebElement Orgicon = driver.findElement(By.xpath("//li[@path='/admin/organizations']"));
        Orgicon.click();
        Thread.sleep(2000);
        
    }
    @SuppressWarnings("deprecation")
	@When("^user verify lands on Customer Organization page$")
    public void user_verify_lands_on_Customer_Organization_page() throws Throwable {
        String text2 = "SocialSurvey | Organizations  ";
        Assert.assertEquals(text2.trim(), driver.getTitle().trim());
        System.out.println("succesfully verified the org landing page");
        Thread.sleep(3000);
        
    }
    @SuppressWarnings("deprecation")
	@When("^user verify the Customer body content on organization page$")
    public void user_verify_the_Customer_body_content_on_organization_page() throws Throwable {
        List<WebElement> orgtab = driver.findElements(By.xpath("//table/tbody/tr[1]/td[1]"));
        if (orgtab.size() == 0) {
            Assert.fail("Successfully verifeid the body content of organization page");
    }
    }
    
    @When("^user click Customer Organization no of accounts$")
    public void user_click_Customer_Organization_no_of_accounts() throws Throwable {
        Thread.sleep(2000);
        WebElement orgaccounticon = driver.findElement(By.xpath("(//span[@class='ant-tag sc-fznXWL cEvDCP'])[2]"));
        orgaccounticon.click();
        Thread.sleep(3000);
        
    }
    @When("^user click Customer Organization Accounts menu icon$")
    public void user_click_Customer_Organization_Accounts_menu_icon() throws Throwable {
        WebElement orgaccountbar = driver.findElement(By.xpath("//li[@path='/admin/organizations/accounts']"));
        orgaccountbar.click();
        Thread.sleep(2000);
        
    }
    @SuppressWarnings("deprecation")
	@When("^user verify lands on Customer Organization Accounts bar by title$")
    public void user_verify_lands_on_Customer_Organization_Accounts_bar_by_title() throws Throwable {
        String text = "SocialSurvey | ssqa org | Accounts";
        Assert.assertEquals(text.trim(), driver.getTitle().trim());
        System.out.println("succesfully verified the   Organization Accounts landing page by title");
        Thread.sleep(3000);
    }
    
    @SuppressWarnings("deprecation")
	@When("^user verify the Customer body  content on Organization Accounts$")
    public void user_verify_the_Customer_body_content_on_Organization_Accounts() throws Throwable {
        List<WebElement> orgaccounnt = driver.findElements(By.xpath("//table/tbody/tr[1]/td[1]"));
        if (orgaccounnt.size() == 0) {
            Assert.fail("Successfully verifeid the body content of organization accounts page");
    }
    }
    
    @SuppressWarnings("deprecation")
	@When("^user verify lands on Customer Organization Accounts bar$")
    public void user_verify_lands_on_Customer_Organization_Accounts_bar() throws Throwable {
        String Organization_Acounturl = FileReaderManager.getInstance().getcrinstance().getOrganization_Accounturl();
        Assert.assertEquals(Organization_Acounturl.trim(), driver.getCurrentUrl().trim());
        System.out.println("succesfully verified the org Accounts landing page");
        Thread.sleep(3000);
        
    }
    
    
    @When("^user click Customer Organization users nav menu icon$")
    public void user_click_Customer_Organization_users_nav_menu_icon() throws Throwable {
        WebElement orguserbar = driver.findElement(By.xpath("//li[@path='/admin/organizations/users']"));
        orguserbar.click();
        Thread.sleep(2000);
        
    }
    @SuppressWarnings("deprecation")
	@When("^user verify Customer url lands on Organization user page$")
    public void user_verify_Customer_url_lands_on_Organization_user_page() throws Throwable {
        String Organization_userurl = FileReaderManager.getInstance().getcrinstance().getOrganization_userurl();
        Assert.assertEquals(Organization_userurl.trim(), driver.getCurrentUrl().trim());
        System.out.println("succesfully verified the org users landing page");
        Thread.sleep(4000);
        
    }
    
    @SuppressWarnings("deprecation")
	@When("^user verify lands on Customer Organization users page by title$")
    public void user_verify_lands_on_Customer_Organization_users_page_by_title() throws Throwable {
        String text = "SocialSurvey | ssqa org | Users";
        Assert.assertEquals(text.trim(), driver.getTitle().trim());
        System.out.println("succesfully verified the org user landing page by title");
        Thread.sleep(3000);
    }
    
    @SuppressWarnings("deprecation")
	@When("^user verify the Customer body content on Organization users$")
    public void user_verify_the_Customer_body_content_on_Organization_users() throws Throwable {
        List<WebElement> orgusertab = driver.findElements(By.xpath("//table/tbody/tr[1]/td[1]"));
        if (orgusertab.size() == 0) {
            Assert.fail("Successfully verifeid the body content of organization user page");
    }
    }
    @When("^user click Customer Organization Settings nav menu icon$")
    public void user_click_Customer_Organization_Settings_nav_menu_icon() throws Throwable {
       /* WebElement orgsettingsbar = driver.findElement(By.xpath("//li[@path='/admin/organizations/settings']"));
        orgsettingsbar.click();
        Thread.sleep(2000);
        */
    }
    
    @When("^user verify lands on Customer Organization settings page by title$")
    public void user_verify_lands_on_Customer_Organization_settings_page_by_title() throws Throwable {
       /* String text = "SocialSurvey | Organization settings | settings";
        Assert.assertEquals(text.trim(), driver.getTitle().trim());
        System.out.println("succesfully verified the org settings landing page by title");
        Thread.sleep(3000);
        */
    }
    @Then("^user verify Customer url lands on Organization Settings page$")
    public void user_verify_Customer_url_lands_on_Organization_Settings_page() throws Throwable {
        /*String Organization_settingsurl = FileReaderManager.getInstance().getcrinstance().getOrganization_settingsurl();
        Assert.assertEquals(Organization_settingsurl.trim(), driver.getCurrentUrl().trim());
        System.out.println("succesfully verified the org settings landing page");
        Thread.sleep(4000);
        */
        
        
    }
    
    // ==============================Accounts and view nav menu icon==================
    
    @When("^user click Customer the SS logo icon$")
    public void user_click_Customer_the_SS_logo_icon() throws Throwable {
        WebElement sslogoicon = driver.findElement(By.xpath("//div[@class='sc-AxjAm sc-jXPivZ djHTWT']"));
        sslogoicon.click();
        Thread.sleep(3000);
        
    }
    @When("^user click the Customer AllOrg button$")
    public void user_click_the_Customer_AllOrg_button() throws Throwable {
        WebElement AllOrgsbtn = driver.findElement(By.xpath("//a[text()='All Organizations']"));
        AllOrgsbtn.click();
        Thread.sleep(2000);
    }
    @When("^user click Customer display anywere$")
    public void user_click_Customer_display_anywere() throws Throwable {
        WebElement Allaccountsbtn = driver.findElement(By.xpath("(//span[@class='ant-table-column-title'])[2]"));
        Allaccountsbtn.click();
        Thread.sleep(2000);
    }
    @When("^user click Customer Account button$")
    public void user_click_Customer_Account_button() throws Throwable {
        WebElement Accounticon = driver.findElement(By.xpath("//li[@path='/admin/accounts']"));
        Accounticon.click();
        Thread.sleep(2000);
    }
    @SuppressWarnings("deprecation")
	@When("^user verify lands  on Customer Accounts page$")
    public void user_verify_lands_on_Customer_Accounts_page() throws Throwable {
        String Accounts_url = FileReaderManager.getInstance().getcrinstance().getAccounts_url();
        Assert.assertEquals(Accounts_url.trim(), driver.getCurrentUrl().trim());
        System.out.println("succesfully verified the accounts landing page");
        Thread.sleep(3000);
    }
    
    @SuppressWarnings("deprecation")
	@When("^user verify lands on Customer Accounts page by title$")
    public void user_verify_lands_on_Customer_Accounts_page_by_title() throws Throwable {
        String text1 = "SocialSurvey | Accounts  ";
        Assert.assertEquals(text1.trim(), driver.getTitle().trim());
        System.out.println("succesfully verified the Accounts landing page");
        Thread.sleep(3000);
        
    }
    @SuppressWarnings("deprecation")
	@When("^user verify Customer body content of Accounts page$")
    public void user_verify_Customer_body_content_of_Accounts_page() throws Throwable {
        List<WebElement> admingrouptab = driver.findElements(By.xpath("//table/tbody/tr[1]/td[1]"));
        if (admingrouptab.size() == 0) {
            Assert.fail("Successfully verifeid the body content of Accounts page");
    }
        
    }
    
    @When("^user click Customer view nav button$")
    public void user_click_Customer_view_nav_button() throws Throwable {
        WebElement viewnavbtn = driver.findElement(By.xpath("//button[@data-test-view-account-btn='10414']"));
        viewnavbtn.click();
        Thread.sleep(2000);
        
    }
    @When("^user click on Customer Hierarchy nav menu icon$")
    public void user_click_on_Customer_Hierarchy_nav_menu_icon() throws Throwable {
        WebElement hierarchynavbtn = driver.findElement(By.xpath("//li[@path='/admin/account/hierarchy']"));
        hierarchynavbtn.click();
        Thread.sleep(2000);
        
    }
    @SuppressWarnings("deprecation")
	@When("^user verfiy lands on Customer Hierarchy page$")
    public void user_verfiy_lands_on_Customer_Hierarchy_page() throws Throwable {
        String Hierarchy_url = FileReaderManager.getInstance().getcrinstance().getHierarchy_url();
        Assert.assertEquals(Hierarchy_url.trim(), driver.getCurrentUrl().trim());
        System.out.println("succesfully verified the hierarchy landing page");
        Thread.sleep(3000);
        
    }
    
    @SuppressWarnings("deprecation")
	@When("^user verify lands on Customer Hierarchy page by title$")
    public void user_verify_lands_on_Customer_Hierarchy_page_by_title() throws Throwable {
        String text7 = "SocialSurvey | AmericanQA105 | Hierarchy";
        Assert.assertEquals(text7.trim(), driver.getTitle().trim());
        System.out.println("succesfully verified the Hierarchy landing page by title");
        Thread.sleep(3000);
        
    }
    @SuppressWarnings("deprecation")
	@When("^user verify lands on Customer Hierarchy page by string$")
    public void user_verify_lands_on_Customer_Hierarchy_page_by_string() throws Throwable {
        List<WebElement> admingrouptab = driver.findElements(By.xpath("//table/tbody/tr[1]/td[2]"));
        if (admingrouptab.size() == 0) {
            Assert.fail("Successfully verifeid the body content of Hierarchy page by string");
    }
    }
    
    @When("^user click transaction icon$")
    public void user_click_transaction_icon() throws Throwable {
        WebElement transaction = driver.findElement(By.xpath("//div[@class='ant-menu-submenu-title']"));
        transaction.click();
        Thread.sleep(2000);
    }
    @When("^user click mismatch icon$")
    public void user_click_mismatch_icon() throws Throwable {
        WebElement mismatch = driver.findElement(By.xpath("//li[@path='/admin/account/mismatches']"));
        mismatch.click();
        Thread.sleep(2000);
    }
    @SuppressWarnings("deprecation")
	@When("^user verify lands on mismatch page$")
    public void user_verify_lands_on_mismatch_page() throws Throwable {
        String text1 = "SocialSurvey | AmericanQA105  ";
        Assert.assertEquals(text1.trim(), driver.getTitle().trim());
        System.out.println("succesfully verified the  settings landing page by title");
        Thread.sleep(3000);
    }
    @When("^user click on Customer Settings menu icon$")
    public void user_click_on_Customer_Settings_menu_icon() throws Throwable {
        /*WebElement settingsmenuicon = driver.findElement(By.xpath("//li[@path='/admin/settings']"));
        settingsmenuicon.click();
        Thread.sleep(2000);*/
        
    }
    @When("^user verify lands on Customer settings page$")
    public void user_verify_lands_on_Customer_settings_page() throws Throwable {
        /*String Accountssettings_url = FileReaderManager.getInstance().getcrinstance().getAccountssettings_url();
        Assert.assertEquals(Accountssettings_url.trim(), driver.getCurrentUrl().trim());
        System.out.println("succesfully verified Account settings landing page");
        Thread.sleep(3000);*/
        
    }
    @When("^user verify lands on Customer settings page by title$")
    public void user_verify_lands_on_Customer_settings_page_by_title() throws Throwable {
        /*String text1 = "SocialSurvey | AmericanQA105 | Settings";
        Assert.assertEquals(text1.trim(), driver.getTitle().trim());
        System.out.println("succesfully verified the  settings landing page by title");
        Thread.sleep(3000);*/
    }
    @When("^user click Customer listings nav menu icon$")
    public void user_click_Customer_listings_nav_menu_icon() throws Throwable {
        WebElement Listingsnavbtn = driver.findElement(By.xpath("//li[@path='/admin/account/alllocations']"));
        Listingsnavbtn.click();
        Thread.sleep(2000);
    }
    
    @SuppressWarnings("deprecation")
	@When("^user verify lands on Customer Listings page by url$")
    public void user_verify_lands_on_Customer_Listings_page_by_url() throws Throwable {
        String listings_url = FileReaderManager.getInstance().getcrinstance().getlistings_url();
        Assert.assertEquals(listings_url.trim(), driver.getCurrentUrl().trim());
        System.out.println("succesfully verified Listings landing page by url");
        Thread.sleep(3000);
    }
    @SuppressWarnings("deprecation")
	@When("^user verify lands on Customer Listings page by title$")
    public void user_verify_lands_on_Customer_Listings_page_by_title() throws Throwable {
        String text1 = "SocialSurvey | AmericanQA105 | Listing / Locations";
        Assert.assertEquals(text1.trim(), driver.getTitle().trim());
        System.out.println("succesfully verified the settings landing page by title");
        Thread.sleep(3000);
    }
    @SuppressWarnings("deprecation")
	@When("^user verify lands on Customer listings page by string$")
    public void user_verify_lands_on_Customer_listings_page_by_string() throws Throwable {
        List<WebElement> hierarchy = driver.findElements(By.xpath("//table/tbody/tr[1]/td[2]"));
        if (hierarchy.size() == 0) {
            Assert.fail("Successfully verifeid the body content of Hierarchy page by string");
    }
    }
    @When("^user click on Customer Widget configuration$")
    public void user_click_on_Customer_Widget_configuration() throws Throwable {
        WebElement Widgetmenuicon = driver.findElement(By.xpath("//li[@path='/admin/account/widget/testimonials/configuration']"));
        Widgetmenuicon.click();
        Thread.sleep(2000);
        
    }
    @SuppressWarnings("deprecation")
	@When("^user verify lands on Customer Widget page$")
    public void user_verify_lands_on_Customer_Widget_page() throws Throwable {
        String Widge_url = FileReaderManager.getInstance().getcrinstance().getWidge_url();
        Assert.assertEquals(Widge_url.trim(), driver.getCurrentUrl().trim());
        System.out.println("succesfully verified the widget landing page");
        Thread.sleep(3000);
        
    }
    @SuppressWarnings("deprecation")
	@When("^user verify lands on Customer Widget page by title$")
    public void user_verify_lands_on_Customer_Widget_page_by_title() throws Throwable {
        String text1 = "SocialSurvey | AmericanQA105 | Testimonial Widget";
        Assert.assertEquals(text1.trim(), driver.getTitle().trim());
        System.out.println("succesfully verified the Widget landing page by title");
        Thread.sleep(3000);
    }
    
    @When("^user click Customer Reviews management menu icon$")
    public void user_click_Customer_Reviews_management_menu_icon() throws Throwable {
        WebElement Reviewsmenuicon = driver.findElement(By.xpath("//li[@path='/admin/account/reviews']"));
        Reviewsmenuicon.click();
        Thread.sleep(2000);
        
        
    }
    @SuppressWarnings("deprecation")
	@When("^user verify lands on Customer Reviews management by title$")
    public void user_verify_lands_on_Customer_Reviews_management_by_title() throws Throwable {
        String text1 = "SocialSurvey | AmericanQA105 | Reviews Management";
        Assert.assertEquals(text1.trim(), driver.getTitle().trim());
        System.out.println("succesfully verified the Reviews management landing page by title");
        Thread.sleep(3000);
    }
    @SuppressWarnings("deprecation")
	@Then("^user verify lands on Customer Reviews management page$")
    public void user_verify_lands_on_Customer_Reviews_management_page() throws Throwable {
        String ReviewsManagement_url = FileReaderManager.getInstance().getcrinstance().getReviewsManagement_url();
        Assert.assertEquals(ReviewsManagement_url.trim(), driver.getCurrentUrl().trim());
        System.out.println("succesfully verified the Review management landing page");
        Thread.sleep(3000);
        
    }
    
    //===================================Customer SSlogo menu nav icon========================================
    @When("^user  click the Customer  ss logo menuicon$")
    public void user_click_the_Customer_ss_logo_menuicon() throws Throwable {
        WebElement SSlogoicon = driver.findElement(By.xpath("//div[@class='sc-AxjAm sc-jXPivZ djHTWT']"));
        SSlogoicon.click();
        Thread.sleep(2000);
        
        
    }
    @When("^user click the  Customer logout button$")
    public void user_click_the_Customer_logout_button() throws Throwable {
        WebElement sslogoutbtn = driver.findElement(By.xpath("//a[text()='Logout']"));
        sslogoutbtn.click();
        Thread.sleep(2000);
        
    }
    @SuppressWarnings("deprecation")
	@Then("^user verify  Customer Admin loged out from the application$")
    public void user_verify_Customer_Admin_loged_out_from_the_application() throws Throwable {
        String logout_url = FileReaderManager.getInstance().getcrinstance().getlogout_url();
        Assert.assertEquals(logout_url.trim(), driver.getCurrentUrl().trim());
        System.out.println("succesfully verified user loggrd out ");
        Thread.sleep(3000);
    
	

}
}
