package com.V2SS.Stepdefinition;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.V2SS.helpers.FileReaderManager;
import com.V2SS.helpers.PageObjectManager;
import com.V2SS.runner.Runnercls;
import com.baseclass.org.BaseClass;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class AAStepdefenitionLogin extends BaseClass {

	public static WebDriver driver = Runnercls.driver;
	public static PageObjectManager pom = new PageObjectManager(driver);
// -----------------------------------------Login------------------------------------------------------------
	// crate set of 2 tabs for onboarding and cs admin
	@When("^user create required tabs$")
	public void user_create_required_tabs() throws Throwable {

		newtab();
		implicitlywait(2);
		navigatetab(1);
		Thread.sleep(2000);
		String geturl = FileReaderManager.getInstance().getcrinstance().geturl();
		applaunch(geturl);
		waitforvisibilityofelement(pom.getlp().getIcon());
		clickOnElement(pom.getlp().getIcon());
		newtab();
		Thread.sleep(2000);
		navigatetab(2);
		applaunch(geturl);
		waitforvisibilityofelement(pom.getlp().getIcon());
		clickOnElement(pom.getlp().getIcon());

	}

	// create additional one tab for salesexec admin
	@When("^user create tab for salesexc account$")
	public void user_create_tab_for_salesexc_account() throws Throwable {
		newtab();
		navigatetab(3);
		Thread.sleep(2000);
		String geturl = FileReaderManager.getInstance().getcrinstance().geturl();
		applaunch(geturl);
		waitforvisibilityofelement(pom.getlp().getIcon());
		clickOnElement(pom.getlp().getIcon());

	}

	@And("^user click the login icon$")
	public void user_click_the_login_icon() throws Throwable {
		navigatetab(0);
		waitforvisibilityofelement(pom.getlp().getIcon());
		clickOnElement(pom.getlp().getIcon());
	}

	// user enter email based on g-suite login dispaly
	@And("^user enter \"(.*?)\" as useremailid$")
	public void user_enter_as_useremailid(String arg1) throws Throwable {
		List<WebElement> admingrouptab = driver.findElements(By.xpath("//h2"));
		if (admingrouptab.size() == 1) {
			waitforvisibilityofelement(pom.getlp().getMail1());
			inputOnElement(pom.getlp().getMail1(), arg1);
		} else {
			waitforvisibilityofelement(pom.getlp().getMail());
			inputOnElement(pom.getlp().getMail(), arg1);
		}

	}

	// user click nxt based on g-suite login dispaly
	@And("^user click the nextbutton icon$")
	public void user_click_the_nextbutton_icon() throws Throwable {
		List<WebElement> admingrouptab = driver.findElements(By.xpath("//h2"));
		if (admingrouptab.size() == 1) {
			waitforvisibilityofelement(pom.getlp().getNxtbtn1());
			clickOnElement(pom.getlp().getNxtbtn1());
		} else {
			waitforvisibilityofelement(pom.getlp().getNxtbtn());
			clickOnElement(pom.getlp().getNxtbtn());
		}

	}

	// user enter password based on g-suite login dispaly
	@And("^user enter \"(.*?)\" as password$")
	public void user_enter_as_password(String arg2) throws Throwable {
		Thread.sleep(3000);
		List<WebElement> admingrouptab2 = driver.findElements(By.xpath("//div[text()='Sign in with Google']"));
		if (admingrouptab2.size() == 1) {
			waitforvisibilityofelement(pom.getlp().getPassword());
			inputOnElement(pom.getlp().getPassword(), arg2);

		} else {
			waitforvisibilityofelement(pom.getlp().getPassword1());
			inputOnElement(pom.getlp().getPassword1(), arg2);
		}

	}
	// user click password nxt based on g-suite login dispaly
	@Then("^user verify the username in the homepage$")
	public void user_verify_the_username_in_the_homepage() throws Throwable {
		Thread.sleep(2000);
		List<WebElement> admingrouptab1 = driver.findElements(By.xpath("//div[text()='Sign in with Google']"));
		if (admingrouptab1.size() == 1) {
			waitforvisibilityofelement(pom.getlp().getPassbtn());
			clickOnElement(pom.getlp().getPassbtn());
			Thread.sleep(9000);

		} else {
			waitforvisibilityofelement(pom.getlp().getPassbtn1());
			clickOnElement(pom.getlp().getPassbtn1());
			Thread.sleep(9000);

		}

	}
}
